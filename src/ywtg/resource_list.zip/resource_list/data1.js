const data = [{"id":2,"name":"积水小区","value":30,"pintype":"ZJGD_积水小区","type":"积水小区","popup":"click2","color":"0, 190, 255","icon":"/fastdfs/group1/M00/09/E4/wKgJx1_pSPyAOlhjAAAYXXDHrjY666.png"}];

export default data;