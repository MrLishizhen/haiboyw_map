import React, { Component } from 'react';
import { ReactDOM } from 'react';
import styles from './index.less'
import { Table, Tooltip, Icon } from 'antd';
import _ from 'lodash';
import { color } from 'highcharts';
import { Row, Col } from 'antd';

//cn_hsjc_ck
export default class Index extends Component {
  constructor(props) {
    super(props);
    this.state = {
      handlers: '',
      filter: [],
    }
  }

  componentDidMount() {
    try {
      const { buffEvent = [{ type: 'click' }] } = this.props;
      let eventValue = {};

      for (let i = 0; i < buffEvent.length; i++) {
        const eventObj = buffEvent[i];
        const { type, method, bindedComponents } = eventObj;
        if (type === 'click') {
          eventValue = {
            onClick: (data) => {
              method && method({ ...data }, bindedComponents)
            }
          }
        }
      }
      this.setState({
        handlers: Object.assign({}, eventValue)
      })

      // this.generatorTimer(this.props, this.state);
      // this.cnt = 1, this.scrollTop = 0;

      // var wrapper = document.getElementById('cn_renliu_wrapper').getElementsByClassName('ant-table-body')[0];
      // wrapper.onmouseenter = () => {
      //   this.clearTimer();
      // };
      // wrapper.onmouseleave = () => {
      //   this.generatorTimer(this.props, this.state)
      // }
    } catch (e) {
      console.log(e)
    }
  }

  onChange = (pagination, filters, sorter, extra) => {
    try {
      // console.log('params', pagination, filters, sorter, extra);
      let filter = [];
      if (filters.unit_type && filters.unit_type.length) {
        filter = filters.unit_type;
        // console.log("filter", filter);
        this.setState({ filter });
      } else {
        this.setState({ filter: [] });
      }
    } catch (error) {
      console.log(e)
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    try {
      // if (!_.isEqual(nextProps.dataProvider, this.props.dataProvider) || !_.isEqual(nextState.filter, this.state.filter)) {
      //   var wrapper = document.getElementById('cn_renliu_wrapper').getElementsByClassName('ant-table-body')[0];
      //   wrapper.scrollTop = 0;
      //   this.cnt = 1, this.scrollTop = 0;
      // this.clearTimer();
      // this.generatorTimer(nextProps, nextState);
      // }

      return true;
    } catch (error) {
      console.log(e)
    }
  }

  // generatorTimer(props, state) {
  //   const { filter = {} } = state;
  //   const { dataProvider = [] } = props;
  //   const data = filter && filter.length > 0 ? dataProvider.filter(item => filter && filter.includes(item.unit_type)) : dataProvider;

  //   // console.log(dataProvider.filter(item => filter && filter.includes(item.unit_type)), 'item')

  //   if (data && data.length > 0) {
  //     var wrapper = document.getElementById('cn_renliu_wrapper').getElementsByClassName('ant-table-body')[0];
  //     var table = document.getElementById('cn_renliu_wrapper').getElementsByClassName('ant-table-tbody')[0];
  //     let speed = 8 * 1000 / (8 * height);
  //     const height = table.offsetHeight / data.length;
  //     console.info(height);
  //     console.info(table.offsetHeight);

  //     this.timerA = setInterval(() => {
  //       if (this.timer) {
  //         clearInterval(this.timer);
  //         this.timer = undefined;
  //       }

  //       this.timer = setInterval(() => {
  //         // console.info(this.cnt, Math.ceil(dataProvider.length / 8),(dataProvider.length - 8) * 164.1 - (dataProvider.length % 8 === 0 ? 0 : 80));
  //         if (this.cnt == Math.ceil(data.length / 8)) {
  //           this.cnt = 1, this.scrollTop = 0;
  //           wrapper.scrollTop = 0;
  //           this.clearTimer();
  //           this.generatorTimer(props, state);
  //         }
  //         if (wrapper.scrollTop < this.cnt * 8 * height) {
  //           if (wrapper.scrollTop > (data.length - 8) * height - (data.length % 8 === 0 ? 0 : 80)) {
  //             clearInterval(this.timer);
  //             this.timer = undefined;
  //             this.cnt++;
  //           } else {
  //             this.scrollTop = this.scrollTop + 2;
  //             wrapper.scrollTop = this.scrollTop;
  //           }
  //         } else {
  //           clearInterval(this.timer);
  //           this.timer = undefined;
  //           this.cnt++;
  //         }
  //       }, speed)
  //     }, 8 * 1000);
  //   }
  // }

  // clearTimer() {
  //   clearInterval(this.timerA);
  //   clearInterval(this.timer);
  //   this.timerA = null;
  //   this.timer = null;
  // }

  render() {
    const { dataProvider } = this.props;
    const { filter } = this.state;
    const isHasData = dataProvider && Array.isArray(dataProvider) && dataProvider.length > 0 && Boolean(dataProvider[0])
    const data = isHasData ? dataProvider : [];
    let datalist = []
    let lastdata = []
    if(data && data.length > 0){
      data.map((item,index)=>{
        if(index != data.length - 1){
          datalist.push(item)
        }
      })
      lastdata = [data[data.length-1]]
    }
    // console.log(data, 'datasss')

    const columns = [
      {
        title: '街镇',
        dataIndex: 'C',
        width: '5%',
        // key:'C',
        // fixed: 'left',
        onCell: () => {
          return {
            style: {
              maxWidth: 170,
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis'
            }
          }
        },
        render: (text, record) => {
          const { C } = record
          return <Tooltip placement="topLeft" title={C} overlayClassName={styles.ant_tooltip}>{C}</Tooltip>
        }
      },
      {
        title: '计划人数',
        dataIndex: 'D',
        // width: 469.2,
        width: '5%',
        // key:'D',
        // fixed:'left',
        onCell: () => {
          return {
            style: {
              maxWidth: 170,
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis',

            }
          }
        },
        render: (text, record) => {
          const { D } = record
          return <Tooltip placement="topLeft" title={D} overlayClassName={styles.ant_tooltip}>{D}</Tooltip>
        }
      },
      {
        title: '采集人数',
        dataIndex: 'E',
        // width:469.2,
        width: '5%',
        key:'E',
        // fixed:'left',
        onCell: () => {
          return {
            style: {
              maxWidth: 170,
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis'
            }
          }
        },
        render: (text, record) => {
          const { E } = record
          return <Tooltip placement="topLeft" title={E} overlayClassName={styles.ant_tooltip}>{E}</Tooltip>
        }
      },
      {
        title: '采集率',
        dataIndex: 'F',
        width: '5%',
        onCell: () => {
          return {
            style: {
              maxWidth: 170,
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis',
              fontWeight: 700,
              color:'#8AC6FF'
            }
          }
        },
        render: (text, record) => {
          const { F } = record
          return <Tooltip placement="topLeft" title={F} overlayClassName={styles.ant_tooltip}>{F}</Tooltip>
        }
      },
      {
        title: '送检人数',
        dataIndex: 'G',
        width: '5%',
        onCell: () => {
          return {
            style: {
              maxWidth: 170,
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis'
            }
          }
        },
        render: (text, record) => {
          const { G } = record
          return <Tooltip placement="topLeft" title={G} overlayClassName={styles.ant_tooltip}>{G}</Tooltip>
        }
      },
      {
        title: '送检率',
        dataIndex: 'H',
        width: '5%',
        onCell: () => {
          return {
            style: {
              maxWidth: 170,
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis',
              fontWeight: 700,
              color:'#8AC6FF'
            }
          }
        },
        render: (text, record) => {
          const { H } = record
          return <Tooltip placement="topLeft" title={H} overlayClassName={styles.ant_tooltip}>{H}</Tooltip>
        }
      },
      {
        title: '接收人数',
        dataIndex: 'I',
        width: '5%',
        onCell: () => {
          return {
            style: {
              maxWidth: 170,
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis'
            }
          }
        },
        render: (text, record) => {
          const { I } = record
          return <Tooltip placement="topLeft" title={I} overlayClassName={styles.ant_tooltip}>{I}</Tooltip>
        }
      },
      {
        title: '接收率',
        dataIndex: 'J',
        width: '5%',
        onCell: () => {
          return {
            style: {
              maxWidth: 170,
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis',
              fontWeight: 700,
              color:'#8AC6FF'
            }
          }
        },
        render: (text, record) => {
          const { J } = record
          return <Tooltip placement="topLeft" title={J} overlayClassName={styles.ant_tooltip}>{J}</Tooltip>
        }
      },
      {
        title: '检测人数',
        dataIndex: 'K',
        width: '5%',
        onCell: () => {
          return {
            style: {
              maxWidth: 170,
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis'
            }
          }
        },
        render: (text, record) => {
          const { K } = record
          return <Tooltip placement="topLeft" title={K} overlayClassName={styles.ant_tooltip}>{K}</Tooltip>
        }
      },
      {
        title: '检测率',
        dataIndex: 'L',
        width: '5%',
        onCell: () => {
          return {
            style: {
              maxWidth: 170,
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis',
              fontWeight: 700,
              color:'#8AC6FF'
            }
          }
        },
        render: (text, record) => {
          const { L } = record
          return <Tooltip placement="topLeft" title={L} overlayClassName={styles.ant_tooltip}>{L}</Tooltip>
        }
      },
     
    ];

    const columnss = [
      {
        dataIndex: 'C',
        width: '5%',
        onHeaderCell: () => {
          return {
            style: {
              display:"none",
            }
          }
        },
        onCell: () => {
          return {
            style: {
              maxWidth: 170,
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis'
            }
          }
        },
        render: (text, record) => {
          const { C } = record
          return <Tooltip placement="topLeft" title={C} overlayClassName={styles.ant_tooltip}>{C}</Tooltip>
        }
      },
      {
        dataIndex: 'D',
        width: '5%',
        onHeaderCell: () => {
          return {
            style: {
              display:"none",
            }
          }
        },
        onCell: () => {
          return {
            style: {
              maxWidth: 170,
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis',

            }
          }
        },
        render: (text, record) => {
          const { D } = record
          return <Tooltip placement="topLeft" title={D} overlayClassName={styles.ant_tooltip}>{D}</Tooltip>
        }
      },
      {
        title: '采集人数',
        dataIndex: 'E',
        // width:469.2,
        width: '5%',
        key:'E',
        // fixed:'left',
        onHeaderCell: () => {
          return {
            style: {
              display:"none",
            }
          }
        },
        onCell: () => {
          return {
            style: {
              maxWidth: 170,
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis'
            }
          }
        },
        render: (text, record) => {
          const { E } = record
          return <Tooltip placement="topLeft" title={E} overlayClassName={styles.ant_tooltip}>{E}</Tooltip>
        }
      },
      {
        title: '采集率',
        dataIndex: 'F',
        width: '5%',
        onHeaderCell: () => {
          return {
            style: {
              display:"none",
            }
          }
        },
        onCell: () => {
          return {
            style: {
              maxWidth: 170,
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis',
              fontWeight: 700,
              color:'#8AC6FF'
            }
          }
        },
        render: (text, record) => {
          const { F } = record
          return <Tooltip placement="topLeft" title={F} overlayClassName={styles.ant_tooltip}>{F}</Tooltip>
        }
      },
      {
        title: '送检人数',
        dataIndex: 'G',
        width: '5%',
        onHeaderCell: () => {
          return {
            style: {
              display:"none",
            }
          }
        },
        onCell: () => {
          return {
            style: {
              maxWidth: 170,
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis'
            }
          }
        },
        render: (text, record) => {
          const { G } = record
          return <Tooltip placement="topLeft" title={G} overlayClassName={styles.ant_tooltip}>{G}</Tooltip>
        }
      },
      {
        title: '送检率',
        dataIndex: 'H',
        width: '5%',
        onHeaderCell: () => {
          return {
            style: {
              display:"none",
            }
          }
        },
        onCell: () => {
          return {
            style: {
              maxWidth: 170,
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis',
              fontWeight: 700,
              color:'#8AC6FF'
            }
          }
        },
        render: (text, record) => {
          const { H } = record
          return <Tooltip placement="topLeft" title={H} overlayClassName={styles.ant_tooltip}>{H}</Tooltip>
        }
      },
      {
        title: '接收人数',
        dataIndex: 'I',
        width: '5%',
        onHeaderCell: () => {
          return {
            style: {
              display:"none",
            }
          }
        },
        onCell: () => {
          return {
            style: {
              maxWidth: 170,
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis'
            }
          }
        },
        render: (text, record) => {
          const { I } = record
          return <Tooltip placement="topLeft" title={I} overlayClassName={styles.ant_tooltip}>{I}</Tooltip>
        }
      },
      {
        title: '接收率',
        dataIndex: 'J',
        width: '5%',
        onHeaderCell: () => {
          return {
            style: {
              display:"none",
            }
          }
        },
        onCell: () => {
          return {
            style: {
              maxWidth: 170,
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis',
              fontWeight: 700,
              color:'#8AC6FF'
            }
          }
        },
        render: (text, record) => {
          const { J } = record
          return <Tooltip placement="topLeft" title={J} overlayClassName={styles.ant_tooltip}>{J}</Tooltip>
        }
      },
      {
        title: '检测人数',
        dataIndex: 'K',
        width: '5%',
        onHeaderCell: () => {
          return {
            style: {
              display:"none",
            }
          }
        },
        onCell: () => {
          return {
            style: {
              maxWidth: 170,
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis'
            }
          }
        },
        render: (text, record) => {
          const { K } = record
          return <Tooltip placement="topLeft" title={K} overlayClassName={styles.ant_tooltip}>{K}</Tooltip>
        }
      },
      {
        title: '检测率',
        dataIndex: 'L',
        width: '5%',
        onHeaderCell: () => {
          return {
            style: {
              display:"none",
            }
          }
        },
        onCell: () => {
          return {
            style: {
              maxWidth: 170,
              overflow: 'hidden',
              whiteSpace: 'nowrap',
              textOverflow: 'ellipsis',
              fontWeight: 700,
              color:'#8AC6FF'
            }
          }
        },
        render: (text, record) => {
          const { L } = record
          return <Tooltip placement="topLeft" title={L} overlayClassName={styles.ant_tooltip}>{L}</Tooltip>
        }
      },
     
    ];

    return (
      <div id='cn_renliu_wrapper' className={styles.MaxBox}>
        <Table
          // generatorTimer={this.generatorTimer.bind(this)}
          rowKey={(record) => record.point_name}
          columns={columns} pagination={false}
          dataSource={datalist}
          onChange={this.onChange}
          scroll={{ y: 1300}}
        />
        <Table
          // generatorTimer={this.generatorTimer.bind(this)}
          rowKey={(record) => record.point_name}
          columns={columnss} pagination={false}
          dataSource={lastdata}
          onChange={this.onChange}
        />
      </div>
    )
  }
}