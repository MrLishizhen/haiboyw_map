const data = [{ "ID": 2, "A": "3月31日", "B": "492500", "C": "222356", "D": "45.15%", "E": "2021年3月1日", "F": "2021年3月31日", "DATACYCLE": "date", "DATADATE": "20210402" }];

export default data;