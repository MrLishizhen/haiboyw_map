import React, {Component} from 'react';

import {isEqual} from "lodash";
import styles from './index.less'
//table_li
export default class Jindu extends Component {

    constructor(props) {
        super(props);
        const {dataProvider = []} = props;
        const dataQuery = Array.isArray(dataProvider) && dataProvider.length > 0 ? dataProvider : [];

        this.state = {
            // data: dataQuery,
            data: [
                {
                    line:2,
                    tabItemHeight:'67px',
                    tabHeader: [
                        {
                            name: '街道名称',
                            style:{
                                width: '15%',
                            },
                            value:'jdmc'
                        },
                        {
                            name: '类别',
                            style:{
                                width: '10%',
                            },
                            value:'lb'
                        },
                        {
                            name: '警情地址',
                            style:{
                                width: '30%',
                            },
                            value:'dz'
                        },
                        {
                            name: '报警时间',
                            style:{
                                width: '15%',
                            },
                            value:'bjsj'
                        }, {
                            name: '详情',
                            style:{
                                width: '30%',
                            },
                            value:'xq'
                        }

                    ],
                    tabCom:[
                        {jdmc:'食谱',lb:'求助',dz:'地址地址地址地址 地址地址地址地址',bjsj:'2022.5.23 19:23:54',xq:'详情详情详情详情详情 详情详情详情详情详详情详情详情详情详情 '},
                        {jdmc:'食谱',lb:'求助',dz:'地址地址地址地址 地址地址地址地址',bjsj:'2022.5.23 19:23:54',xq:'详情详情详情详情详情 详情详情详情详情详详情详情详情详情详情 '},
                        {jdmc:'食谱',lb:'求助',dz:'地址地址地址地址 地址地址地址地址',bjsj:'2022.5.23 19:23:54',xq:'详情详情详情详情详情 详情详情详情详情详详情详情详情详情详情 '},
                        {jdmc:'食谱',lb:'求助',dz:'地址地址地址地址 地址地址地址地址',bjsj:'2022.5.23 19:23:54',xq:'详情详情详情详情详情 详情详情详情详情详详情详情详情详情详情 '},
                        {jdmc:'食谱',lb:'求助',dz:'地址地址地址地址 地址地址地址地址',bjsj:'2022.5.23 19:23:54',xq:'详情详情详情详情详情 详情详情详情详情详详情详情详情详情详情 '},
                        {jdmc:'食谱',lb:'求助',dz:'地址地址地址地址 地址地址地址地址',bjsj:'2022.5.23 19:23:54',xq:'详情详情详情详情详情 详情详情详情详情详详情详情详情详情详情 '},
                        {jdmc:'食谱',lb:'求助',dz:'地址地址地址地址 地址地址地址地址',bjsj:'2022.5.23 19:23:54',xq:'详情详情详情详情详情 详情详情详情详情详详情详情详情详情详情 '},
                        {jdmc:'食谱',lb:'求助',dz:'地址地址地址地址 地址地址地址地址',bjsj:'2022.5.23 19:23:54',xq:'详情详情详情详情详情 详情详情详情详情详详情详情详情详情详情 '},
                        {jdmc:'食谱',lb:'求助',dz:'地址地址地址地址 地址地址地址地址',bjsj:'2022.5.23 19:23:54',xq:'详情详情详情详情详情 详情详情详情详情详详情详情详情详情详情 '},
                        {jdmc:'食谱',lb:'求助',dz:'地址地址地址地址 地址地址地址地址',bjsj:'2022.5.23 19:23:54',xq:'详情详情详情详情详情 详情详情详情详情详详情详情详情详情详情 '},

                        {jdmc:'食谱',lb:'求助',dz:'地址地址地址地址 地址地址地址地址',bjsj:'2022.5.23 19:23:54',xq:'详情详情详情详情详情 详情详情详情详情详详情详情详情详情详情 '},
                        {jdmc:'食谱',lb:'求助',dz:'地址地址地址地址 地址地址地址地址',bjsj:'2022.5.23 19:23:54',xq:'详情详情详情详情详情 详情详情详情详情详详情详情详情详情详情 '},
                        {jdmc:'食谱',lb:'求助',dz:'地址地址地址地址 地址地址地址地址',bjsj:'2022.5.23 19:23:54',xq:'详情详情详情详情详情 详情详情详情详情详详情详情详情详情详情 '},
                        {jdmc:'食谱',lb:'求助',dz:'地址地址地址地址 地址地址地址地址',bjsj:'2022.5.23 19:23:54',xq:'详情详情详情详情详情 详情详情详情详情详详情详情详情详情详情 '},

                    ]

                }

            ],

        }
    }


    componentDidMount() {
        const {buffEvent = [{type: 'click'}]} = this.props;
        let eventValue = {};
        for (let i = 0; i < buffEvent.length; i++) {
            const eventObj = buffEvent[i];
            const {type, method, bindedComponents} = eventObj;
            if (type === 'click') {
                eventValue = {
                    onClick: (data) => {
                        method && method({...data}, bindedComponents)
                    }
                }
            }
        }
        this.setState({
            handlers: Object.assign({}, eventValue)
        })

    }

    handleChange = (value) => {
        this.setState({})
        this.state.handlers.onClick && this.state.handlers.onClick({value});
    }

    shouldComponentUpdate(nextProps, nextState) {
        const {dataProvider, style} = nextProps;
        console.info('bubble shouldComponentUpdate', nextProps, this.props);
        if (!isEqual(dataProvider, this.props.dataProvider)) {
            if (dataProvider && dataProvider.length === 1 && dataProvider[0].series) {
                // colorList = dataProvider[0].series.map(item => item.option.itemStyle.color);
            } else {
                const dataQuery = Array.isArray(dataProvider) && dataProvider.length > 0 ? dataProvider : [];

                this.setState({data: dataQuery}, () => {
                    // let value = this.selectHot(dataQuery);
                    // console.log(value,123)
                    // this.handleChange(value)
                });
            }
        }

        return !isEqual(nextProps, this.props) || !isEqual(nextState, this.state);
    }

    render() {
        let data = this.state?.data[0]||{};
        let {tabHeader = [],tabCom=[],tabItemHeight='42px',line=2,tabH='42px'} = data;

        return (
            <div ref={node => this.node = node} className={styles.box}>
                {
                    tabHeader.length > 0 ?
                        <>
                            <div className={styles.tableH} style={{height:tabH,lineHeight:tabH}}>
                                {
                                    tabHeader.map((u, i) => {
                                        return <div key={i} title={u.name} style={{...u.style}}
                                                    className={styles.tableH_item}>
                                            {u.name}
                                        </div>
                                    })
                                }
                            </div>
                            <div className={styles.com}>
                                {
                                    tabCom.map((u,i)=>{
                                        return <div key={i} className={styles.comItem} style={{height:tabItemHeight}}>
                                            {
                                                tabHeader.map((j,l)=>{
                                                    return <div title={u[j.value]} style={{...j.style,WebkitLineClamp:line}}  key={l}>{u[j.value]}</div>
                                                })
                                            }
                                        </div>
                                    })
                                }
                            </div>
                        </>
                        : ''
                }
            </div>
        )
    }

}
