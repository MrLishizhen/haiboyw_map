const data = [
  {
    "flowNo": 1,
    "creatDate": "2021/5/18 12:36:14",
    "serialNumber": 123456,
    "street": "天山路街道",
    "flowStatus": "处置中",
    "classA": "物联感知",
    "classC": "事件名称",
    "addr": "地址"
  },
  {
    "flowNo": 2,
    "creatDate": "2021/5/18 12:36:14",
    "serialNumber": 123456,
    "street": "天山路街道",
    "flowStatus": "处置中",
    "classA": "物联感知",
    "classC": "事件名称",
    "addr": "地址"
  },
  {
    "flowNo": 3,
    "creatDate": "2021/5/18 12:36:14",
    "serialNumber": 123456,
    "street": "天山路街道",
    "flowStatus": "处置中",
    "classA": "物联感知",
    "classC": "事件名称",
    "addr": "地址"
  }, {
    "flowNo": 4,
    "creatDate": "2021/5/18 12:36:14",
    "serialNumber": 123456,
    "street": "天山路街道",
    "flowStatus": "处置中",
    "classA": "物联感知",
    "classC": "事件名称",
    "addr": "地址"
  },
  {
    "flowNo": 5,
    "creatDate": "2021/5/18 12:36:14",
    "serialNumber": 123456,
    "street": "天山路街道",
    "flowStatus": "处置中",
    "classA": "物联感知",
    "classC": "事件名称",
    "addr": "地址"
  }, {
    "flowNo": 6,
    "creatDate": "2021/5/18 12:36:14",
    "serialNumber": 123456,
    "street": "天山路街道",
    "flowStatus": "处置中",
    "classA": "物联感知",
    "classC": "事件名称",
    "addr": "地址"
  },
  {
    "flowNo": 7,
    "creatDate": "2021/5/18 12:36:14",
    "serialNumber": 123456,
    "street": "天山路街道",
    "flowStatus": "处置中",
    "classA": "物联感知",
    "classC": "事件名称",
    "addr": "地址"
  },
  // {
  //   "flowNo": 8,
  //   "creatDate": "2021/5/18 12:36:14",
  //   "serialNumber": 123456,
  //   "street": "天山路街道",
  //   "flowStatus": "处置中",
  //   "classA": "物联感知",
  //   "classC": "事件名称",
  //   "addr": "地址"
  // }
]

export default data;