import React, { Component } from 'react';
import elementResizeDetectorMaker from 'element-resize-detector';
import _ from 'lodash';

import Polymerization from '../components/AcrgisMap';

export default class Index extends Component {
    constructor(props) {
        super(props);
        this.state = {

        };
    }

    render() {
        const { region = '长宁', width = 7680, height = 2160, center, zoom, layers = {} } = this.props;
        let newLayers = {};
        if (layers) {
            Object.keys(layers).forEach(key => {
                const layerData = layers[key];

                if (layerData.points && layerData.points.length > 0) {
                    newLayers[key] = {
                        ...layerData,
                        points: layerData.points.map(p => {
                            if (p) {
                                return {
                                    ...p,
                                    pinType: key,
                                    sbzbs: Array.isArray(p.sbzbs) ? JSON.stringify(p.sbzbs) : undefined
                                }
                            }
                            return {};
                        })
                    }
                } else {
                    newLayers[key] = layerData;
                }
            });
        }

        return (
            <div style={{ width, height, position: 'relative' }}>
                <Polymerization
                    region={region}
                    data={[width, height]}
                    center={center}
                    zoom={zoom}
                    datas={newLayers}
                />
            </div>
        );
    }
}