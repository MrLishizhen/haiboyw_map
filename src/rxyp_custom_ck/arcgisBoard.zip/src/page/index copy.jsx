import React, { Component } from "react";
import redPin from "../images/redPin.png";
import orangePin from "../images/orangePin.png";
import yellowPin from "../images/yellowPin.png";
import greenPin from "../images/greenPin.png";
import cameraPin from "../images/cam.svg";

import vecPinAliceBlue from "../images/vecPinAliceBlue.png";
// import vecPinBlue from "../images/vecPinBlue.png";
import vecPinGrass from "../images/vecPinGrass.png";
import vecPinGreen from "../images/vecPinGreen.png";
import vecPinOrange from "../images/vecPinOrange.png";
import vecPinPink from "../images/vecPinPink.png";
import vecPinPurple from "../images/vecPinPurple.png";
import vecPinRed from "../images/vecPinRed.png";
import vecPinWhite from "../images/vecPinWhite.png";
import vecPinYellow from "../images/vecPinYellow.png";
import vecAlarmRed from "../images/alarmRed.png";

import ReactDOM from "react-dom";

// import AlertPopups from './AlertPopups'
import Polymerization from "../components/Polymerization3";

const keyWords = [
  {
    filter: (v) => v.type.indexOf("当前警情") >= 0,
    pinType: "dangqianjingqing",
    postData: true,
    marks: vecAlarmRed,
    defaultValue: true,
  },
  {
    filter: (v) => v.type.indexOf("消防设施物联网") >= 0,
    pinType: "xiaofangjianzhu",
    defaultValue: true,
    marks: vecPinGrass,
  },
  {
    filter: (v) => v.type.indexOf("火灾高危单位") >= 0,
    pinType: "gaoweidanwei",
    marks: vecPinPink,
  },
  {
    filter: (v) => v.type.indexOf("大型综合体") >= 0,
    pinType: "daxingzonghe",
    marks: vecPinPurple,
  },
  {
    filter: (v) => v.type.indexOf("高层建筑") >= 0,
    pinType: "gaocengjianzhu",
    marks: vecPinOrange,
  },
  {
    filter: (v) => v.type.indexOf("智能车棚") >= 0,
    pinType: "zhinengchepeng",
    marks: [vecPinWhite, vecPinGreen, vecPinRed],
    defaultValue: true,
    popup: true,
  },
  {
    filter: (v) => v.type.indexOf("消防") >= 0 && v.name.indexOf("长宁") >= 0,
    pinType: "quxiaofangjiuyuanzhan",
    marks: redPin,
  },
  {
    filter: (v) => v.type.indexOf("消防") >= 0 && v.name.indexOf("附近") >= 0,
    pinType: "fujinxiaofangzhan",
    marks: orangePin,
  },
  {
    filter: (v) => v.type.indexOf("消防") >= 0 && v.name.indexOf("企业") >= 0,
    pinType: "qiyeweixingxiaofangzhan",
    marks: greenPin,
  },
  {
    filter: (v) => v.type.indexOf("消防") >= 0 && v.name.indexOf("社区") >= 0,
    pinType: "shequweixingxiaofangzhan",
    marks: yellowPin,
  },
  {
    filter: (v) =>
      v.type.indexOf("消防栓") >= 0 && (v.name === "01" || v.name === "02"),
    pinType: "dishangxiaohuoshuan",
    marks: orangePin,
  },
  {
    filter: (v) =>
      v.type.indexOf("消防栓") >= 0 && (v.name === "11" || v.name === "12"),
    pinType: "zhinengxiaohuoshuan",
    defaultValue: true,
    marks: greenPin,
  },
  {
    filter: (v) => v.type.indexOf("积水路段") >= 0,
    pinType: "jishuiluduan",
    marks: vecPinAliceBlue,
  },
  {
    filter: (v) => v.type.indexOf("积水小区") >= 0,
    pinType: "jishuixiaoqu",
    marks: vecPinYellow,
  },
  {
    filter: (v) => v.type.indexOf("积水点位") >= 0,
    pinType: "jishuidianwei",
    marks: [vecPinWhite, vecPinGreen, vecPinRed],
    popup: true,
    defaultValue: true,
  },
  {
    filter: (v) => v.type.indexOf("视频") >= 0,
    pinType: "shipin",
    marks: cameraPin,
    markSize: 1,
  },
  {
    pinType: "buildingFFF",
    mapLayer: true,
  },
  {
    pinType: "cnBorder",
    defaultValue: true,
    mapLayer: true,
  },
];
const GRIDFLAG = "GRIDFLAG";

const PICKPOINT = "PICKPOINT";
const POSTDATA = "POSTDATA";
const SHOWNSTATE = "SHOWNSTATE";
const SHOWNSTATEARRAY = "SHOWNSTATEARRAY";
const ALARMUPDATE = "ALARMUPDATE";

const postPoints = (evt) => {
  let {
    sbbh,
    name,
    type,
    address,
    pinType,
    state,
    sbzt,
    sbztms,
    bjlx,
    bjlxhz,
    bjsj,
    szms2,
    sz3,
    ID,
  } = evt;
  let data = {
    data: {
      ID,
      sbbh,
      name,
      type,
      address,
      pinType,
      state,
      sbzt,
      sbztms,
      bjlx,
      bjlxhz,
      bjsj,
      szms2,
      sz3,
    },
    type: PICKPOINT,
    flag: GRIDFLAG,
  };
  return data;
};
export default class ArcGISMap extends Component {
  constructor(props) {
    super(props);
    this.state = {
      flag: keyWords.map((e) => e.defaultValue || false),
    };
    this.updateFlag = true;
    this.map = null;
    this.token = null;
    this.addClusters = null;
    this.alarmingData = {};

    window.addEventListener(
      "message",
      (event) => {
        if (event.data.flag && event.data.flag === GRIDFLAG) {
          console.log("frame get message", event);
        }
        if (
          event.origin === "http://bigdata.cn.gov:8070" ||
          event.origin === "http://bigdata.cn.gov:8060" ||
          event.origin === "http://localhost:7000" ||
          event.origin === "http://localhost:8000"
        ) {
          if (event.data.type === SHOWNSTATE && event.data.flag === GRIDFLAG) {
            let { pinType, data } = event.data;
            let index = keyWords.findIndex((e) => e.pinType === pinType);
            console.log(keyWords, pinType, index);
            if (index >= 0) {
              let { flag } = this.state;
              if (data) flag[index] = data;
              else flag[index] = !flag[index];
              this.setState({ flag });
              this.updateFlag = true;
              console.log("changeSuccess");
            }
            console.log(this.state.flag);
          }
          if (event.data.type === ALARMUPDATE && event.data.flag === GRIDFLAG) {
            let { pinType, data } = event.data;
            let index = keyWords.findIndex((e) => e.pinType === pinType);
            console.log(keyWords, pinType, index);
            if (index >= 0) {
              this.alarmingData[pinType] = data;
              this.updateFlag = true;
              console.log("changeSuccess");
            }
          }
          if (
            event.data.type === SHOWNSTATEARRAY &&
            event.data.flag === GRIDFLAG
          ) {
            let { checkedList, all } = event.data;
            let { flag } = this.state;
            for (let i = 0; i < flag.length; i++) {
              let { pinType: key } = keyWords[i];
              if (all.find((e) => e === key)) {
                flag[i] = !!checkedList.find((e) => e === key);
              }
            }
            this.setState({ flag });
            console.log(this.state.flag);
          }
        }
      },
      false
    );
  }

  // {"A":"延安站","B":"定西路999号","C":"121.423556","D":"31.210045999999998","E":"-4597.8876357034396","F":"-2610.5844911409799"}
  componentDidMount() {}

  componentDidUpdate() {}

  shouldComponentUpdate(nextProps) {
    return this.props.data !== nextProps.data || this.updateFlag;
  }

  getData(data) {
    if (!data) {
      return;
    }
    let pointsData = data.map((v) => ({ ...v, x: +v.X, y: +v.Y }));
    let keyWordsFilted = [];
    keyWords.forEach((e, i) => this.state.flag[i] && keyWordsFilted.push(e));
    let typedData = keyWordsFilted.map((dataProp) => {
      let ret;
      if (dataProp.filter) {
        ret = {
          ...dataProp,
          points: pointsData
            .filter(dataProp.filter)
            .map((v) => ({ ...dataProp, ...v, filter: "" })),
        };
        if (dataProp.popup) {
          ret.points = ret.points.map((e) => {
            let { sbbh, pinType } = e;
            if (
              this.alarmingData[pinType] &&
              this.alarmingData[pinType][sbbh]
            ) {
              let state = 1;
              let stateNode = this.alarmingData[pinType][sbbh];
              if (stateNode.gjjlbh) stateNode.sbztms = "报警";
              if (stateNode.sbztms === "报警") state++;
              return { ...e, state, ...stateNode };
            } else {
              return { ...e, state: 0 };
            }
          });
          ret["stateData"] = this.waterAlarming;
        }
      } else if (dataProp.mapLayer) {
        ret = { ...dataProp };
      }
      return ret;
    });
    console.log("typedData", typedData);
    return typedData;
  }

  render() {
    this.update = false;
    const style = {
      overflow: "hidden",
      width: "100%",
      height: "100%",
      zIndex: "0",
    };
    return (
      <div className="road" style={style}>
        <Polymerization
          datas={this.getData(this.props.data)}
          popup={postPoints}
          style={style}
          {...this.props}
        />
      </div>
    );
  }
}
