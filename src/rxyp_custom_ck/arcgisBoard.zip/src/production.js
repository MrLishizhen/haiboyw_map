import widget from "./App";
export default widget;
