export default function (speed = 2,startAngle=0,min = -30, max = 30 ) {
  let angle = startAngle;
  let direction = 1;
  return (t) => {
    if (angle > max) direction = -1;
    if (angle < min) direction = 1;
    angle += (speed * t * direction) / 1000;
    return angle;
  };
}
