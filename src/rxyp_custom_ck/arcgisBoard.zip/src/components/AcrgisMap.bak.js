import React, { Component } from 'react';
import esriLoader from 'esri-loader';
import _ from 'lodash';

import LayerFactory from './LayerFactory';
import jiangsuStreet from './street/jiangsu';

const VERSION = 'new';
const REGION_CONFIG = {
    // 1920*1080(1.4685)
    '联通商圈': { max_zoom: 6.3687 - 0.6, zoom_space: 0.3 * 1.4685, center: [-7955.226115764595, -2607.4065436997591], definitionExpression: undefined },
    '长宁': { max_zoom: 6.3687, zoom_space: 0.3, center: [-7955.226115764595, -2607.4065436997591], definitionExpression: undefined },
    '新华路街道': { max_zoom: 8, zoom_space: 2, center: [-3911.2464883011444, -3028.457641384611], definitionExpression: undefined },
    '江苏路街道': { max_zoom: 8, zoom_space: 2, center: [-3729.3455714651286, -1664.4720787425783], definitionExpression: `bm_code in (${jiangsuStreet.join(',')})` },
    '华阳路街道': { max_zoom: 8, zoom_space: 2, center: [-4410.534136520728, -1628.8769388048968], definitionExpression: undefined },
    '周家桥街道': { max_zoom: 8, zoom_space: 2, center: [-6568.210339344854, -1710.9496411613136], definitionExpression: undefined },
    '天山路街道': { max_zoom: 8, zoom_space: 2, center: [-6279.66060159152, -2660.809539564506], definitionExpression: undefined },
    '仙霞新村街道': { max_zoom: 8, zoom_space: 2, center: [-7703.705844577159, -2783.916420920775], definitionExpression: undefined },
    '虹桥街道': { max_zoom: 7.5, zoom_space: 2, center: [-6766.723836653108, -3852.527653110857], definitionExpression: undefined },
    '程家桥街道': { max_zoom: 8, zoom_space: 2, center: [-11306.685190375983, -4116.7789898968], definitionExpression: undefined },
    '北新泾街道': { max_zoom: 8, zoom_space: 2, center: [-9749.466318422914, -1416.401999739913], definitionExpression: undefined },
    '新泾镇': { max_zoom: 6.3687, zoom_space: 2, center: [-10849.1371812341, -1669.23172042109], definitionExpression: undefined },
};

export default class Indee extends Component {
    constructor(props) {
        super(props);
        this.state = {
            mapReady: false
        };
        this.url = 'http://bigdata.cn.gov:9070/arcgis_js_v416_api/arcgis_js_api/library/4.16/dojo/dojo.js';
        this.spatialReferencevalue = { wkid: 102100 };
        this.featureLayers = {};
    }

    /**
     * datas: 图层数据：{[pinType]:{}}
     */
    shouldComponentUpdate(nextProps, nextState) {
        // if (!_.isEqual(nextState.mapReady, this.state.mapReady) ||
        //     !_.isEqual(nextProps.datas, this.props.datas)
        // ) {
        //     const { datas = {} } = nextProps;
        //     console.info(datas);
        //     Object.keys(datas).forEach(pinType => {
        //         const layerData = datas[pinType];
        //         const { state = false } = layerData || {};

        //         if (this.featureLayers[pinType]) {
        //             if (state) {

        //             } else {

        //             }
        //         } else {
        //             this.generateFixedLayer(pinType);
        //         }
        //     });
        // }

        return !_.isEqual(nextState, this.state) || !_.isEqual(nextProps, this.props);
    }

    generateFixedLayer(pinType) {
        if (!this.state.mapReady) { return; }
        const { region, zrwg } = this.props;
        let layer = null;

        // 长宁区界
        if (pinType === 'cnBorder') {
            layer = LayerFactory.generateShadowBoundaryLayer(this.ArcGisFeatureLayer, VERSION, this.spatialReferencevalue);
        }
        // 街道
        else if (pinType === 'cnCountry') {
            if (region === '长宁' || region === '联通商圈') {
                layer = LayerFactory.generateStreetLayer(this.ArcGisFeatureLayer, VERSION, this.spatialReferencevalue);
            } else {
                layer = LayerFactory.generateStreetLayer(this.ArcGisFeatureLayer, VERSION, this.spatialReferencevalue, {
                    type: 'unique-value',
                    field: 'NAME',
                    defaultSymbol: {
                        type: 'simple-fill',
                        color: [0, 0, 0, 0.6],
                        style: 'solid',
                        outline: {
                            width: 0
                        }
                    },
                    uniqueValueInfos: [
                        {
                            value: `${region}`,
                            symbol: {
                                type: 'simple-fill',
                                color: [0, 0, 0, 0],
                                style: 'solid',
                                outline: {
                                    color: [64, 189, 255, 1],
                                    width: 2
                                }
                            }
                        }
                    ]
                });
            }
        }
        // 责任网格 
        else if (pinType === 'cnWangge') {
            if (region === '长宁' || region === '联通商圈') {
                layer = LayerFactory.generateWanggeLayer(this.ArcGisFeatureLayer, this.ArcgisLabelClass, VERSION, this.spatialReferencevalue, null, null, zrwg);
            } else {
                layer = LayerFactory.generateWanggeLayer(this.ArcGisFeatureLayer, this.ArcgisLabelClass, VERSION, this.spatialReferencevalue, null, `所属街道='${region}'`, zrwg);
            }
        }
        // 社区居委
        else if (pinType === 'cnJuwei') {
            if (region === '长宁' || region === '联通商圈') {
                layer = LayerFactory.generateJuweiLayer(this.ArcGisFeatureLayer, this.ArcgisLabelClass, VERSION, this.spatialReferencevalue);
            } else {
                layer = LayerFactory.generateWanggeLayer(this.ArcGisFeatureLayer, this.ArcgisLabelClass, VERSION, this.spatialReferencevalue, null, `所属街道='${region}'`);
            }
        }

        if (layer) {
            this.map.add(layer);
            this.featureLayers[pinType] = layer;
        }
    }

    componentDidMount() {
        const { region } = this.props;

        // window.getToken(VERSION);
        esriLoader
            .loadModules(
                [
                    'esri/config',
                    'esri/Map',
                    'esri/views/MapView',
                    'esri/views/SceneView',
                    'esri/geometry/Extent',
                    'esri/geometry/Point',
                    'esri/core/watchUtils',

                    'esri/identity/IdentityManager',
                    'esri/layers/TileLayer',
                    'esri/layers/FeatureLayer',
                    'esri/layers/GraphicsLayer',
                    'esri/layers/support/LabelClass'
                ],
                // { url: this.url }
            )
            .then(([
                esriConfig,
                Map,
                MapView,
                SceneView,
                Extent,
                Point,
                watchUtils,

                IdentityManager,
                TileLayer,
                FeatureLayer,
                GraphicsLayer,
                LabelClass
            ]) => {
                this.ArcGisPoint = Point;
                this.ArcGisFeatureLayer = FeatureLayer;
                this.ArcgisLabelClass = LabelClass;

                var CustomLayerView2D = BaseLayerViewGL2D.createSubclass({
                    aPosition: 0,
                    aOffset: 1,

                    constructor: function () {
                        this.transform = mat3.create();
                        this.translationToCenter = vec2.create();
                        this.screenTranslation = vec2.create();

                        this.display = mat3.fromValues(NaN, 0, 0, 0, NaN, 0, -1, 1, 1);
                        this.screenScaling = vec3.fromValues(NaN, NaN, 1);

                        this.needsUpdate = false;

                        var requestUpdate = function () {
                            this.needsUpdate = true;
                            this.requestRender();
                        }.bind(this);

                        this.watcher = watchUtils.on(this, 'layer.graphics', 'change', requestUpdate, requestUpdate, requestUpdate);
                    },

                    attach: function () {
                        var gl = this.context;

                        var vertexSource =
                            'precision highp float;' +
                            'uniform mat3 u_transform;' +
                            'uniform mat3 u_display;' +
                            'attribute vec2 a_position;' +
                            'attribute vec2 a_offset;' +
                            'varying vec2 v_offset;' +
                            'const float SIZE = 70.0;' +
                            'void main() {' +
                            '    gl_Position.xy = (u_display * (u_transform * vec3(a_position, 1.0) + vec3(a_offset * SIZE, 0.0))).xy;' +
                            '    gl_Position.zw = vec2(0.0, 1.0);' +
                            '    v_offset = a_offset;' +
                            '}';

                        var fragmentSource =
                            'precision highp float;' +
                            'uniform float u_current_time;' +
                            'varying vec2 v_offset;' +
                            'const float PI = 3.14159;' +
                            'const float N_RINGS = 3.0;' +
                            'const vec3 COLOR = vec3(0.23, 0.43, 0.70);' +
                            'const float FREQ = 1.0;' +
                            'void main() {' +
                            '    float l = length(v_offset);' +
                            '    float intensity = clamp(cos(l * PI), 0.0, 1.0) * clamp(cos(2.0 * PI * (l * 2.0 * N_RINGS - FREQ * u_current_time)), 0.0, 1.0);' +
                            '    gl_FragColor = vec4(COLOR * intensity, intensity);' +
                            '}';

                        var vertexShader = gl.createShader(gl.VERTEX_SHADER);
                        gl.shaderSource(vertexShader, vertexSource);
                        gl.compileShader(vertexShader);
                        var fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
                        gl.shaderSource(fragmentShader, fragmentSource);
                        gl.compileShader(fragmentShader);

                        this.program = gl.createProgram();
                        gl.attachShader(this.program, vertexShader);
                        gl.attachShader(this.program, fragmentShader);

                        gl.bindAttribLocation(this.program, this.aPosition, 'a_position');
                        gl.bindAttribLocation(this.program, this.aOffset, 'a_offset');

                        gl.linkProgram(this.program);

                        gl.deleteShader(vertexShader);
                        gl.deleteShader(fragmentShader);

                        this.uTransform = gl.getUniformLocation(this.program, 'u_transform');
                        this.uDisplay = gl.getUniformLocation(this.program, 'u_display');
                        this.uCurrentTime = gl.getUniformLocation(
                            this.program,
                            'u_current_time'
                        );

                        this.vertexBuffer = gl.createBuffer();
                        this.indexBuffer = gl.createBuffer();

                        this.indexBufferSize = 0;

                        this.centerAtLastUpdate = vec2.fromValues(
                            this.view.state.center[0],
                            this.view.state.center[1]
                        );
                    },

                    detach: function () {
                        this.watcher.remove();

                        var gl = this.context;

                        gl.deleteBuffer(this.vertexBuffer);
                        gl.deleteBuffer(this.indexBuffer);
                        gl.deleteProgram(this.program);
                    },

                    render: function (renderParameters) {
                        var gl = renderParameters.context;
                        var state = renderParameters.state;

                        this.updatePositions(renderParameters);

                        if (this.indexBufferSize === 0) {
                            return;
                        }

                        mat3.identity(this.transform);
                        this.screenTranslation[0] = (state.pixelRatio * state.size[0]) / 2;
                        this.screenTranslation[1] = (state.pixelRatio * state.size[1]) / 2;
                        mat3.translate(this.transform, this.transform, this.screenTranslation);
                        mat3.rotate(this.transform, this.transform, (Math.PI * state.rotation) / 180);
                        this.screenScaling[0] = state.pixelRatio / state.resolution;
                        this.screenScaling[1] = -state.pixelRatio / state.resolution;
                        mat3.scale(this.transform, this.transform, this.screenScaling);
                        mat3.translate(
                            this.transform,
                            this.transform,
                            this.translationToCenter
                        );

                        this.display[0] = 2 / (state.pixelRatio * state.size[0]);
                        this.display[4] = -2 / (state.pixelRatio * state.size[1]);

                        gl.useProgram(this.program);
                        gl.uniformMatrix3fv(this.uTransform, false, this.transform);
                        gl.uniformMatrix3fv(this.uDisplay, false, this.display);
                        gl.uniform1f(this.uCurrentTime, performance.now() / 1000.0);
                        gl.bindBuffer(gl.ARRAY_BUFFER, this.vertexBuffer);
                        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer);
                        gl.enableVertexAttribArray(this.aPosition);
                        gl.enableVertexAttribArray(this.aOffset);
                        gl.vertexAttribPointer(this.aPosition, 2, gl.FLOAT, false, 16, 0);
                        gl.vertexAttribPointer(this.aOffset, 2, gl.FLOAT, false, 16, 8);
                        gl.enable(gl.BLEND);
                        gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
                        gl.drawElements(gl.TRIANGLES, this.indexBufferSize, gl.UNSIGNED_SHORT, 0);

                        this.requestRender();
                    },

                    hitTest: function (x, y) {
                        var view = this.view;

                        if (this.layer.graphics.length === 0) {
                            return promiseUtils.resolve(null);
                        }

                        var distances = this.layer.graphics.map(function (graphic) {
                            var graphicPoint = view.toScreen(graphic.geometry);
                            return Math.sqrt((graphicPoint.x - x) * (graphicPoint.x - x) + (graphicPoint.y - y) * (graphicPoint.y - y));
                        });

                        var minIndex = 0;

                        distances.forEach(function (distance, i) {
                            if (distance < distances.getItemAt(minIndex)) {
                                minIndex = i;
                            }
                        });

                        var minDistance = distances.getItemAt(minIndex);

                        if (minDistance > 35) {
                            return promiseUtils.resolve(null);
                        }

                        var graphic = this.layer.graphics.getItemAt(minIndex);
                        graphic.sourceLayer = this.layer;
                        return promiseUtils.resolve(graphic);
                    },

                    updatePositions: function (renderParameters) {
                        var gl = renderParameters.context;
                        var stationary = renderParameters.stationary;
                        var state = renderParameters.state;

                        if (!stationary) {
                            vec2.sub(
                                this.translationToCenter,
                                this.centerAtLastUpdate,
                                state.center
                            );
                            this.requestRender();
                            return;
                        }

                        if (
                            !this.needsUpdate &&
                            this.translationToCenter[0] === 0 &&
                            this.translationToCenter[1] === 0
                        ) {
                            return;
                        }

                        this.centerAtLastUpdate.set(state.center);
                        this.translationToCenter[0] = 0;
                        this.translationToCenter[1] = 0;
                        this.needsUpdate = false;

                        var graphics = this.layer.graphics;

                        gl.bindBuffer(gl.ARRAY_BUFFER, this.vertexBuffer);
                        var vertexData = new Float32Array(16 * graphics.length);

                        var i = 0;
                        graphics.forEach(
                            function (graphic) {
                                var point = graphic.geometry;

                                var x = point.x - this.centerAtLastUpdate[0];
                                var y = point.y - this.centerAtLastUpdate[1];

                                vertexData[i * 16 + 0] = x;
                                vertexData[i * 16 + 1] = y;
                                vertexData[i * 16 + 2] = -0.5;
                                vertexData[i * 16 + 3] = -0.5;
                                vertexData[i * 16 + 4] = x;
                                vertexData[i * 16 + 5] = y;
                                vertexData[i * 16 + 6] = 0.5;
                                vertexData[i * 16 + 7] = -0.5;
                                vertexData[i * 16 + 8] = x;
                                vertexData[i * 16 + 9] = y;
                                vertexData[i * 16 + 10] = -0.5;
                                vertexData[i * 16 + 11] = 0.5;
                                vertexData[i * 16 + 12] = x;
                                vertexData[i * 16 + 13] = y;
                                vertexData[i * 16 + 14] = 0.5;
                                vertexData[i * 16 + 15] = 0.5;

                                ++i;
                            }.bind(this)
                        );

                        gl.bufferData(gl.ARRAY_BUFFER, vertexData, gl.STATIC_DRAW);

                        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer);

                        var indexData = new Uint16Array(6 * graphics.length);
                        for (var i = 0; i < graphics.length; ++i) {
                            indexData[i * 6 + 0] = i * 4 + 0;
                            indexData[i * 6 + 1] = i * 4 + 1;
                            indexData[i * 6 + 2] = i * 4 + 2;
                            indexData[i * 6 + 3] = i * 4 + 1;
                            indexData[i * 6 + 4] = i * 4 + 3;
                            indexData[i * 6 + 5] = i * 4 + 2;
                        }

                        gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indexData, gl.STATIC_DRAW);

                        this.indexBufferSize = indexData.length;
                    }
                });

                var CustomLayer = GraphicsLayer.createSubclass({
                    createLayerView: function (view) {
                        return new CustomLayerView2D({
                            view: view,
                            layer: this
                        });
                    }
                });

                var layer = new CustomLayer({
                    popupTemplate: {
                        title: '{NAME}',
                        content: 'Population: {POPULATION}.'
                    },
                    graphics: [
                        {
                            geometry: webMercatorUtils.geographicToWebMercator({
                                x: -118.2437,
                                y: 34.0522,
                                type: 'point',
                                spatialReference: {
                                    wkid: 4326
                                }
                            }),
                            attributes: {
                                NAME: 'Los Angeles',
                                POPULATION: 3792621
                            }
                        }
                    ]
                });

                var map = new Map({
                    basemap: 'streets-night-vector',
                    layers: [layer]
                });

                var view = new MapView({
                    container: 'arcgisContainer',
                    map: map,
                    center: [-100, 40],
                    zoom: 3
                });

                // 加载字体文件
                esriConfig.fontsUrl = 'http://10.207.204.32:9070/arcgisapi-master/fonts/arial-unicode-ms';
                // 初始化视图
                this.map = new Map({});
                // 2D
                // this.view2D = new MapView({
                //     container: 'arcgisContainer',
                //     map: this.map,
                //     center: [-7955.226115764595, -2607.4065436997591], // Longitude, latitude
                //     // center: new Point({
                //     //     x: 13225312.103694644,
                //     //     y: 4032428.0429031784,
                //     //     spatialReference: 102100
                //     // }),
                //     extent: new Extent({
                //         type: 'extent',
                //         xmax: 2116.0772399670277,
                //         xmin: -18203.963400114255,
                //         ymax: -16.55708170044818,
                //         ymin: -5731.568511723309,
                //         spatialReference: this.spatialReferencevalue
                //     }),
                //     zoom: 6.4,
                //     // constraints: {
                //     //     maxZoom: 15,
                //     //     minZoom: 11
                //     // }
                // });

                // 3D
                // this.view3D = new SceneView({
                //     container: 'arcgisContainer',
                //     map: this.map,
                //     showLabels: true,
                //     viewingMode: 'local',
                //     center: REGION_CONFIG[region] ? REGION_CONFIG[region].center : CENTER,
                //     camera: {
                //         tilt: 0,
                //         zoom: REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM
                //     },
                //     spatialReference: this.spatialReferencevalue,
                //     extent: new Extent({
                //         type: 'extent',
                //         xmax: 2116.0772399670277,
                //         xmin: -18203.963400114255,
                //         ymax: -16.55708170044818,
                //         ymin: -5731.568511723309,
                //         spatialReference: this.spatialReferencevalue,
                //     }),
                //     sliderPosition: 'bottom-right',
                //     sliderOrientation: 'horizontal',
                //     zoom: REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM,
                //     qualityProfile: 'high',
                //     environment: {
                //         background: {
                //             type: 'color',
                //             color: [0, 0, 0, 0],
                //         },
                //         starsEnabled: false,
                //         atmosphereEnabled: false,
                //     },
                //     highlightOptions: {
                //         color: [64, 189, 255, 1],
                //         haloOpacity: 0.8
                //     }
                // });

                // const token = document.getElementById('txtToken').value;
                // IdentityManager.registerToken({
                //     server: VERSION === 'new' ? 'http://10.89.5.191/OneMapServer/rest/services' : 'http://map.cn.gov/OneMapServer/rest/services',
                //     token,
                // });

                // const baseLayer = new TileLayer({
                //     url: VERSION === 'new' ? 'http://10.89.5.191/OneMapServer/rest/services/shmw2bigsize_blueblack/MapServer' : 'http://10.207.204.19/server/rest/services/BIGANSE2/MapServer',
                //     id: 'baseLayer',
                // });
                // const maskBoundary = LayerFactory.generateMaskBoundaryLayer(FeatureLayer, VERSION, this.spatialReferencevalue);

                // this.map.add(baseLayer);
                // this.map.add(maskBoundary);

                // this.watchViewCreated(this.view3D, watchUtils);

                // this.appConfig = {
                //     mapView: null,
                //     sceneView: null,
                //     activeView: null,
                // };

                // this.map = new Map({
                //     basemap: 'topo-vector'
                // });

                // // this.view3D.when(() => {
                // //     console.log('view3D create success.');

                // //     watchUtils.whenTrue(this.view3D, 'stationary', () => {
                // //         console.info(this.view3D);
                // //     });
                // // });

                // // this.view3D = new SceneView({
                // //     map: this.map,
                // //     camera: {
                // //         position: {
                // //             x: -118.80,
                // //             y: 34.02,
                // //             z: 120000 // meters
                // //         },
                // //         tilt: 0
                // //     },
                // //     zoom: 11,
                // //     // container: 'arcgisContainer'
                // // });

                // // this.appConfig.mapView = this.view2D;
                // // this.appConfig.activeView = this.appConfig.mapView;
                // // this.appConfig.sceneView = this.view3D

                // // this.view2D.when(() => {
                // //     console.log('view2D create success.');

                // //     watchUtils.whenTrue(this.view2D, 'stationary', () => {
                // //         const { center = {}, zoom, scale } = this.view2D;
                // //         console.log(
                // //             'view2D data：',
                // //             { longitude: center.longitude, latitude: center.latitude },
                // //             { x: center.x, y: center.y },
                // //             scale,
                // //             zoom,
                // //             this.view2D
                // //         );
                // //     });

                // //     this.view2D.popup.autoOpenEnabled = false;
                // //     this.view2D.on('click', (event) => {
                // //         this.view2D.hitTest(event).then((result) => {
                // //             console.log('view2D click data：', result);
                // //             const { results = [], screenPoint = {} } = result;
                // //             const point = results[0] || {};
                // //             const { graphic = {}, mapPoint = {} } = point;
                // //             const { attributes } = graphic;

                // //             if (!attributes || !attributes.pinType) {
                // //                 console.log('invailed point', attributes);
                // //                 this.view2D.popup.visible = false;
                // //             }
                // //         });
                // //     });

                // //     this.setState({ mapReady: true });
                // // });

                // var featureLayer = new FeatureLayer({
                //     url: 'https://services3.arcgis.com/GVgbJbqm8hXASVYi/arcgis/rest/services/Trailheads_Styled/FeatureServer/0',
                // });
                // this.map.add(featureLayer);
            });
    }

    watchViewCreated(view, watchUtils) {
        if (view) {
            const { type } = view;

            view.when(() => {
                console.log(`view${type} create success.`);
                view.qualitySettings.memoryLimit = 4096;
                this.resetCamera(view, 3000);

                watchUtils.whenTrue(view, 'stationary', () => {
                    const { center = {}, zoom, scale } = view;
                    console.log(
                        `view${type} data：`,
                        { longitude: center.longitude, latitude: center.latitude },
                        { x: center.x, y: center.y }, scale, zoom, view
                    );
                });

                view.popup.autoOpenEnabled = false;
                view.on('click', (event) => {
                    view.hitTest(event).then((result) => {
                        console.log(`view${type} click data：`, result);
                        const { results = [], screenPoint = {} } = result;
                        const point = results[0] || {};
                        const { graphic = {}, mapPoint = {} } = point;
                        const { attributes } = graphic;

                        if (!attributes || !attributes.pinType) {
                            console.log('invailed point', attributes);
                            view.popup.visible = false;
                        }
                    });
                });

                this.setState({ mapReady: true });
            });
        }
    }

    resetCamera(view, t = 1000) {
        const { region = '长宁' } = this.props;

        this.endRotate();
        view
            .goTo(
                {
                    tilt: 0,
                    position: new this.ArcGisPoint({
                        x: (REGION_CONFIG[region] ? REGION_CONFIG[region].center : CENTER)[0],
                        y: (REGION_CONFIG[region] ? REGION_CONFIG[region].center : CENTER)[1],
                        spatialReference: this.spatialReferencevalue,
                    }),
                    zoom: REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM,
                },
                { duration: t }
            )
            .then(() => {
                view.goTo({ zoom: REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM }, { duration: t });
            });
    }

    endRotate() {
        console.log('endRotate');
        clearInterval(this.rotationInterval);
        clearTimeout(this.rotationTimeout);
        this.rotationTimeout = 0;
        this.rotationInterval = 0;
    }

    // switchView() {
    //     var is3D = this.appConfig.activeView.type === '3d';
    //     var activeViewpoint = this.appConfig.activeView.viewpoint.clone();

    //     this.appConfig.activeView.container = null;

    //     if (is3D) {
    //         this.appConfig.mapView.viewpoint = activeViewpoint;
    //         this.appConfig.mapView.container = 'arcgisContainer';
    //         this.appConfig.activeView = this.appConfig.mapView;
    //     } else {
    //         this.appConfig.sceneView.viewpoint = activeViewpoint;
    //         this.appConfig.sceneView.container = 'arcgisContainer';
    //         this.appConfig.activeView = this.appConfig.sceneView;
    //     }
    // }

    render() {
        console.info(this.props);

        return (
            <div
                id='arcgisContainer'
                style={{ width: '100%', height: '100%', margin: 0, padding: 0 }}
            >
                {/* <button onClick={this.switchView.bind(this)}>3D</button> */}
            </div>

        );
    }
}