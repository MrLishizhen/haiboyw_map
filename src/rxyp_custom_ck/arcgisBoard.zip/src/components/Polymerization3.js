import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import esriLoader from 'esri-loader';
import _ from 'lodash';

import LayerFactory from './LayerFactory';
import jiangsuStreet from './street/jiangsu';

import "./popup.css";
import "./popups/school.css";
import "./popups/newPopUp.css";

import popDefault from "./popups/default";
import popSchool from "./popups/school";
import newPopUp from "./popups/newPopUp";
import popImage from "./popups/popImage"

import roadOcc from "../images/vecPinWhite.png";

import camRotation from "../featureTools/camRotation";

const VERSION = 'new';

const DEVELOPING = process.env.NODE_ENV === "production";
const layers = [
  "YLJG",
  "SCHOOL",
  "LSWHBH",
  "BMSS",
  "LSWHFMQ",
  "FMBHJF",
  // "FMBHDL",
  "WWBHXX",
  "YXLSJZ",
  "WHCG",
];

const REGION_CONFIG = {
  // 1920*1080(1.4685)
  '联通商圈': { max_zoom: 6.3687 - 0.6, zoom_space: 0.3 * 1.4685, center: [-7955.226115764595, -2607.4065436997591], definitionExpression: undefined },
  '长宁': { max_zoom: 6.3687, zoom_space: 0.3, center: [-7955.226115764595, -2607.4065436997591], definitionExpression: undefined },
  '新华路街道': { max_zoom: 8, zoom_space: 2, center: [-3911.2464883011444, -3028.457641384611], definitionExpression: undefined },
  '江苏路街道': { max_zoom: 8, zoom_space: 2, center: [-3729.3455714651286, -1664.4720787425783], definitionExpression: `bm_code in (${jiangsuStreet.join(',')})` },
  '华阳路街道': { max_zoom: 8, zoom_space: 2, center: [-4410.534136520728, -1628.8769388048968], definitionExpression: undefined },
  '周家桥街道': { max_zoom: 8, zoom_space: 2, center: [-6568.210339344854, -1710.9496411613136], definitionExpression: undefined },
  '天山路街道': { max_zoom: 8, zoom_space: 2, center: [-6279.66060159152, -2660.809539564506], definitionExpression: undefined },
  '仙霞新村街道': { max_zoom: 8, zoom_space: 2, center: [-7703.705844577159, -2783.916420920775], definitionExpression: undefined },
  '虹桥街道': { max_zoom: 7.5, zoom_space: 2, center: [-6766.723836653108, -3852.527653110857], definitionExpression: undefined },
  '程家桥街道': { max_zoom: 8, zoom_space: 2, center: [-11306.685190375983, -4116.7789898968], definitionExpression: undefined },
  '北新泾街道': { max_zoom: 8, zoom_space: 2, center: [-9749.466318422914, -1416.401999739913], definitionExpression: undefined },
  '新泾镇': { max_zoom: 6.3687, zoom_space: 2, center: [-10849.1371812341, -1669.23172042109], definitionExpression: undefined },
}

// 长宁区缩放比例 
const MAX_ZOOM = 6.3687,
  // 卫监缩放比例 
  // const MAX_ZOOM = 6.3687 - 0.2,
  // 长宁区缩放比例 1920*1080
  // const MAX_ZOOM = 6.3687 - 1,
  ZOOM_SPACE = 0.3;
// 江苏路街镇缩放比例
// const MAX_ZOOM = 8,
//   ZOOM_SPACE = 2;

const markHeights = 200,
  defaultZoom = MAX_ZOOM,
  rotateZoom = 6.736,
  defaultTilt = 0,
  rotateTilt = 47.58521,
  defaultRotationSpeed = 1;
// 长宁区中心点  
let CENTER = [-7955.226115764595, -2607.4065436997591];
// 长宁区中心点-卫监  
// let CENTER = [-5984.812475795292, -2294.207155595077];
// 长宁区中心点 1920*1080
// let CENTER = [-8298.346910308344, -1903.1878301480851];
// 江苏路街镇中心点
// let CENTER = [-3729.3455714651286, -1664.4720787425783];
let ROAD_CENTER = {
  '新华路街道': { center: [-3379.1545703995307, -3118.771479718119], zoom: MAX_ZOOM + 1.5 },
  '江苏路街道': { center: [-3729.3455714651286, -1664.4720787425783], zoom: MAX_ZOOM + 1.5 },
  '华阳路街道': { center: [-3839.160267635518, -1662.7358845756294], zoom: MAX_ZOOM + 1.5 },
  '周家桥街道': { center: [-6343.880012965901, -1715.1904596231682], zoom: MAX_ZOOM + 1.5 },
  '天山路街道': { center: [-5753.775087857433, -2606.6545304982983], zoom: MAX_ZOOM + 1.5 },
  '仙霞新村街道': { center: [-7183.090464926783, -2724.673356813347], zoom: MAX_ZOOM + 1.5 },
  '虹桥街道': { center: [-6239.358239386647, -4009.3441067792896], zoom: MAX_ZOOM + 1.5 },
  '程家桥街道': { center: [-10290.922835500976, -4061.7798189898117], zoom: MAX_ZOOM + 1.5 },
  '北新泾街道': { center: [-9478.627826303737, -1467.1741391144164], zoom: MAX_ZOOM + 1.5 },
  '新泾镇': { center: [-9806.61756012832, -1060.9489468143356], zoom: MAX_ZOOM + 1.5 },
  // '虹桥临空园区': []
}

let CENTERDEFAULT = [-8155.226115764595, -1807.4065436997591];

export default class Polymerization extends Component {
  constructor(props) {
    super(props);
    this.popup = props.popup;
    this.ref = null;
    this.spatialReferencevalue = { wkid: 102100 };
    this.url =
      "http://bigdata.cn.gov:9070/arcgis_js_v410_sdk/arcgis_js_api/library/4.10/dojo/dojo.js";
    this.ArcGisGraphic = null;
    this.featureLayers = {};
    this.newFatureLayers = {};
    this.timer = {};
    this.newTmpData = {};
    this.tiltLayers = {};
    this.gridRatio = 100;
    this.view = null;
    this.popPinType = "";
    this.cameraModifyed = false;
    this.state = {
      mapReady: false,
    };
    this.viewsize = { width: 0, height: 0 };
    this.pointsObj = [];
    this.intervals = [];
    this.rotationInterval = 0;
    this.rotationTimeout = 0;
  }

  /**
   *
   * @param {[ { points:[{x:number,y:number}],popup:function(index):void,marks:{type:string,url:image,width:string,height:string} }]} datas
   */
  cluster(datas) {
    console.log('clusting', this.state.mapReady);
    if (!(this.state.mapReady && datas)) {
      return;
    }

    for (let k in this.featureLayers) {
      let layers = this.featureLayers[k];
      if (Array.isArray(layers)) layers.forEach((e) => (e.visible = false));
      else layers.visible = false;
    }

    function defaultMarks() {
      return {
        type: "picture-marker",
        url: roadOcc,
        width: "80px",
        height: "80px",
      };
    }

    function defaultText(text, color) {
      return {
        type: "text", // autocasts as new TextSymbol()
        color: "white",
        backgroundColor: color,
        borderLineColor: "white",
        haloColor: color,
        haloSize: 10,
        text: text,
        font: {
          size: 26,
          weight: "bold",
        },
      };
    }

    let makePoints = (datas, marks) => {
      console.log("arcgisMap marks :", datas, marks);
      let defaultMark = defaultMarks();
      let points = datas.map((e) => {
        let mark;
        let statePos = 0;
        let { levels, sbzb, gjjlbh, sbztms } = e;
        sbzb = sbzb === "" ? 0 : +sbzb;
        if (marks && Array.isArray(marks)) {
          let markArray = marks.map((m) => {
            return {
              ...defaultMark,
              url: m,
            };
          });
          if (levels) {
            levels = JSON.parse(levels);
            if (sbzb < levels[0]) statePos = 2;
            if (sbzb > levels[1]) statePos = 1;
          } else {
            if (gjjlbh) statePos = 2;
            else if (sbztms) statePos = 1;
          }
          mark = markArray[statePos];
        } else if (marks) {
          mark = { ...defaultMark, url: e.icon ? e.icon : marks };
        } else {
          let color = "#ffbb44";
          if (levels) {
            levels = JSON.parse(levels);
            if (sbzb < levels[0]) color = "#e02222";
            if (sbzb > levels[1]) color = "green";
          }
          mark = defaultText(e.attributes.name, color);
        }
        const infoJSON = JSON.stringify(e.attributes);
        return new this.ArcGisGraphic({
          attributes: { ...e.attributes, statePos, infoJSON },
          geometry: {
            type: "point",
            x: +(e.x || e.X),
            y: +(e.y || e.Y),
            z: markHeights,
            spatialReference: this.spatialReferencevalue,
          },
          symbol: mark,
        });
      });
      console.log("arcgisMap Graphics :", points);
      return points;
    };

    let drawPopup = (datas, marks) => {
      let points = makePoints(datas, marks);
      this.view.graphics.addMany(points);
      return points;
    };

    let drawCluster = (grids, icon, dataIcons, flash = false) => {
      console.info('clusting drawCluster', grids, icon, dataIcons);
      let points = makePoints(grids, icon ? icon : roadOcc);
      const attr = points[0].attributes;
      const pinType = attr.pinType;
      attr.infoJSON = JSON.stringify(attr);
      console.info('clusting drawCluster points', flash, points);

      let render = undefined;
      if (Array.isArray(icon)) {
        render = {
          type: "unique-value",
          field: "statePos",
          defaultSymbol: { ...defaultMarks(), url: roadOcc },
          uniqueValueInfos: [
            {
              value: 0,
              symbol: {
                type: "point-3d", // autocasts as new PointSymbol3D()
                symbolLayers: [
                  {
                    type: "icon", // autocasts as new IconSymbol3DLayer()
                    resource: {
                      href: icon[0] || roadOcc,
                    },
                    size: 60,
                  },
                ],
              },
            },
            {
              value: 1,
              symbol: {
                type: "point-3d", // autocasts as new PointSymbol3D()
                symbolLayers: [
                  {
                    type: "icon", // autocasts as new IconSymbol3DLayer()
                    resource: {
                      href: icon[1],
                    },
                    size: 60,
                  },
                ],
              },
            },
            {
              value: 2,
              symbol: {
                type: "point-3d", // autocasts as new PointSymbol3D()
                symbolLayers: [
                  {
                    type: "icon", // autocasts as new IconSymbol3DLayer()
                    resource: {
                      href: icon[2],
                    },
                    size: 60,
                  },
                ],
              },
            },
          ],
        };
      } else {
        if (dataIcons && dataIcons.length > 0) {
          render = {
            type: "unique-value",
            field: "icon",
            defaultSymbol: { ...defaultMarks(), url: icon || roadOcc },
            uniqueValueInfos: dataIcons.map(i => ({
              value: i,
              symbol: {
                type: "picture-marker",
                url: i,
                width: "80px",
                height: "80px",
              },
            }))
          }
        } else {
          render = {
            type: "simple",
            symbol: { ...defaultMarks(), url: icon || roadOcc },
          };
        }
      }

      if (!this.featureLayers[pinType]) {
        let mainLayer = null;
        if (flash) {
          mainLayer = new this.ArcGisGraphicsLayer({
            graphics: points
          });
        } else {
          mainLayer = new this.ArcGisFeatureLayer({
            source: points,
            objectIdField: "OBJECTID",
            //所有显示的属性都需要添加
            fields: [
              { name: "OBJECTID", alias: "OBJECTID", type: "oid" },
              { name: "sbbh", alias: "sbbh", type: "string" },
              { name: "name", alias: "name", type: "string" },
              { name: "type", alias: "type", type: "string" },
              { name: "address", alias: "address", type: "string" },
              { name: "pinType", alias: "pinType", type: "string" },
              { name: "schooltype", alias: "schooltype", type: "string" },
              { name: "state", alias: "state", type: "string" },
              { name: "popup", alias: "popup", type: "string" },
              { name: "sbzbs", alias: "sbzbs", type: "string" },
              { name: "sbztms", alias: "sbztms", type: "string" },
              { name: "statePos", alias: "statePos", type: "small-integer" },
              { name: "infoJSON", alias: "infoJSON", type: "string" },
              { name: "icon", alias: "icon", type: "string" },
            ],
            outFields: ["*"],
            geometryType: "point",
            elevationInfo: { mode: "relative-to-scene" },
            renderer: render,
          });
          if (render) {
            mainLayer.renderer = render;
          }
        }
        this.map.add(mainLayer);
        this.featureLayers[pinType] = mainLayer;
      } else {
        let layer = this.featureLayers[pinType];
        if (render) {
          layer.renderer = render;
        }
        layer.visible = true;
        if (attr.graphicType !== "tile") {
          if (flash) {
            layer.graphic = points;
          } else {
            layer.source = points;
          }
        }
        layer.refresh();
      }

      // 闪烁
      if (flash) {
        const graphics = this.featureLayers[pinType].graphics;

        if (graphics && graphics.items) {
          if (this.timer[pinType]) {
            clearInterval(this.timer[pinType]);
          }
          const timer = setInterval(() => {
            if (!this.featureLayers[pinType].visible) {
              graphics.items.forEach(item => {
                item.visible = false;
              });
              if (this.timer[pinType]) {
                clearInterval(this.timer[pinType]);
              }
            } else {
              graphics.items.forEach(item => {
                if (item.visible) {
                  item.visible = false;
                } else {
                  item.visible = true;
                }
              });
            }
          }, 1000);
          this.timer[pinType] = timer;
        }
      }
      return [];
    };

    let clustPoints = (grids, pointsData) => {
      var webExtent = this.view.extent;
      pointsData.forEach((e, i) => {
        if (
          e.x <= webExtent.xmin ||
          e.x > webExtent.xmax ||
          e.y <= webExtent.ymin ||
          e.y > webExtent.ymax
        ) {
          return;
        }
        var xVal = e.x,
          yVal = e.y;
        for (var j = 0, jLen = grids.length; j < jLen; j++) {
          var cl = grids[j];
          if (
            e.x <= cl.extent.xmin ||
            e.x > cl.extent.xmax ||
            e.y <= cl.extent.ymin ||
            e.y > cl.extent.ymax
          ) {
            continue;
          }
          cl.x =
            cl.clusterCount > 0
              ? (xVal + cl.x * cl.clusterCount) / (cl.clusterCount + 1)
              : xVal;
          cl.y =
            cl.clusterCount > 0
              ? (yVal + cl.y * cl.clusterCount) / (cl.clusterCount + 1)
              : yVal;
          cl.attributes = e;
          cl.points.push([xVal, yVal, e]);
          cl.clusterCount++;

          break;
        }
      });
      return grids;
    };

    let generateGrid = () => {
      var xCount = Math.round(this.view.width / this.gridRatio);
      var yCount = Math.round(this.view.height / this.gridRatio);
      var xw = (this.view.extent.xmax - this.view.extent.xmin) / xCount;
      var yh = (this.view.extent.ymax - this.view.extent.ymin) / yCount;
      var gsxmin, gsxmax, gsymin, gsymax;
      var grids = [];
      for (var i = 0; i < xCount; i++) {
        gsxmin = this.view.extent.xmin + xw * i;
        gsxmax = gsxmin + xw;
        for (var j = 0; j < yCount; j++) {
          gsymin = this.view.extent.ymin + yh * j;
          gsymax = gsymin + yh;
          var ext = {
            xmin: gsxmin,
            xmax: gsxmax,
            ymin: gsymin,
            ymax: gsymax,
          };
          grids.push({
            extent: ext,
            clusterCount: 0,
            subTypeCounts: [],
            singles: [],
            points: [],
            x: 0,
            y: 0,
          });
        }
      }
      return grids;
    };

    let mapPointsData = (pointsData, addons, dataIcons) => {
      return pointsData.map((e) => {
        if (e.icon && !dataIcons.includes(e.icon)) {
          dataIcons.push(e.icon);
        }
        return {
          ...e,
          ...addons,
          icon: e.icon ? e.icon : addons.icon,
          popup: e.popup ? e.popup : addons.popup,
          attributes: { ...e, ...addons, icon: e.icon ? e.icon : addons.icon, popup: e.popup ? e.popup : addons.popup },
        }
      });
    };

    this.view.graphics.removeMany(this.pointsObj);
    this.pointsObj = [];
    for (let i in datas) {
      console.log('clusting', i, datas[i]);
      if (datas[i].state) {
        if (datas[i].points && datas[i].points.length > 0) {
          let e = datas[i];
          let { params } = e;
          let pointsData;
          let dataIcons = [];
          // pointsData = clustPoints(generateGrid(), e.points);
          pointsData = mapPointsData(e.points, { pinType: i, ...params }, dataIcons);
          console.log('clusting pointsData', pointsData, e);
          if (e.graphicType === 'graphic') {
            this.pointsObj = this.pointsObj.concat(
              drawPopup(pointsData, e.marks)
            );
          } else {
            this.pointsObj = this.pointsObj.concat(
              drawCluster(pointsData, e.marks, dataIcons, params.flash)
            );
          }
        } else {
          if (this.featureLayers[datas[i].pinType]) {
            let layers = this.featureLayers[datas[i].pinType];
            if (Array.isArray(layers))
              layers.forEach((e) => (e.visible = true));
            else layers.visible = true;
          }
        }
      }
    }
  }

  onResize() {
    const mapdiv = document.getElementById("mapDiv");
    const { height, width } = mapdiv.getBoundingClientRect();
    const viewWidth = this.props.data[0],
      viewHeight = this.props.data[1];
    this.viewsize = { height: viewHeight / height, width: viewWidth / width };
    console.log(this.viewsize, viewWidth, viewHeight);
  }

  arcgisPopup(data, mapPoint) {
    let dom = document.createElement("div");
    dom.style = "height: 100%";
    try {
      switch (data.popup) {
        case "click4":
          dom = popImage(dom, data);
          break;
        case "click3":
          dom = newPopUp(dom, data);
          break;
        case "click2":
          dom = popSchool(dom, data);
          break;
        default:
          dom = popDefault(dom, data);
          break;
      }
      this.view.popup.open({
        location: mapPoint,
        content: dom,
      });
      this.popPinType = data.pinType;
    } catch (e) {
      console.log("popupERROR", e);
    }
    console.log("POPUP", data);
  }

  pauseRotate(time = 5000) {
    if (this.rotationInterval !== 0) {
      this.endRotate();
      this.rotationTimeout = setTimeout(
        () => this.startRotate(this.view.camera.heading),
        time
      );
    }
  }

  startRotate(angle = 0) {
    if (this.rotationInterval !== 0) {
      clearInterval(this.rotationInterval);
    }
    console.log("start");
    let camRotCtrl = camRotation(defaultRotationSpeed, angle);
    const delta = 200;
    this.rotationInterval = setInterval(() => {
      let heading = camRotCtrl(delta);
      this.view.goTo(
        {
          heading: heading,
          tilt: rotateTilt,
          zoom: rotateZoom,
        },
        { duration: delta }
      );
      console.log("heading", heading);
    }, delta);
  }

  endRotate() {
    console.log("end");
    clearInterval(this.rotationInterval);
    clearTimeout(this.rotationTimeout);
    this.rotationTimeout = 0;
    this.rotationInterval = 0;
  }

  cameraFocuse(params, region = '长宁') {
    this.endRotate();
    this.view &&
      this.state.mapReady &&
      this.view
        .goTo(
          {
            tilt: params.tilt || defaultTilt,
            position: new this.ArcGisPoint({
              x: +params.X,
              y: +params.Y,
              spatialReference: this.spatialReferencevalue,
            }),
            zoom: params.zoom || (REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM),
            heading: params.heading || 0,
          },
          { duration: 500 }
        )
        .then(() => {
          this.view.goTo(
            { zoom: params.zoom || (REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM) },
            { duration: 500 }
          );
        });
  }

  resetCamera(t = 1000, region = '长宁') {
    this.endRotate();
    this.view
      .goTo(
        {
          tilt: defaultTilt,
          position: new this.ArcGisPoint({
            x: (REGION_CONFIG[region] ? REGION_CONFIG[region].center : CENTER)[0],
            y: (REGION_CONFIG[region] ? REGION_CONFIG[region].center : CENTER)[1],
            spatialReference: this.spatialReferencevalue,
          }),
          zoom: REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM,
        },
        { duration: t }
      )
      .then(() => {
        this.view.goTo({ zoom: REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM }, { duration: t });
      });
  }

  componentDidUpdate() {
    this.cluster(this.props.datas, this.props.region);
    this.generateLayer(this.props.layersData, this.props.region);
    this.changeCenter(this.props.mapCenter, this.props.region);
    const wangge = this.props.datas['cnWangge'] || {};
    if (wangge.state && !this.view.popup.autoOpenEnabled) {
      this.view.popup.autoOpenEnabled = true;
    }
    if (this.props.datas.length > 0 && this.state.mapReady) {
      if (
        !this.props.datas.find((e) => e.pinType === this.popPinType && e.state)
      ) {
        this.view.popup.visible = false;
        this.popPinType = "";
      }
    }
    if (this.props.camerainfo && this.view) {
      let { camerainfo } = this.props;
      console.log(camerainfo);
      this.view.center = new this.ArcGisPoint(camerainfo.center);
      this.view.zoom = camerainfo.zoom;
    }
    this.pauseRotate(2000, this.props.region);
  }

  changeCenter(road, region = '长宁') {
    // 长宁边界
    const cnBorder = this.featureLayers['cnBorder'];
    // 长宁区街道
    const cnCountry = this.featureLayers['cnCountry'];

    if (cnBorder && cnCountry && road) {
      if (road !== 'all') {
        const roadData = ROAD_CENTER[road];

        if (roadData) {
          cnBorder.visible = false;
          cnCountry.visible = true;
          // cnCountry.definitionExpression = `NAME='${road}'`
          cnCountry.renderer = {
            type: 'unique-value',
            field: 'NAME',
            defaultSymbol: {
              type: 'simple-fill',
              color: [0, 0, 0, 0.6],
              style: 'solid',
              outline: {
                width: 0
              }
            },
            uniqueValueInfos: [
              {
                value: road,
                symbol: {
                  type: 'simple-line',
                  width: 2,
                  color: [64, 189, 255, 1],
                  style: 'solid',
                }
              }
            ]
          };
          cnCountry.refresh();

          this.view.zoom = roadData.zoom;
          this.view.goTo(
            new this.ArcGisPoint({
              x: roadData.center[0],
              y: roadData.center[1],
              spatialReference: this.spatialReferencevalue,
            })
          );
        }
      } else {
        cnBorder.visible = true;
        cnCountry.visible = false;
        // cnCountry.definitionExpression = `'1'='1'`;
        cnCountry.renderer = {
          type: 'simple',
          symbol: {
            type: 'simple-line',
            width: 1,
            color: [200, 255, 200, 1],
            style: 'solid',
          }
        };
        cnCountry.refresh();

        this.view.zoom = REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM;
        this.view.goTo(
          new this.ArcGisPoint({
            x: (REGION_CONFIG[region] ? REGION_CONFIG[region].center : CENTER)[0],
            y: (REGION_CONFIG[region] ? REGION_CONFIG[region].center : CENTER)[1],
            spatialReference: this.spatialReferencevalue,
          })
        );
      }
      this.road = road;
    }
  }

  generateLayer(list, region = '长宁') {
    const keys = Object.keys(list);

    if (!this.state.mapReady) {
      return;
    }

    keys.forEach(key => {
      const { data, state } = list[key];

      if (state) {
        if (key === 'road') {
          const features = VERSION === 'new' ?
            [
              { url: 'http://10.89.5.191/OneMapServer/rest/services/JTLL_DMDL/MapServer/4', title: '地面主干道路发布段_二级显示 (4)', id: 'ROAD_DM_4', visible: [0, 9] },
              { url: 'http://10.89.5.191/OneMapServer/rest/services/JTLL_DMDL/MapServer/1', title: '地面主干道路发布段_二级显示 (1)', id: 'ROAD_DM_1', visible: [0, 9] },
              // { url: 'http://10.89.5.191/OneMapServer/rest/services/JTLL_DMDL/MapServer/1', title: '地面主干道路发布段_一级显示 (0)', id: 'ROAD_DM_0', visible: [0, 9] },
              { url: 'http://10.89.5.191/OneMapServer/rest/services/JTLL_DMDL/MapServer/2', title: '地面主干道路发布段 (2)', id: 'ROAD_DM_2', visible: [9, Infinity] },
              { url: 'http://10.89.5.191/OneMapServer/rest/services/JTLL_DMDL/MapServer/3', title: '地面次干道路发布段 (3)', id: 'ROAD_DM_3', visible: [9, Infinity] },
              { url: 'http://10.89.5.191/OneMapServer/rest/services/JTLL_DMDL/MapServer/5', title: '地面次干道路发布段 (5)', id: 'ROAD_DM_4', visible: [9, Infinity] },
              // { url: 'http://10.89.5.191/OneMapServer/rest/services/JTLL_DMDL/MapServer/5', title: '地面主干道路发布段_全景显示 (6)', id: 'ROAD_DM_6', visible: [9, Infinity] }
            ] :
            [
              { url: 'http://10.207.204.19/server/rest/services/ROAD_DM/MapServer/7', title: '地面次干道路发布段_二级显示 (7)', id: 'ROAD_DM_7', visible: [0, 9] },
              { url: 'http://10.207.204.19/server/rest/services/ROAD_DM/FeatureServer/4', title: '地面次干道路发布段_二级显示 (4)', id: 'ROAD_DM_4', visible: [0, 9] },
              { url: 'http://10.207.204.19/server/rest/services/ROAD_DM/FeatureServer/8', title: '地面一般道路发布段 (8)', id: 'ROAD_DM_8', visible: [9, Infinity] },
              { url: 'http://10.207.204.19/server/rest/services/ROAD_DM/FeatureServer/6', title: '地面次干道路发布段 (6)', id: 'ROAD_DM_6', visible: [9, Infinity] },
              { url: 'http://10.207.204.19/server/rest/services/ROAD_DM/FeatureServer/5', title: '地面次干道路发布段 (5)', id: 'ROAD_DM_5', visible: [9, Infinity] }
            ];
          const renderer = {
            type: 'unique-value',
            field: 'bm_code',
            defaultSymbol: { type: 'simple-fill', color: '#38A800', outline: { width: 0 } },
            uniqueValueInfos: Object.keys(data).map(bmCode => {
              return ({
                value: bmCode + '',
                symbol: {
                  type: 'simple-fill',
                  color: data[bmCode] === '21' ? 'rgb(48, 168, 91)' :
                    data[bmCode] === '22' ? '#FFCF00' :
                      data[bmCode] === '23' ? '#E60000' :
                        data[bmCode] === '25' ? '#9C9C9C' :
                          '#38A800',
                  outline: { color: '#002F47', join: 'round', width: 0 }
                }
              });
            })
          };
          // 开始不存在，初始化图层
          if (!this.newFatureLayers[key]) {
            // 长宁
            const definitionExpression = REGION_CONFIG[region] ? REGION_CONFIG[region].definitionExpression : undefined;
            // 江苏街道
            // const definitionExpression = `bm_code in (${jiangsuStreet.join(',')})`;
            const roads = features.map(item => {
              const road = new this.ArcGisFeatureLayer({
                url: item.url,
                renderer,
                minScale: 0,
                maxScale: 0,
                spatialReference: this.spatialReferencevalue,
                title: item.title,
                visible: item.visible[0] <= (this.view.zoom || (REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM)) && (this.view.zoom || (REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM)) < item.visible[1],
                outFields: ['*'],
                popupTemplate: {
                  'title': '',
                  'content': `
                    <div class='cn_arcgis_popup_school'>
                      <div class='cn_arcgis_popup_school_title'>{路名}</div>
                      <div class='cn_arcgis_popup_school_info'>
                        <div class='cn_arcgis_popup_school_infotab'>
                          <div class='cn_arcgis_popup_type' style='width:200px'>起点交叉路</div>
                          <div class='cn_arcgis_popup_value' style='min-width:240px'>{起点交叉路}</div>
                        </div>
                        <div class='cn_arcgis_popup_school_infotab'>
                          <div class='cn_arcgis_popup_type' style='width:200px'>终点交叉路</div>
                          <div class='cn_arcgis_popup_value' style='min-width:240px'>{终点交叉路}</div>
                        </div>
                      </div>
                    </div>
                  `
                },
                definitionExpression
              });
              this.map.add(road);
              return { visible: item.visible, layer: road }
            });
            this.view.popup.autoOpenEnabled = true;
            this.newFatureLayers[key] = roads;
            this.newTmpData[key] = data;
          } else {
            if (!_.isEqual(this.newTmpData[key], data)) {
              console.info('update')
              if (Array.isArray(this.newFatureLayers[key]) && this.newFatureLayers[key].length > 0) {
                this.newFatureLayers[key].forEach(item => {
                  const { layer } = item;
                  if (layer) {
                    layer.renderer = renderer;
                    layer.refresh();
                  }
                });
              } else if (this.newFatureLayers[key]) {
                this.newFatureLayers[key].renderer = renderer;
                this.newFatureLayers[key].refresh();
              }
            }
          }
        }
      } else if (!state && this.newFatureLayers[key]) {
        if (Array.isArray(this.newFatureLayers[key]) && this.newFatureLayers[key].length > 0) {
          this.newFatureLayers[key].forEach(item => {
            this.map.remove(item.layer);
            item.layer.destroy();
          });
        } else {
          this.map.remove(this.newFatureLayers[key]);
          this.newFatureLayers[key].destroy();
        }
        this.view.popup.autoOpenEnabled = false;
        this.newFatureLayers[key] = undefined;
        this.newTmpData[key] = undefined;
      }
    });
  }

  componentDidMount() {
    console.log("didmount", this.view);
    window.getToken(VERSION);
    let { postClick, region = '长宁' } = this.props;
    console.info('region', REGION_CONFIG[region] ? REGION_CONFIG[region] : CENTER, CENTER);
    esriLoader
      .loadModules(
        [
          "esri/config",
          "esri/views/MapView",
          "esri/views/SceneView",
          "esri/Map",
          "esri/core/watchUtils",
          "esri/symbols/TextSymbol",
          "esri/geometry/Circle",
          "esri/identity/IdentityManager",
          "esri/geometry/SpatialReference",
          "esri/layers/FeatureLayer",
          "esri/layers/TileLayer",
          "esri/layers/SceneLayer",
          "esri/layers/MapImageLayer",
          "esri/layers/ImageryLayer",
          "esri/geometry/Extent",
          "esri/geometry/Point",
          "esri/symbols/SimpleMarkerSymbol",
          "esri/symbols/PictureMarkerSymbol",
          "esri/Graphic",
          "esri/PopupTemplate",
          "esri/renderers/ClassBreaksRenderer",
          "esri/layers/GraphicsLayer",
          "esri/symbols/SimpleLineSymbol",
          "esri/symbols/SimpleFillSymbol",
          "esri/Color",
          "esri/renderers/SimpleRenderer",
          "esri/views/2d/draw/Draw",
          "dojo",
          "esri/geometry/geometryEngine",
          "dojo/dom-class",
          "esri/tasks/QueryTask",
          "esri/tasks/support/Query",
          "esri/layers/support/LabelClass"
        ],
        { url: this.url }
      )
      .then(
        ([
          esriConfig,
          MapView,
          SceneView,
          Map,
          watchUtils,
          TextSymbol,
          Circle,
          IdentityManager,
          SpatialReference,
          FeatureLayer,
          ArcGISTiledMapServiceLayer,
          SceneLayer,
          ArcGISDynamicMapServiceLayer,
          ImageryTileLayer,
          Extent,
          Point,
          SimpleMarkerSymbol,
          PictureMarkerSymbol,
          Graphic,
          PopupTemplate,
          ClassBreaksRenderer,
          GraphicsLayer,
          SimpleLineSymbol,
          SimpleFillSymbol,
          Color,
          SimpleRenderer,
          Draw,
          dojo,
          geometryEngine,
          domClass,
          arcgisQueryTask,
          arcgisQuery,
          LabelClass
        ]) => {
          this.ArcGisGraphic = Graphic;
          this.ArcGisPoint = Point;
          this.ArcGisFeatureLayer = FeatureLayer;
          this.ArcGisGraphicsLayer = GraphicsLayer;
          let spatialReferencevalue = this.spatialReferencevalue;
          esriConfig.fontsUrl =
            "http://bigdata.cn.gov:9070/arcgisapi-master/fonts/arial-unicode-ms";
          // 定义地图
          this.map = new Map({});
          this.view = new SceneView({
            container: "mapDiv",
            map: this.map,
            showLabels: true,
            viewingMode: "local",
            center: REGION_CONFIG[region] ? REGION_CONFIG[region].center : CENTER,
            camera: { tilt: defaultTilt },
            spatialReference: spatialReferencevalue,
            extent: new Extent({
              type: "extent",
              xmax: 2116.0772399670277,
              xmin: -18203.963400114255,
              ymax: -16.55708170044818,
              ymin: -5731.568511723309,
              spatialReference: spatialReferencevalue,
            }),
            sliderPosition: "bottom-right",
            sliderOrientation: "horizontal",
            // sliderStyle:'small',
            zoom: REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM,
            qualityProfile: "high",
            environment: {
              background: {
                type: 'color',
                color: [0, 0, 0, 0],
              },
              starsEnabled: false,
              atmosphereEnabled: false,
            },
            highlightOptions: {
              color: [64, 189, 255, 1],
              haloOpacity: 0.8
            }
          });
          //地图缩放结束事件
          this.map.on("zoom-end", function () {
            //弹出当前地图缩放比例值
            alert(this.map.getZoom());
          });

          var token = document.getElementById("txtToken").value;
          IdentityManager.registerToken({
            server: VERSION === 'new' ?
              'http://10.89.5.191/OneMapServer/rest/services' :
              'http://map.cn.gov/OneMapServer/rest/services',
            token,
          });
          IdentityManager.on("dialog-create", function () {
            IdentityManager.dialog.open = true;
          });

          let tiledLayer = new ArcGISTiledMapServiceLayer({
            url: VERSION === 'new' ?
              'http://10.89.5.191/OneMapServer/rest/services/shmw2bigsize_blueblack/MapServer' :
              'http://10.207.204.19/server/rest/services/BIGANSE2/MapServer',
            id: 'baseMap',
          });

          let realLayer = new ArcGISTiledMapServiceLayer({
            url:
              VERSION === 'new' ?
                'http://10.89.5.191/OneMapServer/rest/services/cn_sta_image_2020/MapServer' :
                'http://10.207.204.19/server/rest/services/AIRIMAGE2020/MapServer',
            id: '长宁区卫星影像2020年'
          });
          realLayer.visiable = false;
          // 长宁边界
          // const boundary = LayerFactory.generateBoundaryLayer(FeatureLayer, VERSION, spatialReferencevalue);
          // 长宁边界遮罩
          const maskBoundary = LayerFactory.generateMaskBoundaryLayer(FeatureLayer, VERSION, spatialReferencevalue);
          // 长宁边界光圈
          // const shadowBoundary = LayerFactory.generateShadowBoundaryLayer(FeatureLayer, VERSION, spatialReferencevalue);
          // 长宁区街道
          // const street = LayerFactory.generateStreetLayer(FeatureLayer, VERSION, spatialReferencevalue);
          // 长宁网格
          // const wangge = LayerFactory.generateWanggeLayer(FeatureLayer, LabelClass, VERSION, spatialReferencevalue, null, null, this.props.zrwg);
          // 长宁区村居委
          // const juwei = LayerFactory.generateJuweiLayer(FeatureLayer, LabelClass, VERSION, spatialReferencevalue);
          // 长宁区三维白模型
          // const buildingWhite = LayerFactory.generateBaimoLayer(SceneLayer, VERSION, spatialReferencevalue);
          // 长宁精模
          // const buildingReals = LayerFactory.generateJingmoLayer(SceneLayer, VERSION, spatialReferencevalue);

          // 江苏街道光圈
          // LayerFactory.generateShadowBorder(
          //   this.url,
          //   'http://10.89.5.191/OneMapServer/rest/services/STREEt_testzyy/MapServer/0',
          //   spatialReferencevalue,
          //   `NAME='${region}'`,
          //   { lineWidth: 75, outlineNum: 75 },
          //   (layer) => {
          //     this.map.add(layer);
          //   }
          // );
          // 江苏路街道
          // const street = LayerFactory.generateStreetLayer(FeatureLayer, VERSION, spatialReferencevalue, {
          //   type: 'unique-value',
          //   field: 'NAME',
          //   defaultSymbol: {
          //     type: 'simple-fill',
          //     color: [0, 0, 0, 0.6],
          //     style: 'solid',
          //     outline: {
          //       width: 0
          //     }
          //   },
          //   uniqueValueInfos: [
          //     {
          //       value: `${region}`,
          //       symbol: {
          //         type: 'simple-fill',
          //         color: [0, 0, 0, 0],
          //         style: 'solid',
          //         outline: {
          //           color: [64, 189, 255, 1],
          //           width: 2
          //         }
          //       }
          //     }
          //   ]
          // });
          // 江苏路街道网格
          // const wangge = LayerFactory.generateWanggeLayer(FeatureLayer, LabelClass, VERSION, spatialReferencevalue, null, `所属街道='${region}'`);
          // 江苏路街道村居委
          // const juwei = LayerFactory.generateJuweiLayer(FeatureLayer, LabelClass, VERSION, spatialReferencevalue, null, `所属街道='${region}'`);
          // 江苏路街道三维白模型
          // const buildingWhite = LayerFactory.generateBaimoLayer(SceneLayer, VERSION, spatialReferencevalue, null, `ZJD_NAME='${region}'`);

          this.map.add(tiledLayer);
          this.map.add(realLayer);
          this.map.add(maskBoundary);
          this.map.add(shadowBoundary);
          this.map.add(street);
          this.map.add(wangge);
          this.map.add(juwei);
          this.map.add(buildingWhite);
          this.map.addMany(buildingReals);

          this.tiltLayers["vecMaptile"] = tiledLayer;
          this.featureLayers["cameraMaptile"] = realLayer;
          this.featureLayers["cnBorder"] = shadowBoundary;
          this.featureLayers["cnCountry"] = street;
          this.featureLayers["cnWangge"] = wangge;
          this.featureLayers["cnJuwei"] = juwei;
          this.featureLayers["buildingFFF"] = buildingWhite;
          this.featureLayers["buildingReal"] = buildingReals;

          layers.forEach((name) => {
            let alias = '';
            if (VERSION === 'new' && name === 'WHCG') {
              alias = 'WHCS';
            }
            var fl = new ArcGISDynamicMapServiceLayer({
              url: VERSION === 'new' ? `http://10.89.5.191/OneMapServer/rest/services/${alias || name}/MapServer` : `http://10.207.204.19/server/rest/services/${alias || name}/MapServer`,
              title: name,
            });
            this.map.add(fl);
            this.featureLayers[name] = fl;
          });

          this.view.ui.components = [];
          console.log("Map DID INITED");

          this.view.when(() => {
            console.log("Map DID LOADED");
            this.onResize();
            this.view.qualitySettings.memoryLimit = 4096;

            this.resetCamera(3000, region);

            this.cluster(this.props.datas);
            ["drag", "mouse-wheel", "double-click"].forEach((e) => {
              this.view.on(e, (event) => {
                this.cameraModifyed = true;
              });
            });
            watchUtils.whenTrue(this.view, "stationary", () => {
              if (this.cameraModifyed) {
                console.log(
                  "MapCamera: ",
                  this.view.zoom,
                  this.view.center,
                  this.view.camera.tilt,
                  this.view.camera.heading
                );
                this.cameraModifyed = false;
                // 
                if (this.newFatureLayers['road']) {
                  const roads = this.newFatureLayers['road'];
                  try {
                    if (roads) {
                      roads.forEach(item => {
                        if (item.layer) {
                          item.layer.visible = item.visible[0] <= (this.view.zoom || (REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM)) && (this.view.zoom || (REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM)) < item.visible[1];
                        }
                      })
                    }
                  } catch (e) {
                    console.error(e)
                  }
                }
                if (this.view.zoom < (this.road && this.road !== 'all' ? ROAD_CENTER[this.road].zoom : (REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM)) - (REGION_CONFIG[region] ? REGION_CONFIG[region].zoom_space : ZOOM_SPACE)) {
                  this.view.zoom = this.road && this.road !== 'all' ? ROAD_CENTER[this.road].zoom : (REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM);
                  this.view.goTo(
                    new Point({
                      x: this.road && this.road !== 'all' ? ROAD_CENTER[this.road].center[0] : (REGION_CONFIG[region] ? REGION_CONFIG[region].center : CENTER)[0],
                      y: this.road && this.road !== 'all' ? ROAD_CENTER[this.road].center[1] : (REGION_CONFIG[region] ? REGION_CONFIG[region].center : CENTER)[1],
                      spatialReference: spatialReferencevalue,
                    })
                  );
                }
              }
            });
            domClass.add(this.view.popup.domNode, "cn_arcgis_popup");
            this.view.popup.autoOpenEnabled = false;
            this.view.on("click", (e) => {
              if (DEVELOPING) {
                e.x *= this.viewsize.width;
                e.y *= this.viewsize.height;
              }
              this.view.hitTest(e).then((result) => {
                console.log('hit test result：', result);
                let resultPoint = result.results[0];
                let objGraphic = resultPoint.graphic;
                let all = objGraphic ? objGraphic.attributes : {};
                console.info(all);
                if (
                  !objGraphic ||
                  !all ||
                  !all.pinType ||
                  all.NAME === "上海虹桥国际机场" ||
                  all === null ||
                  all.name === "外环高速公路" ||
                  all.name === "北新泾-青浦公路" ||
                  all.name === "上海-聂拉木公路" ||
                  all.name === "虹中路" ||
                  all.name === "金沙江西路" ||
                  all.BUSTYPE === "轨道交通" ||
                  all.objectid === 1
                ) {
                  console.log('invailed point', all);
                  this.view.popup.visible = false;
                  return false;
                } else if (result.results.length > 0) {
                  if (
                    all.popup === "hover" ||
                    all.popup === "click" ||
                    all.popup === "click2" ||
                    all.popup === "click3" ||
                    all.popup === "click4"
                  ) {
                    this.view.popup.fillSymbol = false;
                    this.view.popup.titleInBody = false;
                    // domClass.add(this.view.popup.domNode, "cn_arcgis_popup");
                    let data = this.popup(all).data;
                    this.view.popup.autoOpenEnabled = false;
                    this.arcgisPopup(data, resultPoint.mapPoint);
                  } else if (all.popup === "postVis") {
                    postClick(all);
                  } else if (all.popup === "popup") {
                    let data = this.popup(all);
                    window.postMessage(data);
                    console.log("POSTED");
                  }
                }
              });
            });
            this.view.on("resize", (e) => {
              console.log("resize", e);
              this.onResize();
            });
            this.view.on("pointer-move", (e) => {
              this.pauseRotate();
              if (DEVELOPING) {
                e.x *= this.viewsize.width;
                e.y *= this.viewsize.height;
              }
              let lasthover = false;

              this.view.hitTest(e).then((result) => {
                if (
                  result.results[0].graphic &&
                  result.results[0].graphic.attributes &&
                  result.results[0].graphic.attributes.popup === "hover"
                ) {
                  let all = result.results[0].graphic.attributes;
                  this.view.popup.fillSymbol = false;
                  this.view.popup.titleInBody = false;
                  domClass.add(this.view.popup.domNode, "cn_arcgis_popup");
                  let data = this.popup(all).data;
                  this.arcgisPopup(data, result.results[0].mapPoint);
                } else {
                  this.view.popup.autoOpenEnabled = true;
                  // this.view.popup.visible = false;
                }
              });
            });
            this.view.ui.components = [];
            this.setState({ mapReady: true });
          });
        }
      );
  }

  componentWillUnmount() {
    console.log("destory");
    setTimeout(() => {
      this.view && this.view.destroy();
      console.log("destoried");
    }, 5000);
    this.intervals.forEach((e) => clearInterval(e));
  }

  render() {
    const { active, popup, postClick, layersData, mapCenter, zrwg, ...extra } = this.props;

    return (
      <div
        id='mapDiv'
        ref={(m) => (this.ref = m)}
        styles={{ backgroundColor: '#F3F' }}
        {...extra}
      />
    );
  }
}
