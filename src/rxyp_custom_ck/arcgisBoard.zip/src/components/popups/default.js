

import React, { Component } from "react";
import ReactDOM from "react-dom";
import "./popup.css";
export default function popDefault(dom, data) {
  let sbzbs;
  if (data.sbzbs) {
    sbzbs = JSON.parse(data.sbzbs);
  }
  console.log(data);
  ReactDOM.render(
    <div className={`cn_arcgis_popup_main`}>
      <div className="cn_arcgis_popup_infos">
        <div className="cn_arcgis_popup_text">类型: {data.type}</div>

        <div className="cn_arcgis_popup_text">地址: {data.address}</div>

        <div className="cn_arcgis_popup_text">
          状态: {data.sbztms || "不在线"}
        </div>
        {sbzbs
          ? sbzbs.map((e) => (
              <div className="cn_arcgis_popup_text">
                {e.name}: {e.value}
              </div>
            ))
          : ""}
      </div>
    </div>,
    dom
  );
  return dom;
}
