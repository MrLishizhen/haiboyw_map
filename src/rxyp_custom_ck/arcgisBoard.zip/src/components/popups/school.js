import React, { Component, Fragment } from "react";
import ReactDOM from "react-dom";
import "./school.css";
export default function popDefault(dom, data) {
  let sbzbs, sbzbRud;
  if (data.sbzbs) {
    sbzbs = JSON.parse(data.sbzbs);
    sbzbRud = [];
    for (let i = 0; i < sbzbs.length; i += 2) {
      if (!sbzbs[i + 1]) sbzbs[i + 1] = { name: "", value: "" };
      sbzbRud.push([sbzbs[i], sbzbs[i + 1]]);
    }
  }
  let infos = JSON.parse(data.infoJSON);
  let heatCounts = infos.sbzb || 0;

  ReactDOM.render(
    <div className={`cn_arcgis_popup_school`}>
      <div className={`cn_arcgis_popup_school_title`}>{infos.name}</div>
      <div className="cn_arcgis_popup_school_info">
        {infos.address && (
          <div
            className={`cn_arcgis_popup_school_infotab ${
              !infos.type && "cn_arcgis_popup_full_address"
              }`}
          >
            <div className="cn_arcgis_popup_type" style={data.pinType.indexOf('ZJGD') !== -1 ? { width: 270 } : {}}>地址</div>
            <div className="cn_arcgis_popup_value">{infos.address}</div>
          </div>
        )}
        {infos.infotype && infos.infotype.startsWith('http://') && (
          // <div className="cn_arcgis_popup_school_infotab cn_arcgis_popup_right">
          <div className="cn_arcgis_popup_school_infotab">
            <div className="cn_arcgis_popup_type" style={data.pinType.indexOf('ZJGD') !== -1 ? { width: 270 } : {}}>类型</div>
            <div className="cn_arcgis_popup_value">{infos.infotype}</div>
          </div>
        )}
        {sbzbRud &&
          sbzbRud.map((e) => (
            // <div className="cn_arcgis_popup_school_info">
            <Fragment>
              {e[0] && e[0].name &&
                <div className="cn_arcgis_popup_school_infotab">
                  <div className="cn_arcgis_popup_type" style={data.pinType.indexOf('ZJGD') !== -1 ? { width: 270 } : {}}>{e[0].name}</div>
                  {e[0].value === '5星' ?
                    <div className="cn_arcgis_popup_value">
                      <div className='star'></div>
                      <div className='star'></div>
                      <div className='star'></div>
                      <div className='star'></div>
                      <div className='star'></div>
                    </div> :
                    e[0].value === '4星' ?
                      <div className="cn_arcgis_popup_value">
                        <div className='star'></div>
                        <div className='star'></div>
                        <div className='star'></div>
                        <div className='star'></div>
                      </div> :
                      e[0].value === '3星' ?
                        <div className="cn_arcgis_popup_value">
                          <div className='star'></div>
                          <div className='star'></div>
                          <div className='star'></div>
                        </div> :
                        e[0].value === '2星' ?
                          <div className="cn_arcgis_popup_value">
                            <div className='star'></div>
                            <div className='star'></div>
                          </div> :
                          e[0].value === '1星' ?
                            <div className="cn_arcgis_popup_value">
                              <div className='star'></div>
                            </div> :
                            <div className="cn_arcgis_popup_value">{e[0].value}</div>
                  }
                </div>
              }
              {e[1] && e[1].name &&
                // <div className="cn_arcgis_popup_school_infotab cn_arcgis_popup_right">
                <div className="cn_arcgis_popup_school_infotab">
                  <div className="cn_arcgis_popup_type" style={data.pinType.indexOf('ZJGD') !== -1 ? { width: 270 } : {}}>{e[1].name}</div>
                  {e[1].value === '5星' ?
                    <div className="cn_arcgis_popup_value">
                      <div className='star'></div>
                      <div className='star'></div>
                      <div className='star'></div>
                      <div className='star'></div>
                      <div className='star'></div>
                    </div> :
                    e[1].value === '4星' ?
                      <div className="cn_arcgis_popup_value">
                        <div className='star'></div>
                        <div className='star'></div>
                        <div className='star'></div>
                        <div className='star'></div>
                      </div> :
                      e[1].value === '3星' ?
                        <div className="cn_arcgis_popup_value">
                          <div className='star'></div>
                          <div className='star'></div>
                          <div className='star'></div>
                        </div> :
                        e[1].value === '2星' ?
                          <div className="cn_arcgis_popup_value">
                            <div className='star'></div>
                            <div className='star'></div>
                          </div> :
                          e[1].value === '1星' ?
                            <div className="cn_arcgis_popup_value">
                              <div className='star'></div>
                            </div> :
                            <div className="cn_arcgis_popup_value">{e[1].value}</div>
                  }
                </div>
              }
            </Fragment>
            // </div>
          ))}
      </div>
      {infos.total && (
        <>
          <div className="cn_arcgis_popup_school_hr" />
          <div className="cn_arcgis_popup_school_heat">
            <div className="cn_arcgis_popup_school_heatCount">
              <div className="cn_arcgis_popup_school_heat_title">发热人数</div>
              <div className={`cn_arcgis_popup_school_num cn_arcgis_popup_red`}>
                {heatCounts}
              </div>
            </div>
            <div className="cn_arcgis_popup_school_totalCount">
              <div className="cn_arcgis_popup_school_heat_title">总检人数</div>
              <div
                className={`cn_arcgis_popup_school_num cn_arcgis_popup_green`}
              >
                {infos.total || Math.round(500 + Math.random() * 500)}
              </div>
            </div>
          </div>
        </>
      )}
    </div>,
    dom
  );
  return dom;
}
