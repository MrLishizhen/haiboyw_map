import React, { Component, Fragment } from "react";
import ReactDOM from "react-dom";
import "./newPopUp.css";

export default function popDefault(dom, data) {
  let sbzbs, sbzbRud;
  if (data.sbzbs) {
    sbzbs = JSON.parse(data.sbzbs);
    sbzbRud = [];
    for (let i = 0; i < sbzbs.length; i += 2) {
      if (!sbzbs[i + 1]) sbzbs[i + 1] = { name: "", value: "" };
      sbzbRud.push([sbzbs[i], sbzbs[i + 1]]);
    }
  }
  let infos = JSON.parse(data.infoJSON);
  console.log(data);

  ReactDOM.render(
    // <div className={`cn_arcgis_popup_school`}>
    //   <div className={`cn_arcgis_popup_school_title`}>{infos.name}</div>
    //   <div className="cn_arcgis_popup_school_info">
    //     {infos.address && (
    //       <div
    //         className={`cn_arcgis_popup_school_infotab ${
    //           !infos.type && "cn_arcgis_popup_full_address"
    //           }`}
    //       >
    //         <div className="cn_arcgis_popup_type">地址</div>
    //         <div className="cn_arcgis_popup_value">{infos.address}</div>
    //       </div>
    //     )}
    //     {infos.infotype && (
    //       <div className="cn_arcgis_popup_school_infotab cn_arcgis_popup_right">
    //         <div className="cn_arcgis_popup_type">类型</div>
    //         <div className="cn_arcgis_popup_value">{infos.infotype}</div>
    //       </div>
    //     )}
    //   </div>
    //   {sbzbRud &&
    //     sbzbRud.map((e) => (
    //       <div className="cn_arcgis_popup_school_info">
    //         <div className="cn_arcgis_popup_school_infotab">
    //           <div className="cn_arcgis_popup_type">{e[0].name}</div>
    //           <div className="cn_arcgis_popup_value">{e[0].value}</div>
    //         </div>
    //         <div className="cn_arcgis_popup_school_infotab cn_arcgis_popup_right">
    //           <div className="cn_arcgis_popup_type">{e[1].name}</div>
    //           <div className="cn_arcgis_popup_value">{e[1].value}</div>
    //         </div>
    //       </div>
    //     ))}
    // </div>,
    <div className='cn_arcgis_popup_new'>
      <div className='cn_arcgis_popup_new_scroll'>
        <table style={{ width: '100%' }}>
          <tbody>
            {infos.name &&
              <tr>
                <td className='cn_arcgis_popup_new_name' valign='top'>名称</td>
                <td className='cn_arcgis_popup_new_value' valign='top'>{infos.name}</td>
              </tr>
            }
            {infos.address &&
              <tr>
                <td className='cn_arcgis_popup_new_name' valign='top'>地址</td>
                <td className='cn_arcgis_popup_new_value' valign='top'>{infos.address}</td>
              </tr>
            }
            {infos.infotype &&
              <tr>
                <td className='cn_arcgis_popup_new_name' valign='top'>类型</td>
                <td className='cn_arcgis_popup_new_value' valign='top'>{infos.infotype}</td>
              </tr>
            }
            {sbzbRud &&
              sbzbRud.map((e) => (
                <Fragment>
                  {e[0].name && e[0].value &&
                    <tr>
                      <td className='cn_arcgis_popup_new_name' valign='top'>{e[0].name}</td>
                      <td className='cn_arcgis_popup_new_value' valign='top'>{e[0].value}</td>
                    </tr>
                  }
                  {e[1].name && e[1].value &&
                    <tr>
                      <td className='cn_arcgis_popup_new_name' valign='top'>{e[1].name}</td>
                      <td className='cn_arcgis_popup_new_value' valign='top'>{e[1].value}</td>
                    </tr>
                  }
                </Fragment>
              ))}
          </tbody>
        </table>
      </div>
    </div>,
    dom
  );
  return dom;
}
