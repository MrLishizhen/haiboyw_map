import React, { Component, Fragment } from "react";
import ReactDOM from "react-dom";
import "./school.css";
export default function popDefault(dom, data) {
  let sbzbs, sbzbRud;
  if (data.sbzbs) {
    sbzbs = JSON.parse(data.sbzbs);
    sbzbRud = [];
    for (let i = 0; i < sbzbs.length; i += 2) {
      if (!sbzbs[i + 1]) sbzbs[i + 1] = { name: "", value: "" };
      sbzbRud.push([sbzbs[i], sbzbs[i + 1]]);
    }
  }
  let infos = JSON.parse(data.infoJSON);
  let heatCounts = infos.sbzb || 0;

  ReactDOM.render(
    <div className={`cn_arcgis_popup_school`}>
      <div className={`cn_arcgis_popup_school_title`} style={{ maxWidth: 'unset' }} >{infos.name}</div>
      <div style={{ width: '100%' }}>
        {infos.infotype &&
          <div className="cn_arcgis_popup_school_info" style={{ display: 'inline-block', verticalAlign: 'middle' }}>
            <img src={infos.infotype} style={{ width: 264, height: '100%' }} />
          </div>
        }
        <div className="cn_arcgis_popup_school_info" style={{ display: 'inline-block', verticalAlign: 'middle' }}>
          {infos.address && (
            <div
              className={`cn_arcgis_popup_school_infotab ${
                !infos.type && "cn_arcgis_popup_full_address"
                }`}
            >
              <div className="cn_arcgis_popup_type">地址</div>
              <div className="cn_arcgis_popup_value" style={{ minWidth: 100 }}>{infos.address}</div>
            </div>
          )}
          {infos.infotype && !infos.infotype.startsWith('http://') && (
            <div className="cn_arcgis_popup_school_infotab">
              <div className="cn_arcgis_popup_type">类型</div>
              <div className="cn_arcgis_popup_value" style={{ minWidth: 100 }}>{infos.infotype}</div>
            </div>
          )}
          {sbzbRud &&
            sbzbRud.map((e) => (
              // <div className="cn_arcgis_popup_school_info">
              <Fragment>
                {e[0] && e[0].name &&
                  <div className="cn_arcgis_popup_school_infotab">
                    <div className="cn_arcgis_popup_type">{e[0].name}</div>
                    {e[0].value === '5星' ?
                      <div className="cn_arcgis_popup_value" style={{ minWidth: 100 }}>
                        <div className='star'></div>
                        <div className='star'></div>
                        <div className='star'></div>
                        <div className='star'></div>
                        <div className='star'></div>
                      </div> :
                      e[0].value === '4星' ?
                        <div className="cn_arcgis_popup_value" style={{ minWidth: 100 }}>
                          <div className='star'></div>
                          <div className='star'></div>
                          <div className='star'></div>
                          <div className='star'></div>
                        </div> :
                        e[0].value === '3星' ?
                          <div className="cn_arcgis_popup_value" style={{ minWidth: 100 }}>
                            <div className='star'></div>
                            <div className='star'></div>
                            <div className='star'></div>
                          </div> :
                          e[0].value === '2星' ?
                            <div className="cn_arcgis_popup_value" style={{ minWidth: 100 }}>
                              <div className='star'></div>
                              <div className='star'></div>
                            </div> :
                            e[0].value === '1星' ?
                              <div className="cn_arcgis_popup_value" style={{ minWidth: 100 }}>
                                <div className='star'></div>
                              </div> :
                              <div className="cn_arcgis_popup_value" style={{ minWidth: 100 }}>{e[0].value}</div>
                    }
                  </div>
                }
                {e[1] && e[1].name &&
                  // <div className="cn_arcgis_popup_school_infotab cn_arcgis_popup_right">
                  <div className="cn_arcgis_popup_school_infotab">
                    <div className="cn_arcgis_popup_type">{e[1].name}</div>
                    {e[1].value === '5星' ?
                      <div className="cn_arcgis_popup_value" style={{ minWidth: 100 }}>
                        <div className='star'></div>
                        <div className='star'></div>
                        <div className='star'></div>
                        <div className='star'></div>
                        <div className='star'></div>
                      </div> :
                      e[1].value === '4星' ?
                        <div className="cn_arcgis_popup_value" style={{ minWidth: 100 }}>
                          <div className='star'></div>
                          <div className='star'></div>
                          <div className='star'></div>
                          <div className='star'></div>
                        </div> :
                        e[1].value === '3星' ?
                          <div className="cn_arcgis_popup_value" style={{ minWidth: 100 }}>
                            <div className='star'></div>
                            <div className='star'></div>
                            <div className='star'></div>
                          </div> :
                          e[1].value === '2星' ?
                            <div className="cn_arcgis_popup_value" style={{ minWidth: 100 }}>
                              <div className='star'></div>
                              <div className='star'></div>
                            </div> :
                            e[1].value === '1星' ?
                              <div className="cn_arcgis_popup_value" style={{ minWidth: 100 }}>
                                <div className='star'></div>
                              </div> :
                              <div className="cn_arcgis_popup_value" style={{ minWidth: 100 }}>{e[1].value}</div>
                    }
                  </div>
                }
              </Fragment>
              // </div>
            ))}
        </div>
      </div>
    </div>,
    dom
  );
  return dom;
}
