import React, { Fragment } from 'react';
import ReactDOM from 'react-dom';
import Video from './clearVideo';
import VideoList from './VideoList';
import './index.css';

class Index extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      current: 0
    }
  }

  render() {
    const { data, showPhone, makeCall, hangupCall, postClick } = this.props;
    const { name, address, infotype, sbzbs, pinType } = Array.isArray(data) ? data[this.state.current] : data;
    let array = [];
    const id = new Date().valueOf();

    try {
      array = JSON.parse(sbzbs);
    } catch (e) {
      console.error(e);
    }

    function phoneCall(id, value) {
      if (typeof makeCall === 'function') {
        makeCall(id, value);
      }
    }

    function showVideo(videoSrc, index, name, itemName) {
      console.log('videoSrc', videoSrc);
      const wrapper = document.getElementById('panel_canvas');
      let scale = 0;
      if (wrapper) {
        scale = Math.min(document.body.clientWidth / wrapper.offsetWidth, document.body.clientHeight / wrapper.offsetHeight);
      }
      const dom = document.createElement('div');
      document.body.appendChild(dom);
      dom.id = 'video_wrapper';
      if (scale > 0) {
        dom.style = `cursor: pointer; position: fixed; top: 0; right: 0; left: 0; height: ${wrapper.offsetHeight * scale}px;  background-color: rgba(0, 0, 0, 0.5); z-index: 1`;
      } else {
        dom.style = 'cursor: pointer; position: fixed; top: 0; right: 0; bottom: 0; left: 0; background-color: rgba(0, 0, 0, 0.5); z-index: 1';
      }
      dom.onclick = (e) => {
        if (e && e.target && e.target.id === 'video_wrapper') {
          ReactDOM.unmountComponentAtNode(dom);
          document.body.removeChild(dom);
        }
      };
      if (itemName === '视频列表') {
        ReactDOM.render(<VideoList name={name} />, dom);
      } else {
        ReactDOM.render(<Video videoSrc={videoSrc} index={index} onClose={() => { const el = document.getElementById('video_wrapper'); if (el) { document.body.removeChild(el) } }} />, dom);
      }
    }

    return (
      <div className={`popup_dom_wrapper`}>
        {Array.isArray(data) && data.length > 1 &&
          <Fragment>
            <div className='video-list-btn next' style={{ height: '50px', width: '50px', position: 'absolute', top: '50%', right: '20px', cursor: 'pointer', opacity: 1 }}
              onClick={() => {
                if (this.state.current + 1 < data.length) {
                  this.setState({ current: this.state.current + 1 });
                }
              }}
            />
            <div className='video-list-btn prev' style={{ height: '50px', width: '50px', position: 'absolute', top: '50%', left: '20px', cursor: 'pointer', opacity: 1 }}
              onClick={() => {
                if (this.state.current - 1 >= 0) {
                  this.setState({ current: this.state.current - 1 });
                }
              }}
            />
          </Fragment>
        }
        <div className={`popup_dom_title`}>{name}</div>
        <div style={{ padding: '0 32px' }}>
          <table className={`popup_dom_content`}>
            <tbody>
              {address &&
                <tr>
                  <td style={{ minWidth: pinType && pinType.indexOf('ZJGD') !== -1 ? 280 : 240, color: '#00c2ff' }}>地址</td>
                  <td>{address}</td>
                </tr>
              }
              {infotype &&
                <tr>
                  <td style={{ minWidth: pinType && pinType.indexOf('ZJGD') !== -1 ? 280 : 240, color: '#00c2ff' }}>类型</td>
                  <td>{infotype}</td>
                </tr>
              }
              {array && array.length > 0 &&
                array.map((item, index) => {
                  let { name: itemName, value } = item;
                  value = typeof value === 'string' ? value.replace(/\r\n/g, '') : value;
                  let isPhone = /*pinType && pinType.indexOf('ZJGD') !== -1 &&*/ /^([0-9]{3,4}(-)?)?[0-9]{7,8}$/.test(value) || /^1(3|4|5|6|7|8|9)\d{9}$/.test(value);
                  let isVideo = itemName && (itemName === '视频编号' || itemName === '视频列表');
                  const isPostClick = itemName.indexOf('_postClick');
                  const arrayValue = value && typeof value.split === 'function' ? value.split('/') : undefined;

                  // 垃圾-撒点弹窗-扣分项变成红色
                  let wbmb = 0, wbj = 0;
                  try {
                    wbmb = itemName.match(/\d+(\.\d+)?/g)[0];
                    wbmb = parseFloat(wbmb);
                    wbj = parseFloat(value);
                    console.info(wbmb, wbj)
                  } catch (e) {
                    console.error(e);
                  }
                  
                  return (
                    <tr key={index} className={isPostClick !== -1 ? 'popup_dom_item_hover' : ''} onClick={isPostClick !== -1 ? () => { if (typeof postClick === 'function') postClick(Array.isArray(data) ? data[this.state.current] : data) } : undefined}>
                      <td style={{ minWidth: pinType && pinType.indexOf('ZJGD') !== -1 ? 280 : 240, color: '#00c2ff' }}>{isPostClick !== -1 ? itemName.substring(0, isPostClick) : itemName}</td>
                      <td style={wbmb > wbj ? { color: "red" } : {}}>
                        {value === '5星' ?
                          <div className='cn_arcgis_popup_value'>
                            <div className='star'></div>
                            <div className='star'></div>
                            <div className='star'></div>
                            <div className='star'></div>
                            <div className='star'></div>
                          </div> :
                          value === '4星' ?
                            <div className='cn_arcgis_popup_value'>
                              <div className='star'></div>
                              <div className='star'></div>
                              <div className='star'></div>
                              <div className='star'></div>
                            </div> :
                            value === '3星' ?
                              <div className='cn_arcgis_popup_value'>
                                <div className='star'></div>
                                <div className='star'></div>
                                <div className='star'></div>
                              </div> :
                              value === '2星' ?
                                <div className='cn_arcgis_popup_value'>
                                  <div className='star'></div>
                                  <div className='star'></div>
                                </div> :
                                value === '1星' ?
                                  <div className='cn_arcgis_popup_value'>
                                    <div className='star'></div>
                                  </div> :
                                  <div className='cn_arcgis_popup_value'>
                                    {arrayValue && arrayValue.length > 1 ?
                                      arrayValue.map((v, i) => {
                                        isPhone = /*pinType && pinType.indexOf('ZJGD') !== -1 &&*/ /^([0-9]{3,4}(-)?)?[0-9]{7,8}$/.test(v) || /^1(3|4|5|6|7|8|9)\d{9}$/.test(v);

                                        return (
                                          <div key={i}>
                                            {v}
                                            {!!showPhone && !!isPhone &&
                                              <Fragment>
                                                <div id={`${id}-array-${i}-phone-call`} className='phone-icon phone-call' onClick={() => phoneCall(`${id}-array-${i}`, v)} />
                                                <div id={`${id}-array-${i}-phone-forwarded`} className='phone-icon phone-forwarded' />
                                                <div id={`${id}-array-${i}-phone-off-disabled`} className='phone-icon phone-off-disabled' />
                                                <div id={`${id}-array-${i}-phone-off`} className='phone-icon phone-off' onClick={() => hangupCall()} />
                                              </Fragment>
                                            }
                                            {isVideo &&
                                              <div className='phone-icon video-show' onClick={() => showVideo(arrayValue, i)} />
                                            }
                                          </div>
                                        );
                                      }) :
                                      <Fragment>
                                        {value}
                                        {!!showPhone && !!isPhone &&
                                          <Fragment>
                                            <div id={`${id}-${index}-phone-call`} className='phone-icon phone-call' onClick={() => phoneCall(`${id}-${index}`, value)} />
                                            <div id={`${id}-${index}-phone-forwarded`} className='phone-icon phone-forwarded' />
                                            <div id={`${id}-${index}-phone-off-disabled`} className='phone-icon phone-off-disabled' />
                                            <div id={`${id}-${index}-phone-off`} className='phone-icon phone-off' onClick={() => hangupCall()} />
                                          </Fragment>
                                        }
                                        {isVideo &&
                                          <div className='phone-icon video-show' onClick={() => showVideo([value], 0, name, itemName)} />
                                        }
                                      </Fragment>
                                    }
                                  </div>
                        }
                      </td>
                    </tr>
                  )
                })
              }
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default function popDefault(dom, data, showPhone, makeCall, hangupCall, postClick) {
  // const { name, address, infotype, sbzbs, pinType } = data;
  // let array = [];
  // const id = new Date().valueOf();

  // try {
  //   array = JSON.parse(sbzbs);
  // } catch (e) {
  //   console.error(e);
  // }

  // function phoneCall(id, value) {
  //   if (typeof makeCall === 'function') {
  //     makeCall(id, value);
  //   }
  // }

  // function showVideo(videoSrc, index) {
  //   console.log('videoSrc', videoSrc);
  //   const dom = document.createElement('div');
  //   document.body.appendChild(dom);
  //   dom.id = 'video_wrapper';
  //   dom.style = 'cursor: pointer; position: fixed; top: 0; right: 0; bottom: 0; left: 0; background-color: rgba(0, 0, 0, 0.5)';
  //   dom.onclick = () => {
  //     document.body.removeChild(dom);
  //   };
  //   ReactDOM.render(<Video videoSrc={videoSrc} index={index} onClose={() => { const el = document.getElementById('video_wrapper'); if (el) { document.body.removeChild(el) } }} />, dom);
  // }

  ReactDOM.render(
    // <div className={`popup_dom_wrapper`}>
    //   <div className={`popup_dom_title`}>{name}</div>
    //   <div style={{ padding: '0 32px' }}>
    //     <table className={`popup_dom_content`}>
    //       <tbody>
    //         {address &&
    //           <tr>
    //             <td style={{ minWidth: pinType && pinType.indexOf('ZJGD') !== -1 ? 280 : 240, color: '#00c2ff' }}>地址</td>
    //             <td>{address}</td>
    //           </tr>
    //         }
    //         {infotype &&
    //           <tr>
    //             <td style={{ minWidth: pinType && pinType.indexOf('ZJGD') !== -1 ? 280 : 240, color: '#00c2ff' }}>类型</td>
    //             <td>{infotype}</td>
    //           </tr>
    //         }
    //         {array && array.length > 0 &&
    //           array.map((item, index) => {
    //             let { name, value } = item;
    //             value = typeof value === 'string' ? value.replace(/\r\n/g, '') : value;
    //             let isPhone = /*pinType && pinType.indexOf('ZJGD') !== -1 &&*/ /^([0-9]{3,4}(-)?)?[0-9]{7,8}$/.test(value) || /^1(3|4|5|6|7|8|9)\d{9}$/.test(value);
    //             let isVideo = name && name === '视频编号';
    //             const arrayValue = value && typeof value.split === 'function' ? value.split('/') : undefined;

    //             return (
    //               <tr key={index}>
    //                 <td style={{ minWidth: pinType && pinType.indexOf('ZJGD') !== -1 ? 280 : 240, color: '#00c2ff' }}>{name}</td>
    //                 <td>
    //                   {value === '5星' ?
    //                     <div className='cn_arcgis_popup_value'>
    //                       <div className='star'></div>
    //                       <div className='star'></div>
    //                       <div className='star'></div>
    //                       <div className='star'></div>
    //                       <div className='star'></div>
    //                     </div> :
    //                     value === '4星' ?
    //                       <div className='cn_arcgis_popup_value'>
    //                         <div className='star'></div>
    //                         <div className='star'></div>
    //                         <div className='star'></div>
    //                         <div className='star'></div>
    //                       </div> :
    //                       value === '3星' ?
    //                         <div className='cn_arcgis_popup_value'>
    //                           <div className='star'></div>
    //                           <div className='star'></div>
    //                           <div className='star'></div>
    //                         </div> :
    //                         value === '2星' ?
    //                           <div className='cn_arcgis_popup_value'>
    //                             <div className='star'></div>
    //                             <div className='star'></div>
    //                           </div> :
    //                           value === '1星' ?
    //                             <div className='cn_arcgis_popup_value'>
    //                               <div className='star'></div>
    //                             </div> :
    //                             <div className='cn_arcgis_popup_value'>
    //                               {arrayValue && arrayValue.length > 1 ?
    //                                 arrayValue.map((v, i) => {
    //                                   isPhone = /*pinType && pinType.indexOf('ZJGD') !== -1 &&*/ /^([0-9]{3,4}(-)?)?[0-9]{7,8}$/.test(v) || /^1(3|4|5|6|7|8|9)\d{9}$/.test(v);

    //                                   return (
    //                                     <div key={i}>
    //                                       {v}
    //                                       {!!showPhone && !!isPhone &&
    //                                         <Fragment>
    //                                           <div id={`${id}-array-${i}-phone-call`} className='phone-icon phone-call' onClick={() => phoneCall(`${id}-array-${i}`, v)} />
    //                                           <div id={`${id}-array-${i}-phone-forwarded`} className='phone-icon phone-forwarded' />
    //                                           <div id={`${id}-array-${i}-phone-off-disabled`} className='phone-icon phone-off-disabled' />
    //                                           <div id={`${id}-array-${i}-phone-off`} className='phone-icon phone-off' onClick={() => hangupCall()} />
    //                                         </Fragment>
    //                                       }
    //                                       {isVideo &&
    //                                         <div className='phone-icon video-show' onClick={() => showVideo(arrayValue, i)} />
    //                                       }
    //                                     </div>
    //                                   );
    //                                 }) :
    //                                 <Fragment>
    //                                   {value}
    //                                   {!!showPhone && !!isPhone &&
    //                                     <Fragment>
    //                                       <div id={`${id}-${index}-phone-call`} className='phone-icon phone-call' onClick={() => phoneCall(`${id}-${index}`, value)} />
    //                                       <div id={`${id}-${index}-phone-forwarded`} className='phone-icon phone-forwarded' />
    //                                       <div id={`${id}-${index}-phone-off-disabled`} className='phone-icon phone-off-disabled' />
    //                                       <div id={`${id}-${index}-phone-off`} className='phone-icon phone-off' onClick={() => hangupCall()} />
    //                                     </Fragment>
    //                                   }
    //                                   {isVideo &&
    //                                     <div className='phone-icon video-show' onClick={() => showVideo([value])} />
    //                                   }
    //                                 </Fragment>
    //                               }
    //                             </div>
    //                   }
    //                 </td>
    //               </tr>
    //             )
    //           })
    //         }
    //       </tbody>
    //     </table>
    //   </div>
    // </div>,
    <Index data={data} showPhone={showPhone} makeCall={makeCall} hangupCall={hangupCall} postClick={postClick} />,
    dom
  );

  return dom;
}
