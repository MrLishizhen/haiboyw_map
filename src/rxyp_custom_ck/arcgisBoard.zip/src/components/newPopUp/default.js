import React, { Fragment } from 'react';
import ReactDOM from 'react-dom';
import Video from './clearVideo';
import VideoList from './VideoList';
import './index.css';

class Index extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      current: 0
    }
  }

  render() {
    const { current } = this.state;
    const { data, showPhone, makeCall, hangupCall, postClick, parent, videoFusion } = this.props;
    const { name, address, infotype, sbzbs, pinType } = Array.isArray(data) ? data[current] : data;
    let array = [], arrayIndex = 0;
    const id = new Date().valueOf();

    try {
      if (sbzbs) {
        if (typeof sbzbs === 'string') {
          array = JSON.parse(sbzbs);
        } else {
          array = sbzbs;
        }
      }
    } catch (e) {
      console.error(e);
    }

    function phoneCall(id, value) {
      if (typeof makeCall === 'function') {
        makeCall(id, value);
      }
    }

    function showImage(url) {
      let dom = document.createElement('div');
      dom.style = `
        position: fixed;
        top:0;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 9999;
        background-color: rgba(0,0,0,0.6);
      `;
      let img = document.createElement('img');
      img.src = url;
      img.style = `
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
      `;
      dom.appendChild(img);
      dom.onclick = function () {
        document.body.removeChild(dom);
      }
      document.body.appendChild(dom);
    }

    function showVideo(videoSrc, index, name, itemName, parentName, id) {
      const info = array.filter(a => a && a.name === 'info')[0];
      if (info && typeof videoFusion === 'function') {
        videoFusion(Array.isArray(data) ? data[current] : data);
        return;
      }

      console.log('videoSrc', videoSrc, index, name, itemName, parentName);
      const wrapper = document.getElementById('panel_canvas');
      let scale = 0;
      if (wrapper) {
        scale = Math.min(document.body.clientWidth / wrapper.offsetWidth, document.body.clientHeight / wrapper.offsetHeight);
      }
      const dom = document.createElement('div');
      document.body.appendChild(dom);
      dom.id = id || 'video_wrapper_map';
      if (scale > 0) {
        dom.style = `cursor: pointer; position: fixed; top: 0; right: 0; left: 0; height: ${wrapper.offsetHeight * scale}px;  background-color: rgba(0, 0, 0, 0); z-index: ${id ? 2 : 1}`;
      } else {
        dom.style = `cursor: pointer; position: fixed; top: 0; right: 0; bottom: 0; left: 0; background-color: rgba(0, 0, 0, 0); z-index: ${id ? 2 : 1}`;
      }
      dom.onclick = (e) => {
        if (e && e.target && e.target.id === (id || 'video_wrapper_map')) {
          ReactDOM.unmountComponentAtNode(dom);
          document.body.removeChild(dom);
        }
      };
      if (itemName.indexOf('视频列表') !== -1) {
        ReactDOM.render(<VideoList name={name} parentName={parentName} onClick={(videoSrc) => {
          console.info(videoSrc);
          showVideo(videoSrc, 0, '', '', '', 'video_wrapper_map_single')
        }} />, dom);
      } else {
        // const { pinType } = data[0] || {};

        // if (pinType === 'ztc' && parent && parent.props.region.indexOf('虹桥临空经济园区') !== -1) {
        //   if (parent.view.type === '3d') {
        //     if (scale > 0) {

        //     } else {
        //       dom.style = `cursor: pointer; position: fixed; top: 25%; right: 25%; width: 1920px; height: 1080px; background-color: rgba(0, 0, 0, 0.5); z-index: ${id ? 2 : 1}`;
        //     }
        //     parent.view.goTo(
        //       {
        //         center: [-0.08909011989432779, -0.012077452001977402],
        //         zoom: 6.74
        //       },
        //       { duration: 1 }
        //     );
        //   }
        // }
        ReactDOM.render(<Video videoSrc={Array.isArray(videoSrc) ? videoSrc[0] : videoSrc} index={index}
          wrapperStyle={{ position: 'unset' }}
          style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', width: '70%', height: '70%', backgroundColor: 'transparent' }}
          onClose={() => { const el = document.getElementById(id || 'video_wrapper_map'); if (el) { ReactDOM.unmountComponentAtNode(dom); document.body.removeChild(el) } }} />, dom);
      }
    }

    return (
      <div className={`popup_dom_wrapper`}>
        {Array.isArray(data) && data.length > 1 &&
          <Fragment>
            {current < (data.length - 1) &&
              <div className='video-list-btn next' style={{ height: '50px', width: '50px', position: 'absolute', top: '50%', right: '20px', cursor: 'pointer', opacity: 1 }}
                onClick={() => {
                  if (current + 1 < data.length) {
                    this.setState({ current: current + 1 });
                  }
                }}
              />
            }
            {current > 0 &&
              <div className='video-list-btn prev' style={{ height: '50px', width: '50px', position: 'absolute', top: '50%', left: '20px', cursor: 'pointer', opacity: 1 }}
                onClick={() => {
                  if (current - 1 >= 0) {
                    this.setState({ current: current - 1 });
                  }
                }}
              />
            }
          </Fragment>
        }
        <div className={`popup_dom_title`}>{name}</div>
        <div style={Array.isArray(data) && data.length > 1 ? { padding: '0px 64px' } : { padding: '0 32px' }}>
          <table className={`popup_dom_content`}>
            <tbody>
              {address &&
                <tr>
                  <td style={{ minWidth: pinType && pinType.indexOf('ZJGD') !== -1 ? 320 : 260, color: '#00c2ff', paddingRight: 20 }}>地        址</td>
                  <td>{address}</td>
                </tr>
              }
              {infotype &&
                <tr>
                  <td style={{ minWidth: pinType && pinType.indexOf('ZJGD') !== -1 ? 320 : 260, color: '#00c2ff', paddingRight: 20 }}>类        型</td>
                  <td>{infotype}</td>
                </tr>
              }
              {array && array.length > 0 &&
                pinType === 'szsb' ?
                array.map((item, index) => {
                  if (arrayIndex < array.length) {
                    return (
                      <tr key={arrayIndex}>
                        <td style={{ width: 260, color: '#00c2ff', paddingRight: 20 }}>
                          {array[arrayIndex].name}
                        </td>
                        <td colSpan={arrayIndex === 0 ? 3 : 1} style={arrayIndex === 0 ? {} : { width: '25%' }}>
                          {array[arrayIndex++].value}
                        </td>
                        {arrayIndex > 1 && arrayIndex < array.length &&
                          <Fragment>
                            <td style={{ width: 260, color: '#00c2ff', paddingRight: 20 }}>
                              {array[arrayIndex].name}
                            </td>
                            <td style={{ width: '25%' }}>
                              {array[arrayIndex++].value}
                            </td>
                          </Fragment>
                        }
                      </tr>
                    )
                  }
                }) :
                array.filter(a => a && a.name !== 'info').map((item, index) => {
                  let { name: itemName, value } = item;
                  value = typeof value === 'string' ? value.replace(/\r\n/g, '') : value;
                  let isPhone = /*pinType && pinType.indexOf('ZJGD') !== -1 &&*/ /^([0-9]{3,4}(-)?)?[0-9]{7,8}$/.test(value) || /^1(3|4|5|6|7|8|9)\d{9}$/.test(value);
                  let isVideo = itemName && (itemName === '视频编号' || itemName.indexOf('视频列表') !== -1);
                  const isImageClick = itemName.indexOf('_imageClick');
                  const isPostClick = itemName.indexOf('_postClick');
                  const isSecretClick = itemName.indexOf('_secretClick');
                  const arrayValue = value && typeof value.split === 'function' && isImageClick === -1 ? value.split('/') : undefined;
                  if (isImageClick !== -1) {
                    value = '点击查看详情'
                  }
                  // 垃圾-撒点弹窗-扣分项变成红色
                  let wbmb = 0, wbj = 0;
                  try {
                    wbmb = itemName.match(/\d+(\.\d+)?/g)[0];
                    wbmb = parseFloat(wbmb);
                    wbj = parseFloat(value);
                    console.info(wbmb, wbj)
                  } catch (e) {
                    console.error(e);
                  }

                  return (
                    <tr key={index} className={isPostClick !== -1 ? 'popup_dom_item_hover' : ''} onClick={
                      isPostClick !== -1 ? () => { if (typeof postClick === 'function') postClick(Array.isArray(data) ? data[current] : data) } :
                        isImageClick !== -1 ? () => showImage(item.value) :
                          undefined
                    }
                    >
                      <td style={{ minWidth: pinType && pinType.indexOf('ZJGD') !== -1 ? 320 : 260, color: '#00c2ff', paddingRight: 20 }}>
                        {
                          isPostClick !== -1 ? itemName.substring(0, isPostClick) :
                            isImageClick !== -1 ? itemName.substring(0, isImageClick) :
                              isSecretClick !== -1 ? itemName.substring(0, isSecretClick) :
                                isVideo ? itemName.substring(0, itemName.indexOf('_') !== -1 ? itemName.indexOf('_') : itemName.length) :
                                  itemName
                        }
                      </td>
                      <td style={wbmb > wbj ? { color: '#00FF8F' } : {}}>
                        {value === '5星' ?
                          <div className='cn_arcgis_popup_value'>
                            <div className='star'></div>
                            <div className='star'></div>
                            <div className='star'></div>
                            <div className='star'></div>
                            <div className='star'></div>
                          </div> :
                          value === '4星' ?
                            <div className='cn_arcgis_popup_value'>
                              <div className='star'></div>
                              <div className='star'></div>
                              <div className='star'></div>
                              <div className='star'></div>
                            </div> :
                            value === '3星' ?
                              <div className='cn_arcgis_popup_value'>
                                <div className='star'></div>
                                <div className='star'></div>
                                <div className='star'></div>
                              </div> :
                              value === '2星' ?
                                <div className='cn_arcgis_popup_value'>
                                  <div className='star'></div>
                                  <div className='star'></div>
                                </div> :
                                value === '1星' ?
                                  <div className='cn_arcgis_popup_value'>
                                    <div className='star'></div>
                                  </div> :
                                  <div className='cn_arcgis_popup_value'>
                                    {arrayValue && arrayValue.length > 1 ?
                                      arrayValue.map((v, i) => {
                                        isPhone = /*pinType && pinType.indexOf('ZJGD') !== -1 &&*/ /^([0-9]{3,4}(-)?)?[0-9]{7,8}$/.test(v) || /^1(3|4|5|6|7|8|9)\d{9}$/.test(v);

                                        return (
                                          <div key={i}>
                                            {v}
                                            {!!showPhone && !!isPhone &&
                                              <Fragment>
                                                <div id={`${id}-array-${i}-phone-call`} className='phone-icon phone-call' onClick={() => phoneCall(`${id}-array-${i}`, v)} />
                                                <div id={`${id}-array-${i}-phone-forwarded`} className='phone-icon phone-forwarded' />
                                                {/* <div id={`${id}-array-${i}-phone-off-disabled`} className='phone-icon phone-off-disabled' /> */}
                                                <div id={`${id}-array-${i}-phone-off`} className='phone-icon phone-off' onClick={() => hangupCall()} />
                                              </Fragment>
                                            }
                                            {isVideo &&
                                              <div className='phone-icon video-show' onClick={() => showVideo(arrayValue, i)} />
                                            }
                                          </div>
                                        );
                                      }) :
                                      <Fragment>
                                        {isSecretClick >= 0 ?
                                          (
                                            this.state[`visible_${index}`] ?
                                              (
                                                !this.state[`visible_ok_${index}`] ?
                                                  <input type='password' placeholder='请输入密码'
                                                    onChange={(e) => {
                                                      if (e.target.value === '1234@qwer') {
                                                        this.setState({ [`visible_ok_${index}`]: true })
                                                      }
                                                    }}
                                                  /> :
                                                  value
                                              ) :
                                              '*************'
                                          ) :
                                          value}
                                        {!!showPhone && !!isPhone &&
                                          <Fragment>
                                            <div id={`${id}-${index}-phone-call`} className='phone-icon phone-call' onClick={() => phoneCall(`${id}-${index}`, value)} />
                                            <div id={`${id}-${index}-phone-forwarded`} className='phone-icon phone-forwarded' />
                                            {/* <div id={`${id}-${index}-phone-off-disabled`} className='phone-icon phone-off-disabled' /> */}
                                            <div id={`${id}-${index}-phone-off`} className='phone-icon phone-off' onClick={() => hangupCall()} />
                                          </Fragment>
                                        }
                                        {isVideo &&
                                          <div className='phone-icon video-show' onClick={() => showVideo([value], 0, name, itemName, itemName.indexOf('_') !== -1 ? itemName.substring(itemName.indexOf('_') + 1, itemName.length) : '')} />
                                        }
                                        {isSecretClick >= 0 ?
                                          this.state[`visible_${index}`] ?
                                            <div className='phone-icon eye-off' onClick={() => this.setState({ [`visible_${index}`]: false, [`visible_ok_${index}`]: false })} /> :
                                            <div className='phone-icon eye' onClick={() => this.setState({ [`visible_${index}`]: true })} /> :
                                          null
                                        }
                                      </Fragment>
                                    }
                                  </div>
                        }
                      </td>
                    </tr>
                  )
                })
              }
            </tbody>
          </table>
        </div>
      </div >
    );
  }
}

export default function popDefault(dom, data, showPhone, makeCall, hangupCall, postClick, parent, videoFusion) {
  // const { name, address, infotype, sbzbs, pinType } = data;
  // let array = [];
  // const id = new Date().valueOf();

  // try {
  //   array = JSON.parse(sbzbs);
  // } catch (e) {
  //   console.error(e);
  // }

  // function phoneCall(id, value) {
  //   if (typeof makeCall === 'function') {
  //     makeCall(id, value);
  //   }
  // }

  // function showVideo(videoSrc, index) {
  //   console.log('videoSrc', videoSrc);
  //   const dom = document.createElement('div');
  //   document.body.appendChild(dom);
  //   dom.id = 'video_wrapper_map';
  //   dom.style = 'cursor: pointer; position: fixed; top: 0; right: 0; bottom: 0; left: 0; background-color: rgba(0, 0, 0, 0.5)';
  //   dom.onclick = () => {
  //     document.body.removeChild(dom);
  //   };
  //   ReactDOM.render(<Video videoSrc={videoSrc} index={index} onClose={() => { const el = document.getElementById('video_wrapper_map'); if (el) { document.body.removeChild(el) } }} />, dom);
  // }

  ReactDOM.render(
    // <div className={`popup_dom_wrapper`}>
    //   <div className={`popup_dom_title`}>{name}</div>
    //   <div style={{ padding: '0 32px' }}>
    //     <table className={`popup_dom_content`}>
    //       <tbody>
    //         {address &&
    //           <tr>
    //             <td style={{ minWidth: pinType && pinType.indexOf('ZJGD') !== -1 ? 260 : 260, color: '#00c2ff' }}>地址</td>
    //             <td>{address}</td>
    //           </tr>
    //         }
    //         {infotype &&
    //           <tr>
    //             <td style={{ minWidth: pinType && pinType.indexOf('ZJGD') !== -1 ? 260 : 260, color: '#00c2ff' }}>类型</td>
    //             <td>{infotype}</td>
    //           </tr>
    //         }
    //         {array && array.length > 0 &&
    //           array.map((item, index) => {
    //             let { name, value } = item;
    //             value = typeof value === 'string' ? value.replace(/\r\n/g, '') : value;
    //             let isPhone = /*pinType && pinType.indexOf('ZJGD') !== -1 &&*/ /^([0-9]{3,4}(-)?)?[0-9]{7,8}$/.test(value) || /^1(3|4|5|6|7|8|9)\d{9}$/.test(value);
    //             let isVideo = name && name === '视频编号';
    //             const arrayValue = value && typeof value.split === 'function' ? value.split('/') : undefined;

    //             return (
    //               <tr key={index}>
    //                 <td style={{ minWidth: pinType && pinType.indexOf('ZJGD') !== -1 ? 260 : 260, color: '#00c2ff' }}>{name}</td>
    //                 <td>
    //                   {value === '5星' ?
    //                     <div className='cn_arcgis_popup_value'>
    //                       <div className='star'></div>
    //                       <div className='star'></div>
    //                       <div className='star'></div>
    //                       <div className='star'></div>
    //                       <div className='star'></div>
    //                     </div> :
    //                     value === '4星' ?
    //                       <div className='cn_arcgis_popup_value'>
    //                         <div className='star'></div>
    //                         <div className='star'></div>
    //                         <div className='star'></div>
    //                         <div className='star'></div>
    //                       </div> :
    //                       value === '3星' ?
    //                         <div className='cn_arcgis_popup_value'>
    //                           <div className='star'></div>
    //                           <div className='star'></div>
    //                           <div className='star'></div>
    //                         </div> :
    //                         value === '2星' ?
    //                           <div className='cn_arcgis_popup_value'>
    //                             <div className='star'></div>
    //                             <div className='star'></div>
    //                           </div> :
    //                           value === '1星' ?
    //                             <div className='cn_arcgis_popup_value'>
    //                               <div className='star'></div>
    //                             </div> :
    //                             <div className='cn_arcgis_popup_value'>
    //                               {arrayValue && arrayValue.length > 1 ?
    //                                 arrayValue.map((v, i) => {
    //                                   isPhone = /*pinType && pinType.indexOf('ZJGD') !== -1 &&*/ /^([0-9]{3,4}(-)?)?[0-9]{7,8}$/.test(v) || /^1(3|4|5|6|7|8|9)\d{9}$/.test(v);

    //                                   return (
    //                                     <div key={i}>
    //                                       {v}
    //                                       {!!showPhone && !!isPhone &&
    //                                         <Fragment>
    //                                           <div id={`${id}-array-${i}-phone-call`} className='phone-icon phone-call' onClick={() => phoneCall(`${id}-array-${i}`, v)} />
    //                                           <div id={`${id}-array-${i}-phone-forwarded`} className='phone-icon phone-forwarded' />
    //                                           <div id={`${id}-array-${i}-phone-off-disabled`} className='phone-icon phone-off-disabled' />
    //                                           <div id={`${id}-array-${i}-phone-off`} className='phone-icon phone-off' onClick={() => hangupCall()} />
    //                                         </Fragment>
    //                                       }
    //                                       {isVideo &&
    //                                         <div className='phone-icon video-show' onClick={() => showVideo(arrayValue, i)} />
    //                                       }
    //                                     </div>
    //                                   );
    //                                 }) :
    //                                 <Fragment>
    //                                   {value}
    //                                   {!!showPhone && !!isPhone &&
    //                                     <Fragment>
    //                                       <div id={`${id}-${index}-phone-call`} className='phone-icon phone-call' onClick={() => phoneCall(`${id}-${index}`, value)} />
    //                                       <div id={`${id}-${index}-phone-forwarded`} className='phone-icon phone-forwarded' />
    //                                       <div id={`${id}-${index}-phone-off-disabled`} className='phone-icon phone-off-disabled' />
    //                                       <div id={`${id}-${index}-phone-off`} className='phone-icon phone-off' onClick={() => hangupCall()} />
    //                                     </Fragment>
    //                                   }
    //                                   {isVideo &&
    //                                     <div className='phone-icon video-show' onClick={() => showVideo([value])} />
    //                                   }
    //                                 </Fragment>
    //                               }
    //                             </div>
    //                   }
    //                 </td>
    //               </tr>
    //             )
    //           })
    //         }
    //       </tbody>
    //     </table>
    //   </div>
    // </div>,
    <Index data={data} showPhone={showPhone} makeCall={makeCall} hangupCall={hangupCall} postClick={postClick} parent={parent} videoFusion={videoFusion} />,
    dom
  );

  return dom;
}
