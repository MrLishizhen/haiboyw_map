import React from 'react';
import axios from 'axios';
import Video from './clearVideo';

export default class Index extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            current: 1,
            pageSize: 6,
            videoList: [
                { type: 'empty' }, { type: 'empty' }, { type: 'empty' }, { type: 'empty' }, { type: 'empty' }, { type: 'empty' }, { type: 'empty' }, { type: 'empty' }
            ]
        };
    }

    componentDidMount() {
        const { name, parentName } = this.props;

        axios.post(
            'http://10.207.204.33:5479/sign/vedioservice/tree', { catalogType: 'BASIC_PLAN' }
        ).then(response => {
            const { status, data } = response;

            if (status == 200) {
                const { result } = data;
                const { data: list } = result;

                const sf = list.filter(item => {
                    return item.title === (parentName || '司法矫正');
                })[0];

                if (sf) {
                    // const names = [];
                    list.forEach(item => {
                        // if (item.parentId === sf.id && item.deviceCount > 0) {
                        //     console.info(item.title, item.deviceCount);
                        //     names.push(`update TFSQL_1626226943172 set videos='${item.deviceCount}' where B = '${item.title}';`);
                        // }
                        if (item.parentId === sf.id && item.title === name) {
                            axios.post(
                                'http://10.207.204.33:5479/sign/vedioservice/planDeviceId', { planId: item.id }
                            ).then((response2) => {
                                const { status, data } = response2;

                                if (status == 200) {
                                    const { result } = data;
                                    const { data: videoList } = result;

                                    if (Array.isArray(videoList) && videoList.length > 0) {
                                        this.setState({ videoList });
                                    }
                                }
                            })
                        }
                    });
                    // console.info(names.join(''));
                }
            }
        });
    }

    componentWillUnmount() {
        console.info('componentWillUnmount');
    }

    onChange(type, e) {
        if (e && e.stopPropagation) {
            e.stopPropagation();
        }
        const { current, pageSize, videoList = [] } = this.state;

        if (type === 'next') {
            const cnt = Math.ceil(videoList.length / pageSize);
            if (current < cnt) {
                this.setState({ current: current + 1 })
            }
        } else if (type === 'prev') {
            if (current > 1) {
                this.setState({ current: current - 1 })
            }
        }
    }

    render() {
        const { parentName } = this.props;
        const { current, pageSize, videoList = [] } = this.state;

        return (
            <div style={
                parentName && videoList.length <= 1 ?
                    { width: 2950, height: 1683, position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)' } :
                    { width: '90%', height: '90%', backgroundColor: '#000000', position: 'absolute', top: '5%', left: '5%' }
            }
            >
                {videoList && videoList.length > pageSize && <div className='video-list-btn prev' onClick={this.onChange.bind(this, 'prev')} />}
                <div className='video-list-wrapper' style={videoList && videoList.length > pageSize ? {} : { width: '100%', height: '100%' }}>
                    {videoList && videoList.length > 0 &&
                        videoList.slice((current - 1) * pageSize, current * pageSize).map((video, index) => {
                            return (
                                video && video.type !== 'empty' ?
                                    <div index={video.id || index} style={parentName && videoList.length === 1 ? { width: '100%', height: '100%' } : {}} onClick={() => { if (this.props.onClick && videoList.length > 1) { this.props.onClick(video.deviceId) } }} >
                                        <Video videoSrc={video.deviceId} scale={1} wrapperStyle={{ width: '96%', height: '96%', padding: '2%', backgroundColor: '#000000' }} style={{ width: '100%', height: '100%' }} />
                                    </div> :
                                    <div index={video.id || index}>
                                        <div style={{ display: 'table', width: '100%', height: '100%' }}>
                                            <div style={{ display: 'table-cell', verticalAlign: 'middle' }}>暂无数据</div>
                                        </div>
                                    </div>
                            );
                        })
                    }
                </div>
                {videoList && videoList.length > pageSize && <div className='video-list-btn next' onClick={this.onChange.bind(this, 'next')} />}
                {videoList && videoList.length > pageSize &&
                    <div className='video-list-pagination'>
                        <div style={{ display: 'table', width: '100%', height: '100%' }}>
                            <div style={{ display: 'table-cell', verticalAlign: 'middle', textAlign: 'center' }}>{current}/{Math.ceil(videoList.length / pageSize)}</div>
                        </div>
                    </div>
                }
            </div>
        )
    }
}