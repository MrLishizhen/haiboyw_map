import React, { Fragment } from 'react';
import ReactDOM from 'react-dom';
import Video from './clearVideo';
import VideoList from './VideoList';
import './index.css';

export default function popDefault(dom, data, showPhone, makeCall, hangupCall, postClick) {
  const { name, address, infotype, pinType, sbzbs } = data;
  let array = [];
  const id = new Date().valueOf();

  try {
    if (typeof sbzbs === 'string') {
      array = JSON.parse(sbzbs);
    } else {
      array = sbzbs;
    }
  } catch (e) {
    console.error(e);
  }

  function onClick() {
    let dom = document.createElement('div');
    dom.style = `
      position: fixed;
      top:0;
      right: 0;
      bottom: 0;
      left: 0;
      z-index: 9999;
      background-color: rgba(0,0,0,0.6);
    `;
    let img = document.createElement('img');
    img.src = infotype;
    img.style = `
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    `;
    dom.appendChild(img);
    dom.onclick = function () {
      document.body.removeChild(dom);
    }
    document.body.appendChild(dom);
  }

  function showVideo(videoSrc, index, name, itemName) {
    console.log('videoSrc', videoSrc);
    const wrapper = document.getElementById('panel_canvas');
    let scale = 0;
    if (wrapper) {
      scale = Math.min(document.body.clientWidth / wrapper.offsetWidth, document.body.clientHeight / wrapper.offsetHeight);
    }
    const dom = document.createElement('div');
    document.body.appendChild(dom);
    dom.id = 'video_wrapper';
    if (scale > 0) {
      dom.style = `cursor: pointer; position: fixed; top: 0; right: 0; left: 0; height: ${wrapper.offsetHeight * scale}px;  background-color: rgba(0, 0, 0, 0.5); z-index: 1`;
    } else {
      dom.style = 'cursor: pointer; position: fixed; top: 0; right: 0; bottom: 0; left: 0; background-color: rgba(0, 0, 0, 0.5); z-index: 1';
    }
    dom.onclick = (e) => {
      if (e && e.target && e.target.id === 'video_wrapper') {
        ReactDOM.unmountComponentAtNode(dom);
        document.body.removeChild(dom);
      }
    };
    if (itemName === '视频列表') {
      ReactDOM.render(<VideoList name={name} />, dom);
    } else {
      ReactDOM.render(<Video videoSrc={videoSrc} index={index} onClose={() => { const el = document.getElementById('video_wrapper'); if (el) { document.body.removeChild(el) } }} />, dom);
    }
  }

  ReactDOM.render(
    <div className={`popup_dom_wrapper`} style={{ maxWidth: 1200 }}>
      <div className={`popup_dom_title`}>{name}</div>
      <div style={{ padding: '0 32px' }}>
        {infotype &&
          <div style={{ display: 'inline-block', verticalAlign: 'middle', cursor: 'pointer' }} onClick={onClick}>
            <img src={infotype} style={{ width: 256, height: '100%' }} />
          </div>
        }
        <div style={!infotype || (!infotype.startsWith('http://') && !infotype.startsWith('/fastdfs')) ? {} : { display: 'inline-block', verticalAlign: 'middle', marginLeft: 32, maxWidth: 750 }}>
          <table className={`popup_dom_content`}>
            <tbody>
              {address &&
                <tr>
                  <td style={{ minWidth: 240, color: '#00c2ff' }}>{pinType === 'AIZYs' ? '监控点位' : '地址'}</td>
                  <td>{address}</td>
                </tr>
              }
              {infotype && !infotype.startsWith('http://') && !infotype.startsWith('/fastdfs') &&
                <tr>
                  <td style={{ minWidth: 240, color: '#00c2ff' }}>类型</td>
                  <td>{infotype}</td>
                </tr>
              }
              {array && array.length > 0 &&
                array.map((item, index) => {
                  let { name: itemName, value } = item;
                  value = typeof value === 'string' ? value.replace(/\r\n/g, '') : value;
                  let isPhone = /*pinType && pinType.indexOf('ZJGD') !== -1 &&*/ /^([0-9]{3,4}(-)?)?[0-9]{7,8}$/.test(value) || /^1(3|4|5|6|7|8|9)\d{9}$/.test(value);
                  let isVideo = itemName && (itemName === '视频编号' || itemName === '视频列表');
                  const isPostClick = itemName.indexOf('_postClick');
                  const arrayValue = value && typeof value.split === 'function' ? value.split('/') : undefined;

                  return (
                    <tr key={index} className={isPostClick !== -1 ? 'popup_dom_item_hover' : ''} onClick={isPostClick !== -1 ? () => { if (typeof postClick === 'function') postClick({ ...data, clickNode: itemName }) } : undefined}>
                      <td style={{ minWidth: pinType && pinType.indexOf('ZJGD') !== -1 ? 280 : 240, color: '#00c2ff' }}>{isPostClick !== -1 ? itemName.substring(0, isPostClick) : itemName}</td>
                      <td>
                        {value === '5星' ?
                          <div className='cn_arcgis_popup_value'>
                            <div className='star'></div>
                            <div className='star'></div>
                            <div className='star'></div>
                            <div className='star'></div>
                            <div className='star'></div>
                          </div> :
                          value === '4星' ?
                            <div className='cn_arcgis_popup_value'>
                              <div className='star'></div>
                              <div className='star'></div>
                              <div className='star'></div>
                              <div className='star'></div>
                            </div> :
                            value === '3星' ?
                              <div className='cn_arcgis_popup_value'>
                                <div className='star'></div>
                                <div className='star'></div>
                                <div className='star'></div>
                              </div> :
                              value === '2星' ?
                                <div className='cn_arcgis_popup_value'>
                                  <div className='star'></div>
                                  <div className='star'></div>
                                </div> :
                                value === '1星' ?
                                  <div className='cn_arcgis_popup_value'>
                                    <div className='star'></div>
                                  </div> :
                                  <div className='cn_arcgis_popup_value'>
                                    {arrayValue && arrayValue.length > 1 ?
                                      arrayValue.map((v, i) => {
                                        isPhone = /*pinType && pinType.indexOf('ZJGD') !== -1 &&*/ /^([0-9]{3,4}(-)?)?[0-9]{7,8}$/.test(v) || /^1(3|4|5|6|7|8|9)\d{9}$/.test(v);

                                        return (
                                          <div key={i}>
                                            {v}
                                            {!!showPhone && !!isPhone &&
                                              <Fragment>
                                                <div id={`${id}-array-${i}-phone-call`} className='phone-icon phone-call' onClick={() => phoneCall(`${id}-array-${i}`, v)} />
                                                <div id={`${id}-array-${i}-phone-forwarded`} className='phone-icon phone-forwarded' />
                                                {/* <div id={`${id}-array-${i}-phone-off-disabled`} className='phone-icon phone-off-disabled' /> */}
                                                <div id={`${id}-array-${i}-phone-off`} className='phone-icon phone-off' onClick={() => hangupCall()} />
                                              </Fragment>
                                            }
                                            {isVideo &&
                                              <div className='phone-icon video-show' onClick={() => showVideo(arrayValue, i)} />
                                            }
                                          </div>
                                        );
                                      }) :
                                      <Fragment>
                                        {value}
                                        {!!showPhone && !!isPhone &&
                                          <Fragment>
                                            <div id={`${id}-${index}-phone-call`} className='phone-icon phone-call' onClick={() => phoneCall(`${id}-${index}`, value)} />
                                            <div id={`${id}-${index}-phone-forwarded`} className='phone-icon phone-forwarded' />
                                            {/* <div id={`${id}-${index}-phone-off-disabled`} className='phone-icon phone-off-disabled' /> */}
                                            <div id={`${id}-${index}-phone-off`} className='phone-icon phone-off' onClick={() => hangupCall()} />
                                          </Fragment>
                                        }
                                        {isVideo &&
                                          <div className='phone-icon video-show' onClick={() => showVideo([value], 0, name, itemName)} />
                                        }
                                      </Fragment>
                                    }
                                  </div>
                        }
                      </td>
                    </tr>
                  )
                })
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>,
    dom
  );

  return dom;
}
