import React, { Fragment } from 'react';
import ReactDOM from 'react-dom';
import './wjPopUp.css';

const CONST_LIST_ITEM = {
  '二次供水': ['检测单位', '采样日期', '色度', '浑浊度', '菌落总数', '总大肠菌群', '总氟', 'PH', '检测结果']
}

export default function popDefault(dom, data, callback) {
  const { name, address, infotype, sbzbs, pinType, extra, list } = data;
  let array = [];
  let newList = [];
  let newExtra = [];
  const id = new Date().valueOf();
  let interval = -10, etraDom = undefined, etraList = undefined;

  try {
    if (typeof sbzbs === 'string') {
      array = JSON.parse(sbzbs);
    } else {
      array = sbzbs;
    }

    if (typeof extra === 'string') {
      newExtra = JSON.parse(extra);
    } else {
      newExtra = extra;
    }

    if (typeof list === 'string') {
      newList = JSON.parse(list);
    } else {
      newList = list;
    }
  } catch (e) {
    console.error(e);
  }

  function onClick(name, data = {}) {
    if (name) {
      if (name === 'item_detail') {
        if (etraList) {
          let dom = etraList[1];
          const { info = [], extra = [] } = data;

          if (!dom) {
            dom = document.createElement('div');
            dom.className = 'wj_popup_dom_wrapper';
            document.getElementById('wj_pop_up_main').appendChild(dom);
            etraList.push(dom)
          }
          dom.innerHTML = `
            <div>
              <div class='wj_popup_dom_line'></div>
              <div>
                <table class='wj_popup_dom_content'>
                  <tbody>
                    ${info && info.map(item => {
            return (
              `<tr class=''>
                            <td style="min-width: 150px;">${item.name}</td>
                            <td style="min-width: 250px;">${item.value || '暂无数据'}</td>
                          </tr>`
            )
          }).join('')}
                    ${extra && extra.map(item => {
            return (
              `<tr class=''>
                          <td style="min-width: 150px;">${item.name}</td>
                          <td style="min-width: 250px;">${item.value || '暂无数据'}</td>
                        </tr>`
            )
          }).join('')}
                  </tbody>
                </table>
              </div>  
            </div>
          `;
        }
      } else if (name.indexOf('_click_list') !== -1) {
        if (etraDom) {
          document.getElementById('wj_pop_up_main').removeChild(etraDom);
          etraDom = undefined;
        }
        if (etraList) {
          etraList.forEach(dom => {
            document.getElementById('wj_pop_up_main').removeChild(dom);
          });
          etraList = undefined;
        } else {
          const dom = document.createElement('div');
          dom.className = 'wj_popup_dom_wrapper';
          document.getElementById('wj_pop_up_main').appendChild(dom);
          dom.innerHTML = `
            <div>
              <div class='wj_popup_dom_line'></div>
              <div>
                <table class='wj_popup_dom_content list'>
                    <tbody>
                      <tr>
                        <td style="min-width: 100px;">序号</td>
                        <td style="min-width: 300px;">位置</td>
                      </tr>
                      ${newList && newList.length > 0 &&
            newList.map(((item, index) => {
              const { info = [] } = item
              const i = info.filter(i => i.name === '储水设备位置' || i.name === '检测位置')[0] || {};

              return (
                `<tr class='wj_popup_dom_item_hover wj_popup_dom_list_item'>
                              <td>${index + 1}</td>
                              <td>
                                <div style="float: left">${i.value}</div>
                                <div style="float: right; marginLeft: 32px;">>></div>
                              </td>
                            </tr>`
              )
            })).join('')}
                    </tbody>
                  </tbody>
                </table>
              </div>
            </div>
          `;
          const items = document.getElementsByClassName('wj_popup_dom_list_item');
          if (items) {
            for (let i = 0; i < items.length; i++) {
              items[i].addEventListener('click', function () {
                onClick('item_detail', newList[i]);
              });
            }
          }

          etraList = [dom];
        }
      } else if (name.indexOf('_click') !== -1) {
        if (etraList) {
          etraList.forEach(dom => {
            document.getElementById('wj_pop_up_main').removeChild(dom);
          });
          etraList = undefined;
        }
        if (etraDom) {
          document.getElementById('wj_pop_up_main').removeChild(etraDom);
          etraDom = undefined;
        } else {
          etraDom = document.createElement('div');

          if (pinType.indexOf('管道分质供水') !== -1) {
            const e = newExtra.filter(i => i.name === '检测结果')[0] || {};

            if (e.value) {
              document.body.appendChild(etraDom);
              etraDom.style = "position: absolute; top: 0; right: 0; bottom: 0; left: 0; background-color: rgba(0, 0, 0, 0.6); z-index: 9999;";
              etraDom.innerHTML = `
                <img src='${e.value ? e.value.startsWith('http://') ? e.value : `http://bigdata.cn.gov:8070${e.value}` : ''}' style="cursor: pointer; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);" />
              `;
              etraDom.addEventListener('click', function () {
                document.body.removeChild(etraDom);
                etraDom = undefined;
              });
            }
          } else {
            etraDom.className = 'wj_popup_dom_wrapper';
            document.getElementById('wj_pop_up_main').appendChild(etraDom);
            etraDom.innerHTML = `
            <div>
              <div class='wj_popup_dom_line'></div>
              <div>
                <table class='wj_popup_dom_content'>
                    <tbody>
                        ${newExtra && newExtra.map((item, index) => {
              return (
                `<tr>
                              <td style="min-width: 150px;">${item.name}</td>
                              <td style="color: #799fdf; padding-left: 16px; min-width: 250px;">${item.value || '暂无数据'}</td>
                            </tr>`
              );
            }).join('')}
                    </tbody>
                </table>
              </div>
            </div>
          `;
          }
        }
      }
      callback(interval);
      interval = -interval;
    }
  }

  ReactDOM.render(
    <div id='wj_pop_up_main' style={{ overflow: 'hidden' }}>
      <div className={'wj_popup_dom_wrapper'}>
        <div className='wj_popup_dom_line' />
        <div>
          <table className='wj_popup_dom_content'>
            <tbody>
              <tr>
                <td style={{ minWidth: 300 }}>名称</td>
                <td style={{ color: '#799fdf', paddingLeft: '16px' }}>{name}</td>
              </tr>
              {address &&
                <tr>
                  <td>地址</td>
                  <td style={{ color: '#799fdf', paddingLeft: '16px' }}>{address}</td>
                </tr>
              }
              {infotype &&
                <tr>
                  <td>类型</td>
                  <td style={{ color: '#799fdf', paddingLeft: '16px' }}>{infotype}</td>
                </tr>
              }
              {array && array.length > 0 &&
                array.map((item, index) => {
                  const { name, value } = item;
                  const isClick = name.indexOf('_click');

                  return (
                    <tr className={isClick !== -1 ? 'wj_popup_dom_item_hover' : ''} key={index} onClick={isClick !== -1 ? () => onClick(name) : undefined}>
                      <td >{name ? isClick !== -1 ? name.substring(0, isClick) : name : ''}</td>
                      {isClick === -1 ?
                        <td style={{ color: '#799fdf', paddingLeft: '16px' }}>{value}</td> :
                        <td style={{ color: '#799fdf', paddingLeft: '16px' }}>
                          <div style={{ float: 'left' }}>{value}</div>
                          <div style={{ float: 'right' }}>>></div>
                        </td>
                      }
                    </tr>
                  )
                })
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>,
    dom
  );

  return dom;
}
