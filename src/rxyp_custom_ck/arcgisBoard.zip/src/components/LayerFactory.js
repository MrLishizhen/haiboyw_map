import esriLoader from 'esri-loader';

import './popups/newPopUp.css';

/** 长宁区图层 **/
const generateBoundaryLayer = (FeatureLayer, version, spatialReference, definitionExpression) => {
    return new FeatureLayer({
        url: version === 'new' ?
            'http://10.89.5.191/OneMapServer/rest/services/BOUNDARY/MapServer' :
            'http://10.207.204.19/server/rest/services/Hosted/County/FeatureServer',
        renderer: {
            type: 'simple',
            symbol: {
                type: 'simple-line',
                width: 3,
                color: [255, 255, 255, 1],
                style: 'solid',
            },
        },
        minScale: 0,
        maxScale: 0,
        spatialReference,
        title: '长宁边界',
        definitionExpression
    });
};

const generateShadowBoundaryLayer = (FeatureLayer, version, spatialReference, definitionExpression) => {
    const shadowRender = (step) => {
        const total = 25, show = 10, part = 10;
        const per = Math.ceil(show / part);
        const result = [];
        let currentPart = 1;

        for (let i = 1; i <= show; i++) {
            if (i > currentPart * per) {
                currentPart++;
            }
            result.push({
                value: step + (i - 1) * step,
                symbol: {
                    type: 'simple-fill',
                    color: [19, 62, 100, 1 - (1 / part) * (currentPart - 1)],
                    style: 'solid',
                    outline: {
                        width: 0
                    }
                }
            });
        }

        return result;
    };

    return new FeatureLayer({
        url: 'http://10.89.5.191/OneMapServer/rest/services/cn_boundary/MapServer/0',
        renderer: {
            type: 'unique-value',
            field: 'distance',
            defaultSymbol: {
                type: 'simple-fill',
                color: [0, 0, 0, 1],
                style: 'solid',
                outline: {
                    color: [110, 110, 110, 1],
                    width: 0
                }
            },
            uniqueValueInfos: shadowRender(15)
        },
        minScale: 0,
        maxScale: 0,
        spatialReference,
        title: '长宁边界光圈',
        definitionExpression: `distance<=150`
    });
};

const generateMaskBoundaryLayer = (FeatureLayer, version, spatialReference, definitionExpression) => {
    return new FeatureLayer({
        url: 'http://10.89.5.191/OneMapServer/rest/services/cn_boundary/MapServer/1',
        minScale: 0,
        maxScale: 0,
        spatialReference,
        // renderer: {
        //     type: 'simple',
        //     symbol: {
        //         type: 'simple-fill',
        //         color: [0, 8, 16, 1],
        //         style: 'solid',
        //         outline: {
        //             width: 0
        //         }
        //     },
        // },
        title: '长宁边界遮罩',
    });
};

const generateStreetLayer = (FeatureLayer, LabelClass, version, spatialReference, renderer, definitionExpression, color, popupTemplate, region, labelingInfo, id) => {
    return new FeatureLayer({
        url:
            version === 'new' ?
                (
                    region && (region.indexOf('临空') !== -1 || region.indexOf('长宁-数字驾驶舱') !== -1) ?
                        'http://10.89.5.191/OneMapServer/rest/services/street_11_linkong/FeatureServer/0' :
                        'http://10.89.5.191/OneMapServer/rest/services/STREEt_testzyy/MapServer/0'
                ) :
                'http://10.207.204.19/server/rest/services/Hosted/Street/FeatureServer',
        renderer:
            renderer || {
                type: 'unique-value',
                field: 'NAME',
                defaultSymbol: {
                    type: 'simple-fill',
                    color: [0, 0, 0, 0],
                    style: 'solid',
                    outline: {
                        color: color || [200, 255, 200, 1],
                        // color: color || [205, 199, 252, 1],
                        width: 2
                    }
                }
            },
        popupTemplate,
        labelingInfo:
            labelingInfo ? labelingInfo :
                (
                    renderer ?
                        [] : [
                            { 'name': '新华路街道', alias: '新华', color: [205, 199, 252, 1] },
                            { 'name': '江苏路街道', alias: '江苏', color: [211, 255, 190, 1] },
                            { 'name': '华阳路街道', alias: '华阳', color: [255, 211, 127, 1] },
                            { 'name': '周家桥街道', alias: '周家桥', color: [252, 250, 184, 1] },
                            { 'name': '天山路街道', alias: '天山', color: [255, 190, 190, 1] },
                            { 'name': '仙霞新村街道', alias: '仙霞', color: [211, 255, 190, 1] },
                            { 'name': '虹桥街道', alias: '虹桥', color: [252, 212, 237, 1] },
                            { 'name': '程家桥街道', alias: '程家桥', color: [190, 232, 255, 1], labelPlacement: 'always-horizontal' },
                            { 'name': '北新泾街道', alias: '北新泾', color: [252, 224, 212, 1] },
                            { 'name': '新泾镇', alias: '新泾镇', color: [255, 204, 190, 1] },
                        ].map(item => {
                            return new LabelClass({
                                labelPlacement: 'above-center',
                                // labelExpressionInfo: { expression: '$feature.NAME' },
                                labelExpressionInfo: { expression: `'${item.alias}'` },
                                labelPlacement: item.labelPlacement,
                                symbol: {
                                    type: 'text',
                                    color: item.color,
                                    font: {
                                        size: 36,
                                        weight: 'bold'
                                    },
                                    haloSize: 0,
                                    haloColor: 'white'
                                },
                                where: `NAME = '${item.name}'`
                            });
                        })
                ),
        // renderer: {
        //     type: 'unique-value',
        //     field: 'NAME',
        //     defaultSymbol: {
        //         type: 'simple-fill',
        //         color: [0, 0, 0, 0.6],
        //         style: 'solid',
        //         outline: {
        //             color: [110, 110, 110, 1],
        //             width: 0
        //         }
        //     },
        //     uniqueValueInfos: [
        //         {
        //             value: '仙霞新村街道',
        //             label: '仙霞新村街道',
        //             symbol: {
        //                 type: 'simple-fill',
        //                 color: [211, 255, 190, 1],
        //                 style: 'solid',
        //                 outline: {
        //                     color: [178, 178, 178, 1],
        //                     width: 0
        //                 }
        //             }
        //         },
        //         {
        //             value: '北新泾街道',
        //             label: '北新泾街道',
        //             symbol: {
        //                 type: 'simple-fill',
        //                 color: [252, 224, 212, 1],
        //                 style: 'solid',
        //                 outline: {
        //                     color: [178, 178, 178, 1],
        //                     width: 0
        //                 }
        //             }
        //         },
        //         {
        //             value: '华阳路街道',
        //             label: '华阳路街道',
        //             symbol: {
        //                 type: 'simple-fill',
        //                 color: [255, 211, 127, 1],
        //                 style: 'solid',
        //                 outline: {
        //                     color: [178, 178, 178, 1],
        //                     width: 0
        //                 }
        //             }
        //         },
        //         {
        //             value: '周家桥街道',
        //             label: '周家桥街道',
        //             symbol: {
        //                 type: 'simple-fill',
        //                 color: [252, 250, 184, 1],
        //                 style: 'solid',
        //                 outline: {
        //                     color: [178, 178, 178, 1],
        //                     width: 0
        //                 }
        //             }
        //         },
        //         {
        //             value: '天山路街道',
        //             label: '天山路街道',
        //             symbol: {
        //                 type: 'simple-fill',
        //                 color: [255, 190, 190, 1],
        //                 style: 'solid',
        //                 outline: {
        //                     color: [178, 178, 178, 1],
        //                     width: 0
        //                 }
        //             }
        //         },
        //         {
        //             value: '新华路街道',
        //             label: '新华路街道',
        //             symbol: {
        //                 type: 'simple-fill',
        //                 color: [205, 199, 252, 1],
        //                 style: 'solid',
        //                 outline: {
        //                     color: [178, 178, 178, 1],
        //                     width: 0
        //                 }
        //             }
        //         },
        //         {
        //             value: '新泾镇',
        //             label: '新泾镇',
        //             symbol: {
        //                 type: 'simple-fill',
        //                 color: [255, 204, 190, 1],
        //                 style: 'solid',
        //                 outline: {
        //                     color: [178, 178, 178, 1],
        //                     width: 0
        //                 }
        //             }
        //         },
        //         {
        //             value: '江苏路街道',
        //             label: '江苏路街道',
        //             symbol: {
        //                 type: 'simple-fill',
        //                 color: [211, 255, 190, 1],
        //                 style: 'solid',
        //                 outline: {
        //                     color: [178, 178, 178, 1],
        //                     width: 0
        //                 }
        //             }
        //         },
        //         {
        //             value: '程家桥街道',
        //             label: '程家桥街道',
        //             symbol: {
        //                 type: 'simple-fill',
        //                 color: [190, 232, 255, 1],
        //                 style: 'solid',
        //                 outline: {
        //                     color: [190, 232, 255, 1],
        //                     width: 0
        //                 }
        //             }
        //         },
        //         {
        //             value: '虹桥街道',
        //             label: '虹桥街道',
        //             symbol: {
        //                 type: 'simple-fill',
        //                 color: [252, 212, 237, 1],
        //                 style: 'solid',
        //                 outline: {
        //                     color: [190, 232, 255, 1],
        //                     width: 0
        //                 }
        //             }
        //         }
        //     ]
        // },
        minScale: 0,
        maxScale: 0,
        spatialReference,
        id: id || '长宁区街道',
        title: '长宁区街道',
        definitionExpression
    });
};

const generateWanggeLayer = (FeatureLayer, LabelClass, version, spatialReference, renderer, definitionExpression, zrwg = []) => {
    let labelClass = undefined;
    if (LabelClass) {
        labelClass = new LabelClass({
            labelExpressionInfo: { expression: '$feature.网格编码' },
            symbol: {
                type: 'text',
                color: [200, 200, 255, 1],
                font: {
                    size: 32,
                    family: 'sans-serif',
                },
                haloSize: 0,
                haloColor: 'white'
            },
            labelPlacement: 'always-horizontal'
        });
    }

    const layer = new FeatureLayer({
        url:
            version === 'new' ?
                'http://10.89.5.191/OneMapServer/rest/services/Hosted_wangge/FeatureServer/0' :
                'http://10.207.204.19/server/rest/services/Hosted/wangge/FeatureServer',
        renderer:
            renderer || {
                type: 'simple',
                symbol: {
                    type: 'simple-fill',
                    color: [247, 242, 200, 0],
                    style: 'solid',
                    outline: {
                        color: [200, 200, 255, 1],
                        width: 1
                    }
                },
            },
        labelingInfo: labelClass ? [labelClass] : undefined,
        outFields: ['*'],
        minScale: 0,
        maxScale: 0,
        spatialReference,
        title: '长宁网格',
        popupTemplate:
            zrwg && zrwg.length > 0 ?
                {
                    title: '',
                    outFields: ['*'],
                    content: function (feature) {
                        if (zrwg && feature && feature.graphic && feature.graphic.attributes) {
                            // feature.graphic.layer.renderer = {
                            //     type: 'unique-value',
                            //     field: '网格编码',
                            //     defaultSymbol: {
                            //         type: 'simple-fill',
                            //         color: [247, 242, 200, 0],
                            //         style: 'solid',
                            //         outline: {
                            //             color: [200, 200, 255, 1],
                            //             width: 1
                            //         }
                            //     },
                            //     uniqueValueInfos: [
                            //         {
                            //             value: feature.graphic.attributes.网格编码,
                            //             symbol: {
                            //                 type: 'simple-fill',
                            //                 color: 'red',
                            //                 style: 'solid',
                            //                 outline: {
                            //                     color: [178, 178, 178, 1],
                            //                     width: 0
                            //                 }
                            //             }
                            //         }
                            //     ]
                            // }
                            // feature.graphic.layer.refresh();

                            const code = feature.graphic.attributes.网格编码;
                            const data = zrwg.filter(item => item.网格编码 === code)[0];

                            if (data) {
                                return `
                                    <div class='popup_dom_wrapper' style='border-radius: 0'>
                                        <div class='popup_dom_title'>${data.网格编码}</div>
                                        <div style='padding: 0 32px'>
                                            <table class='popup_dom_content'>
                                                <tbody>
                                                    <tr>
                                                        <td style='min-width: 240px; color: #00c2ff'>街镇园区</td>
                                                        <td>${data.街镇园区}</td>
                                                    </tr>
                                                    <tr>
                                                        <td style='min-width: 240px; color: #00c2ff'>网格长</td>
                                                        <td>${data.姓名}</td>
                                                    </tr>
                                                    <tr>
                                                        <td style='min-width: 240px; color: #00c2ff'>职务</td>
                                                        <td>${data.职务}</td>
                                                    </tr>
                                                    <tr>
                                                        <td style='min-width: 240px; color: #00c2ff'>联动站点</td>
                                                        <td>${data.联勤联动}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    `;
                            }
                        }
                    }
                } : undefined,
        definitionExpression
    });

    return layer;
};

const generateJuweiLayer = (FeatureLayer, LabelClass, version, spatialReference, renderer, definitionExpression) => {
    let labelClass = undefined;
    if (LabelClass) {
        labelClass = new LabelClass({
            labelExpressionInfo: { expression: '$feature.居委会代码' },
            symbol: {
                type: 'text',
                color: '#ffab00',
                font: {
                    size: 12,
                },
                haloSize: 0,
                haloColor: 'white'
            }
        });
    }

    return new FeatureLayer({
        url:
            version === 'new' ?
                'http://10.89.5.191/OneMapServer/rest/services/Hosted_juwei/FeatureServer' :
                'http://10.207.204.19/server/rest/services/Hosted/juwei/FeatureServer',
        renderer:
            renderer || {
                type: 'simple',
                symbol: {
                    type: 'simple-fill',
                    color: [242, 205, 189, 0],
                    style: 'solid',
                    outline: {
                        color: '#ffab00',
                        width: 2
                    }
                },
            },
        labelingInfo: labelClass ? [labelClass] : [],
        minScale: 0,
        maxScale: 0,
        spatialReference,
        title: '长宁区村居委',
        definitionExpression
    });
}

const generateBaimoLayer = (SceneLayer, version, spatialReference, renderer, definitionExpression) => {
    return new SceneLayer({
        url: version === 'new' ?
            // 'http://10.89.5.169/server/rest/services/Hosted/changningbaimo2/SceneServer' :
            // 'http://10.89.5.191/OneMapServer/rest/services/changningbaimo2/SceneServer' :
            'http://10.89.5.191/OneMapServer/rest/services/Hosted_baimo_jiedao/SceneServer' :
            'http://10.207.204.19/server/rest/services/Hosted/baimo/SceneServer',
        popupEnabled: false,
        renderer: {
            type: 'simple',
            symbol: {
                type: 'mesh-3d',
                symbolLayers: [
                    {
                        type: 'fill',
                        material: {
                            color: [103, 216, 255, 1],
                            transparency: 0,
                            colorMixMode: 'multiply',
                        },
                        edges: {
                            type: 'solid',
                            color: [0, 0, 0, 0.1],
                            size: 1,
                        },
                    },
                ],
            },
        },
        id: '长宁区三维白模型',
        definitionExpression
    });
};

const generateJingmoLayer = (SceneLayer, MeshLayer, version, spatialReference, renderer, definitionExpression) => {
    return (
        version === 'new' ?
            (
                definitionExpression ?
                    [
                        { url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_biaomo_jiedao/SceneServer', id: '长宁区标准模型_带街道属性', expression: true },
                        // { url: 'http://10.89.5.191/OneMapServer/rest/services/quanxidaolu_road/SceneServer', id: '主干道路全息模型_道路', expression: false },
                        // { url: 'http://10.89.5.191/OneMapServer/rest/services/quanxidaolu_bujian/SceneServer', id: '主干道路全息模型_部件', expression: false },
                        // { url: 'http://10.89.5.191/OneMapServer/rest/services/quanxidaolu_Green/SceneServer', id: '主干道路全息模型_绿化', expression: false },
                    ] :
                    [
                        { url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_cn_jinmo/SceneServer', id: '长宁精模' },
                        // { url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_cn_fencengfenhu/SceneServer', id: '长宁区部分小区分层分户模型' },
                        { url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_cn_bmq_jmq_fcfh/SceneServer', id: '长宁区标准模型（精模及分层分户覆盖区域除外）' },
                        // { url: 'http://10.89.5.191/OneMapServer/rest/services/quanxidaolu_road/SceneServer', id: '主干道路全息模型_道路' },
                        // { url: 'http://10.89.5.191/OneMapServer/rest/services/quanxidaolu_bujian/SceneServer', id: '主干道路全息模型_部件' },
                        // { url: 'http://10.89.5.191/OneMapServer/rest/services/quanxidaolu_Green/SceneServer', id: '主干道路全息模型_绿化' },
                        // { url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_ZFDX_NorthPart_nodemerge/SceneServer', id: '华政步道3d', type: 'meshLayer' },
                        // { url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_dwyQXMX/SceneServer', id: '动物园倾斜摄影模型', type: 'meshLayer' },
                        { url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_SHHZ_ALL/SceneServer', id: '华政步道3d' },
                        { url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_SHDWY_ALL/SceneServer', id: '动物园倾斜摄影模型' },
                    ]
            ) :
            [
                'http://10.207.204.19/server/rest/services/Hosted/biaomo_jm_fcfh/SceneServer',
                'http://10.207.204.19/server/rest/services/Hosted/jingmo/SceneServer',
                'http://10.207.204.19/server/rest/services/Hosted/fencengfenhu01/SceneServer',
            ]
    ).map((item, i) => {
        if (item.type === 'meshLayer') {
            return new MeshLayer({
                url: item.url,
                id: item.id,
            });
        }
        return new SceneLayer({
            url: typeof item === 'object' ? item.url : item,
            popupEnabled: false,
            id: typeof item === 'object' ? item.id : 'building real' + i,
            definitionExpression: item.expression ? definitionExpression : undefined
        });
    });
};

/** 公共方法 **/
const generateShadowBorder = (sdkUrl, url, spatialReference, where, geomParams, callback) => {
    esriLoader
        .loadModules(
            [
                'esri/Color',
                'esri/geometry/geometryEngineAsync',
                'esri/geometry/Polygon',
                'esri/Graphic',
                'esri/layers/GraphicsLayer',
                'esri/tasks/QueryTask',
                'esri/tasks/support/Query',
            ],
            { url: sdkUrl }
        )
        .then(([
            Color,
            geometryEngineAsync,
            Polygon,
            Graphic,
            GraphicsLayer,
            QueryTask,
            Query
        ]) => {
            const queryTask = new QueryTask({ url });
            const query = new Query();
            query.where = where;
            query.outFields = ['*'];
            query.returnGeometry = true;

            queryTask.execute(query)
                .then(results => {
                    if (results.features.length > 0) {
                        const geomArr = [];

                        for (let i = 0; i < results.features.length; i++) {
                            geomArr.push(results.features[i].geometry);
                        }
                        geometryEngineAsync
                            .union(geomArr)
                            .then(feature => {
                                const outlineGraLyr = new GraphicsLayer({ title: '街道区界光圈', listMode: 'hide' });
                                if (typeof callback === 'function') {
                                    callback(outlineGraLyr)
                                }

                                const params = { inputgeometry: feature.rings, ...geomParams };
                                const geom = new Polygon({ rings: params.inputgeometry, spatialReference });
                                const outlineCount = params.outlineNum === undefined ? params.lineWidth : params.outlineNum;
                                const unitWidth = Math.ceil(params.lineWidth / outlineCount);
                                const rgba = new Color(params.color ? params.color : [19, 62, 100]).toRgba();

                                for (let i = 1; i <= outlineCount; i++) {
                                    geometryEngineAsync.buffer(geom, i * unitWidth, 'meters')
                                        .then(geomOuter => {
                                            geometryEngineAsync.buffer(geom, (i - 1) * unitWidth, 'meters')
                                                .then(geomInner => {
                                                    geometryEngineAsync.difference(geomOuter, geomInner)
                                                        .then(clipGeom => {
                                                            rgba[3] = 1 - (1 / outlineCount) * (i - 1);
                                                            const outlineGra = new Graphic({
                                                                geometry: clipGeom,
                                                                symbol: {
                                                                    type: 'simple-fill',
                                                                    color: rgba,
                                                                    style: 'solid',
                                                                    outline: {
                                                                        color: 'rgba(0, 0, 0, 0)',
                                                                        width: 1
                                                                    }
                                                                }
                                                            });
                                                            outlineGraLyr.add(outlineGra);
                                                        })
                                                        .catch(e => {
                                                            console.error('generateShadowBorder geometryEngineAsync difference error:', e);
                                                        });
                                                })
                                                .catch(e => {
                                                    console.error('generateShadowBorder geometryEngineAsync buffer Inner error:', e);
                                                });
                                        })
                                        .catch(e => {
                                            console.error('generateShadowBorder geometryEngineAsync buffer Outer error:', e);
                                        });
                                }
                            })
                            .catch(e => {
                                console.error('generateShadowBorder geometryEngineAsync union error:', e);
                            });
                    }
                }).catch(e => {
                    console.error('generateShadowBorder queryTask error:', e);
                });
        });
};

const generateSpecialLayer = (FeatureLayer, labelClass, spatialReference, renderer, definitionExpression, type, title, url) => {
    return new FeatureLayer({
        url: url ? url : `http://10.89.5.191/OneMapServer/rest/services/${type}/MapServer`,
        // renderer: {
        //     type: 'simple',
        //     symbol: {
        //         type: 'simple-fill',
        //         color: '#00F2BD',
        //         style: 'solid',
        //         outline: {
        //             color: '#ffffff',
        //             width: 0
        //         }
        //     },
        // },
        renderer,
        definitionExpression,
        labelingInfo: labelClass ? [labelClass] : undefined,
        minScale: 0,
        maxScale: 0,
        spatialReference,
        title
    });
};

export default {
    generateBoundaryLayer,
    generateShadowBoundaryLayer,
    generateMaskBoundaryLayer,
    generateStreetLayer,
    generateWanggeLayer,
    generateJuweiLayer,
    generateBaimoLayer,
    generateJingmoLayer,
    //
    generateShadowBorder,
    generateSpecialLayer
};