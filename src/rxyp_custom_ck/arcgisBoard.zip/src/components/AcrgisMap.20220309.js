import React, { Component, Fragment } from 'react';
import esriLoader from 'esri-loader';
import axios from 'axios';
import _ from 'lodash';
// import { mat3, vec2, vec3 } from 'gl-matrix';

import LayerFactory from './LayerFactory';
import jiangsuStreet from './street/jiangsu';
import xinhuaStreet from './street/xinhua';
import huayangStreet from './street/huayang';
import zhouqiaoStreet from './street/zhouqiao';
import tianshanStreet from './street/tianshan';
import xianxiaStreet from './street/xianxia';
import hongqiaoStreet from './street/hongqiao';
import chengjiaqiaoStreet from './street/chengjiaqiao';
import beixinjingStreet from './street/beixinjing';
import xinjingzhenStreet from './street/xinjingzhen';
import defaultIcon from '../images/vecPinWhite.png';
import juWeiIcon from '../images/xjz_juwei.png';

import './custom.css';
import './newPopUp/index.css';
import popDefault from './newPopUp/default';
import popImage from './newPopUp/popImage';
import wjPopUp from './newPopUp/wjPopUp';

import MarkedInfo from '../data/MarkedInfo';

const DEVELOPING = process.env.NODE_ENV === 'production';
const VERSION = 'new';
const REGION_CONFIG = {
    '卫监': { max_zoom: 6.1687, zoom_space: 0.3, center: [-5984.812475795292, -2294.207155595077], definitionExpression: undefined },
    '卫监25:10': { max_zoom: 6.1687, zoom_space: 0.3, center: [-6890.107747474149, -2301.7616504062294], definitionExpression: undefined },
    // 1920*1080(1.4685)
    '精神卫生': { max_zoom: 6.3687 - 1, zoom_space: 2, center: [-8298.346910308344, -1903.1878301480851], definitionExpression: undefined },
    // '联通商圈': { max_zoom: 6, viewType: '2d', zoom_space: 2, center: [-7955.226115764595, -2607.4065436997591], definitionExpression: undefined },
    '联通商圈': { max_zoom: 6, viewType: '2d', zoom_space: 2, center: [-0.07225997013417587, -0.025818144504317717], definitionExpression: undefined },
    '联通商圈16:9': { max_zoom: 6.6, zoom_space: 2, center: [-8170.737085180836, -2583.451394551383], definitionExpression: undefined },
    '联通商圈21:9': { max_zoom: 5.6, zoom_space: 2, center: [-8170.737085180838, -2583.4426680162546], definitionExpression: undefined },
    '民政局': { max_zoom: 5.2, zoom_space: 2, center: [-7908.845518473394, -2289.4395147892574], definitionExpression: undefined },
    // '民政16:9': { max_zoom: 4, viewType: '2d', zoom_space: 2, center: [-8006.069113520387, -2147.157005473706], definitionExpression: undefined },
    '民政16:9': { max_zoom: 4, viewType: '2d', zoom_space: 2, center: [-0.07225997013417587, -0.025818144504317717], definitionExpression: undefined },
    '长宁': { max_zoom: 6.3687, zoom_space: 2, center: [-7955.226115764595, -2607.4065436997591], definitionExpression: undefined },
    '长宁-疫苗接种': { max_zoom: 6.3687, zoom_space: 2, center: [-7955.226115764595, -2607.4065436997591], definitionExpression: undefined },
    '长宁16:9': { max_zoom: 6.0, zoom_space: 2, center: [-10299.544792675988, -2300.3576741948245], definitionExpression: undefined },
    '长宁21:9': { max_zoom: 6.0, zoom_space: 2, center: [-8471.635422320514, -2300.3576741948245], definitionExpression: undefined },
    '华政步道': { max_zoom: 9.8, zoom_space: 2, center: [-5350.127682375419, -850.2280061023675], definitionExpression: undefined },
    // 3d效果
    // '华政步道': { max_zoom: 11.555432160443884, zoom_space: 2, center: [-5208.5730394243155, -853.884728447629], definitionExpression: undefined, camera: { heading: 1.9695424207592287, tilt: 59.38732894400099 } },
    '长宁城运16:9': { max_zoom: 5.9, zoom_space: 2, center: [-11199.215224944955, -2323.1053837593754], definitionExpression: undefined },
    '新华路街道': { max_zoom: 8, zoom_space: 2, center: [-3911.2464883011444, -3028.457641384611], definitionExpression: `bm_code in (${xinhuaStreet.join(',')})` },
    '新华路街道-16:9': { max_zoom: 7.9, zoom_space: 2, center: [-4861.854539422685, -3170.7196483495923], definitionExpression: `bm_code in (${xinhuaStreet.join(',')})` },
    '新华路街道-21:9': { max_zoom: 7.7, zoom_space: 2, center: [-4365.110566389961, -3191.366307519167], definitionExpression: `bm_code in (${xinhuaStreet.join(',')})` },
    '江苏路街道': { max_zoom: 8, zoom_space: 2, center: [-3729.3455714651286, -1664.4720787425783], definitionExpression: `bm_code in (${jiangsuStreet.join(',')})` },
    '江苏路街道-16:9': { max_zoom: 8, zoom_space: 2, center: [-4491.502694535417, -1647.4817232781647], definitionExpression: `bm_code in (${jiangsuStreet.join(',')})` },
    '江苏路街道-21:9': { max_zoom: 8, zoom_space: 2, center: [-4025.81542683057, -1651.7069206639762], definitionExpression: `bm_code in (${jiangsuStreet.join(',')})` },
    '华阳路街道': { max_zoom: 8, zoom_space: 2, center: [-4410.534136520728, -1628.8769388048968], definitionExpression: `bm_code in (${huayangStreet.join(',')})` },
    '华阳路街道-16:9': { max_zoom: 7.8, zoom_space: 2, center: [-5477.022791568356, -1658.1325775588632], definitionExpression: `bm_code in (${huayangStreet.join(',')})` },
    '华阳路街道-21:9': { max_zoom: 7.6, zoom_space: 2, center: [-4898.87331804815, -1658.1151244878233], definitionExpression: `bm_code in (${huayangStreet.join(',')})` },
    '周家桥街道': { max_zoom: 8, zoom_space: 2, center: [-7017.199485924686, -1760.5176979232183], definitionExpression: `bm_code in (${zhouqiaoStreet.join(',')})` },
    '周家桥街道-21:9': { max_zoom: 7.7, zoom_space: 2, center: [-6940.822733901554, -1688.2856509671744], definitionExpression: `bm_code in (${zhouqiaoStreet.join(',')})` },
    '天山路街道': { max_zoom: 8, zoom_space: 2, center: [-6279.66060159152, -2660.809539564506], definitionExpression: `bm_code in (${tianshanStreet.join(',')})` },
    '天山路街道-16:9': { max_zoom: 8, zoom_space: 2, center: [-6781.919126330123, -2780.7855813879423], definitionExpression: `bm_code in (${tianshanStreet.join(',')})` },
    '天山路街道-21:9': { max_zoom: 8, zoom_space: 2, center: [-6285.920252449489, -2704.36239039734], definitionExpression: `bm_code in (${tianshanStreet.join(',')})` },
    '仙霞新村街道': { max_zoom: 8, zoom_space: 2, center: [-7703.705844577159, -2783.916420920775], definitionExpression: `bm_code in (${xianxiaStreet.join(',')})` },
    '仙霞新村街道-16:9': { max_zoom: 8, zoom_space: 2, center: [-8309.549147411777, -3002.5560916619006], definitionExpression: `bm_code in (${xianxiaStreet.join(',')})` },
    '仙霞新村街道-21:9': { max_zoom: 7.9, zoom_space: 2, center: [-7670.41042472942, -2955.9964203400805], definitionExpression: `bm_code in (${xianxiaStreet.join(',')})` },
    '虹桥街道': { max_zoom: 7.5, zoom_space: 2, center: [-6766.723836653108, -3852.527653110857], definitionExpression: `bm_code in (${hongqiaoStreet.join(',')})` },
    '虹桥街道-16:9': { max_zoom: 7.5, zoom_space: 2, center: [-7296.016585647948, -3842.00647820177], definitionExpression: `bm_code in (${hongqiaoStreet.join(',')})` },
    '虹桥街道-21:9': { max_zoom: 7.5, zoom_space: 2, center: [-6799.323394367828, -3913.806503761317], definitionExpression: `bm_code in (${hongqiaoStreet.join(',')})` },
    '程家桥街道': { max_zoom: 7.2, zoom_space: 2, center: [-10923.915204160785, -4201.237610836268], definitionExpression: `bm_code in (${chengjiaqiaoStreet.join(',')})` },
    '程家桥街道-16:9': { max_zoom: 7, zoom_space: 2, center: [-11833.534677892689, -4203.352834931387], definitionExpression: `bm_code in (${chengjiaqiaoStreet.join(',')})` },
    '程家桥街道-21:9': { max_zoom: 7, zoom_space: 2, center: [-10784.062849179676, -4228.721069260143], definitionExpression: `bm_code in (${chengjiaqiaoStreet.join(',')})` },
    '北新泾街道': { max_zoom: 8, zoom_space: 2, center: [-9749.466318422914, -1416.401999739913], definitionExpression: `bm_code in (${beixinjingStreet.join(',')})` },
    '北新泾街道-16:9': { max_zoom: 8, zoom_space: 2, center: [-10296.167480790105, -1519.3708414979737], definitionExpression: `bm_code in (${beixinjingStreet.join(',')})` },
    '北新泾街道-21:9': { max_zoom: 8, zoom_space: 2, center: [-9877.100734985415, -1443.18935583241], definitionExpression: `bm_code in (${beixinjingStreet.join(',')})` },
    '新泾镇': { max_zoom: 6.7, zoom_space: 2, center: [-10217.15300508177, -2716.6543797962395], definitionExpression: `bm_code in (${xinjingzhenStreet.join(',')})` },
    '新泾镇-16:9': { max_zoom: 6.94, zoom_space: 2, center: [-11101.656712298112, -2849.9152626370724], definitionExpression: `bm_code in (${xinjingzhenStreet.join(',')})` },
    '新泾镇-21:9': { max_zoom: 6.94, zoom_space: 2, center: [-10501.573069585638, -2849.9152626370724], definitionExpression: `bm_code in (${xinjingzhenStreet.join(',')})` },
    // '新泾镇-垃圾管理16:9': { max_zoom: 7, zoom_space: 2, viewType: '2d', center: [-11398.866456587017, -2791.5126316115475], definitionExpression: `bm_code in (${xinjingzhenStreet.join(',')})` },
    '新泾镇-垃圾管理16:9': { max_zoom: 7, zoom_space: 2, viewType: '2d', center: [-0.07225997013417587, -0.025818144504317717], definitionExpression: `bm_code in (${xinjingzhenStreet.join(',')})` },
    '虹桥临空经济园区': { max_zoom: 6.74, zoom_space: 2, center: [-11521.012709161942, -1331.7631203871779], definitionExpression: undefined },
    '虹桥临空经济园区-16:9': { max_zoom: 6.74, zoom_space: 2, center: [-12759.824186894026, -1364.8003282957027], definitionExpression: undefined },
    '虹桥临空经济园区-21:9': { max_zoom: 6.74, zoom_space: 2, center: [-11614.536742999031, -1364.8003282957027], definitionExpression: undefined },
    '新泾镇-河湖管理': { max_zoom: 6.3687, zoom_space: 2, center: [-10661.768625537758, -1757.9083537485476], definitionExpression: undefined },
    '新泾镇-河湖管理2d': { max_zoom: 7, viewType: '2d', zoom_space: 2, center: [-10287.614234082603, -2916.396214712047], definitionExpression: undefined },
    // '新泾镇-河湖管理2d': { max_zoom: 7, viewType: '2d', zoom_space: 2, center: [-0.09241521103601946, -0.026198432029337443], definitionExpression: undefined },
    '健康管控': { max_zoom: 6.1687, zoom_space: 2, center: [-8103.746570022386, -2297.6219857251635], definitionExpression: undefined },
    '健康管控16:9': { max_zoom: 6.1687, zoom_space: 2, center: [-10086.784317153768, -2165.546071042901], definitionExpression: undefined },
    '人民武装部16:9': { max_zoom: 4.56, zoom_space: 2, center: [-7906.66744511881, -2591.9794259631126], definitionExpression: undefined },
    '交互枢纽': { max_zoom: 6, viewType: '2d', zoom_space: 2, center: [0.027185227900393637, -0.013610914439672469], definitionExpression: undefined },
    '虹桥街道-一码通行': { max_zoom: 7.2, zoom_space: 2, center: [-6652.401896767744, -3981.664177637679], definitionExpression: undefined },

    // 25:10
    '长宁25:10': { max_zoom: 6.46, zoom_space: 2, center: [-8181.676046960232, -2400.62117792485], definitionExpression: undefined },
    '新华路街道-25:10': { max_zoom: 8.0, zoom_space: 2, center: [-4224.951747191434, -3096.0837758225653], definitionExpression: `bm_code in (${xinhuaStreet.join(',')})` },
    '江苏路街道-25:10': { max_zoom: 8.41, zoom_space: 2, center: [-4058.655586456266, -1555.202194234414], definitionExpression: `bm_code in (${jiangsuStreet.join(',')})` },
    '华阳路街道-25:10': { max_zoom: 7.77, zoom_space: 2, center: [-4956.97302688629, -1475.786315481828], definitionExpression: `bm_code in (${huayangStreet.join(',')})` },
    '周家桥街道-25:10': { max_zoom: 8.15, zoom_space: 2, center: [-6858.4742560207815, -1727.2557371067433], definitionExpression: `bm_code in (${zhouqiaoStreet.join(',')})` },
    '天山路街道-25:10': { max_zoom: 8.2, zoom_space: 2, center: [-6247.648146041439, -2633.5861983742416], definitionExpression: `bm_code in (${tianshanStreet.join(',')})` },
    '仙霞新村街道-25:10': { max_zoom: 8.1, zoom_space: 2, center: [-7716.496578921079, -2876.7858719672877], definitionExpression: `bm_code in (${xianxiaStreet.join(',')})` },
    '虹桥街道-25:10': { max_zoom: 7.78, zoom_space: 2, center: [-6702.89129297038, -3787.589330952619], definitionExpression: `bm_code in (${hongqiaoStreet.join(',')})` },
    '程家桥街道-25:10': { max_zoom: 7.19, zoom_space: 2, center: [-10971.815590690385, -4008.138105401505], definitionExpression: `bm_code in (${chengjiaqiaoStreet.join(',')})` },
    '北新泾街道-25:10': { max_zoom: 8.42, zoom_space: 2, center: [-9970.267648917961, -1339.512723482258], definitionExpression: `bm_code in (${beixinjingStreet.join(',')})` },
    '新泾镇-25:10': { max_zoom: 7.12, zoom_space: 2, center: [-10006.491401302363, -2596.2261689052275], definitionExpression: `bm_code in (${xinjingzhenStreet.join(',')})` },
    '联通商圈25:10': { max_zoom: 5.84, zoom_space: 2, center: [-8291.523538757237, -2419.475555375527], definitionExpression: undefined },

};
let ROAD_CENTER = {
    '新华路街道': { center: [-3379.1545703995307, -3118.771479718119], zoom: 6.1687 + 1.5 },
    '江苏路街道': { center: [-3729.3455714651286, -1664.4720787425783], zoom: 6.1687 + 1.5 },
    '华阳路街道': { center: [-3839.160267635518, -1662.7358845756294], zoom: 6.1687 + 1.5 },
    '周家桥街道': { center: [-6343.880012965901, -1715.1904596231682], zoom: 6.1687 + 1.5 },
    // '天山路街道': { center: [-5753.775087857433, -2606.6545304982983], zoom: 6.1687 + 1.5 },
    '天山路街道': { center: [-6279.66060159152, -2660.809539564506], zoom: 8 },
    '仙霞新村街道': { center: [-7183.090464926783, -2724.673356813347], zoom: 6.1687 + 1.5 },
    '虹桥街道': { center: [-6239.358239386647, -4009.3441067792896], zoom: 6.1687 + 1.5 },
    '程家桥街道': { center: [-10290.922835500976, -4061.7798189898117], zoom: 6.1687 + 1.5 },
    '北新泾街道': { center: [-9478.627826303737, -1467.1741391144164], zoom: 6.1687 + 1.5 },
    '新泾镇': { center: [-9806.61756012832, -1060.9489468143356], zoom: 6.1687 + 1.5 },
    '周家浜': { center: [-10271.338045749568, -2389.7524523710467], zoom: 9.31, changeOnly: true },
    '河湖管理': { center: [-10661.768625537758, -1757.9083537485476], zoom: 6.3687, changeOnly: true },
    '天山道钉': { center: [-6084.320726352595, -3185.922599794744], zoom: 11.63, changeOnly: true },

    // '新华路街道_shzz': { center: [-4220.790897440429, -3085.2552046203646], zoom: 6.5 },
    // '江苏路街道_shzz': { center: [-3887.9029386465645, -1575.122050469437], zoom: 6.8 },
    // '华阳路街道_shzz': { center: [-4741.8189868878335, -1472.7590843930388], zoom: 6.39 },
    // '周家桥街道_shzz': { center: [-6667.025652939691, -1787.6777711475204], zoom: 6.2 },
    // '天山路街道_shzz': { center: [-6162.013201407164, -2644.8192411043055], zoom: 6.63 },
    // '仙霞新村街道_shzz': { center: [-7700.445145955027, -2861.6827307005965], zoom: 6.67 },
    // '虹桥街道_shzz': { center: [-6495.259285671022, -3848.495632015579], zoom: 5.89 },
    // '程家桥街道_shzz': { center: [-10522.121424411538, -4079.7357949373477], zoom: 5.64 },
    // '北新泾街道_shzz': { center: [-9600.789334992256, -1414.2885308165673], zoom: 6.75 },
    // '新泾镇_shzz': { center: [-9750.700743712601, -2862.706994604191], zoom: 5.9 },

    // '新华路街道_shzz_pc': { center: [-4370.736789571156, -3190.670939976196], zoom: 8 },
    // '江苏路街道_shzz_pc': { center: [-3980.49391221955, -1677.1321116254326], zoom: 8.5 },
    // '华阳路街道_shzz_pc': { center: [-4815.280027596852, -1639.1355713391572], zoom: 8 },
    // '周家桥街道_shzz_pc': { center: [-6666.842340457952, -1787.8093401393744], zoom: 8.3 },
    // '天山路街道_shzz_pc': { center: [-6143.174179181473, -2807.1384579910355], zoom: 8.3 },
    // '仙霞新村街道_shzz_pc': { center: [-7708.437345636381, -2976.313364763697], zoom: 8.2 },
    // '虹桥街道_shzz_pc': { center: [-6566.659656445148, -3846.4979704747093], zoom: 8.0 },
    // '程家桥街道_shzz_pc': { center: [-10771.881274423587, -4077.404068889822], zoom: 6.1687 + 1.5 },
    // '北新泾街道_shzz_pc': { center: [-9660.1310401674, -1405.7959952017002], zoom: 8.3 },
    // '新泾镇_shzz_pc': { center: [-9916.153237905766, -2455.7221796730855], zoom: 6.1687 + 1.2 },\

    '新华路街道_shzz': { center: [-4317.656057290735, -3008.497252477893], zoom: 7.6 },
    '江苏路街道_shzz': { center: [-3963.1843098164786, -1492.0944862484184], zoom: 8 },
    '华阳路街道_shzz': { center: [-4756.135636120943, -1452.5941587744899], zoom: 7.5 },
    '周家桥街道_shzz': { center: [-6652.463076252072, -1771.3960955714263], zoom: 7.76 },
    '天山路街道_shzz': { center: [-6119.903576083331, -2633.4192205532], zoom: 7.77 },
    '仙霞新村街道_shzz': { center: [-7649.57479076719, -2789.753596089446], zoom: 7.8 },
    '虹桥街道_shzz': { center: [-6607.283970540486, -3805.2902860886707], zoom: 7.49 },
    '程家桥街道_shzz': { center: [-10595.15377618692, -3886.3564988794774], zoom: 6.78 },
    '北新泾街道_shzz': { center: [-9807.506517530019, -1340.4783998382081], zoom: 8.14 },
    '新泾镇_shzz': { center: [-10273.844645894893, -2458.511370035228], zoom: 6.46 },

    '新华路街道_shzz_pc': { center: [-4220.790897440429, -3085.2552046203646], zoom: 6.5 },
    '江苏路街道_shzz_pc': { center: [-3887.9029386465645, -1575.122050469437], zoom: 6.8 },
    '华阳路街道_shzz_pc': { center: [-4748.143199550883, -1469.0559504481807], zoom: 6.22 },
    '周家桥街道_shzz_pc': { center: [-6667.025652939691, -1787.6777711475204], zoom: 5.89 },
    '天山路街道_shzz_pc': { center: [-6162.013201407164, -2644.8192411043055], zoom: 6.28 },
    '仙霞新村街道_shzz_pc': { center: [-7700.445145955027, -2861.6827307005965], zoom: 6.42 },
    '虹桥街道_shzz_pc': { center: [-6578.853049438034, -3821.885416030107], zoom: 5.55 },
    '程家桥街道_shzz_pc': { center: [-10621.585731407093, -4075.81711693268], zoom: 5.11 },
    '北新泾街道_shzz_pc': { center: [-9618.27479897334, -1414.2885308165673], zoom: 6.53 },
    '新泾镇_shzz_pc': { center: [-9972.34225463753, -2616.3639096476318], zoom: 5.36 },

    '新华路街道_交互枢纽': { center: [-0.012320514595719445, -0.024268326511244713], zoom: 8 },
    '江苏路街道_交互枢纽': { center: [-0.01028938474329036, -0.011500922129951184], zoom: 8 },
    '华阳路街道_交互枢纽': { center: [-0.018228709410568988, -0.012556266768722943], zoom: 8 },
    '周家桥街道_交互枢纽': { center: [-0.0323493820591321, -0.013018322903001544], zoom: 8 },
    '天山路街道_交互枢纽': { center: [-0.030955089133012467, -0.020628035161071208], zoom: 8 },
    '仙霞新村街道_交互枢纽': { center: [-0.043759368790522765, -0.023651917790293873], zoom: 8 },
    '虹桥街道_交互枢纽': { center: [-0.033278648145656155, -0.03248803026799177], zoom: 8 },
    '程家桥街道_交互枢纽': { center: [-0.04595421416007631, -0.03307956770505205], zoom: 7 },
    '北新泾街道_交互枢纽': { center: [-0.061953788713251814, -0.00998782725073246], zoom: 8 },
    '新泾镇_交互枢纽': { center: [-0.0380548509439063, -0.019810331187073253], zoom: 7 },
    '虹桥临空经济园区_交互枢纽': { center: [-0.05090222062041752, -0.013333542067453658], zoom: 7 },
}
const FIXED_LAYER_PINTYPE = ['cnBorder', 'cnCountry', 'cnWangge', 'cnJuwei', 'buildingFFF', 'buildingReal', 'cameraMaptile', 'ST', 'hzbd', 'hzbd_3d', 'tsdd'];

function printEvent(handler, event) {
    try {
        console.info(handler + ': ' + JSON.stringify(event, null, 4) + '\n\n');
    } catch (e) {
        console.error('printEvent error：', e);
    }
}

const CONST_CODE = {
    '1': {
        label: '坐席事件', status: {
            0: '座席初始化状态',
            1: '签入',
            2: '置忙',
            3: '置闲',
            4: '锁定',
            5: '工作，包含振铃、通话等话路事件',
            6: '事后整理',
            7: '其他工作'
        }
    },
    '2': {
        label: '话路事件', status: {
            20: '设备初始化状态',
            21: '空闲',
            22: '摘机',
            23: '振铃',
            24: '被咨询振铃',
            25: '外拨振铃',
            26: '咨询摘机',
            27: '咨询振铃',
            28: '双方通话',
            29: '保持',
            30: '被保持',
            31: '咨询通话',
            32: '被咨询通话',
            33: '会议',
            34: '被会议',
            35: '监听',
            36: '强插',
        }
    },
    '3': {
        label: '系统事件', status: {
            50: '连接上线',
            51: '连接断开',
            52: 'CTILINK 连接',
            53: 'CTILINK 断开'
        }
    }
}

export default class Indee extends Component {
    constructor(props) {
        super(props);
        this.state = {
            mapReady: false
        };
        this.url = 'http://bigdata.cn.gov:9070/arcgis_js_v416_api/arcgis_js_api/library/4.16/dojo/dojo.js';
        // this.url = 'http://bigdata.cn.gov:9070/arcgis_js_v410_sdk/arcgis_js_api/library/4.10/dojo/dojo.js';
        this.spatialReferencevalue = { wkid: 102100 };
        this.featureLayers = {};
        this.newFatureLayers = {}
        this.newTmpData = {};
        this.statusRef = React.createRef();

        window.dojoConfig = {
            packages: [{
                name: 'app',
                location: 'http://bigdata.cn.gov:9070/libs/app'
            }, {
                name: 'three-projector',
                location: 'http://bigdata.cn.gov:9070/libs/threejs-projector',
                main: 'three'
            }, {
                name: 'axios',
                location: 'http://bigdata.cn.gov:9070/libs/axios',
                main: 'axios'
            }, {
                name: 'flv',
                location: 'http://bigdata.cn.gov:9070/libs/flv',
                main: 'flv'
            }, {
                name: 'VideoStream',
                location: 'http://bigdata.cn.gov:9070/libs/VideoStream',
                main: 'VideoStream'
            }]
        };
    }

    /**
     * datas: 图层数据：{[pinType]:{}}
     * layersData: 路况数据
     */
    shouldComponentUpdate(nextProps, nextState) {
        try {
            if (nextProps.mapCenter !== this.props.mapCenter) {
                if (nextState.mapReady && nextProps.mapCenter) {
                    console.log('map shouldComponentUpdate change center', nextProps.mapCenter);
                    this.view.popup.visible = false;
                    this.changeCenter(nextProps.mapCenter, nextProps.region);
                }
            } else if (!_.isEqual(nextState.mapReady, this.state.mapReady) && nextProps.mapCenter) {
                setTimeout(() => {
                    console.log('map shouldComponentUpdate change center', nextProps.mapCenter);
                    this.view.popup.visible = false;
                    this.changeCenter(nextProps.mapCenter, nextProps.region);
                }, 500);
            }
            if (nextProps.makeCall !== this.props.makeCall) {
                const { phone } = nextProps.makeCall || {}
                this.makeCall(null, phone);
            }
            if (!_.isEqual(nextProps.popUp, this.props.popUp)) {
                const { pinType, id } = nextProps.popUp || {};

                if (this.featureLayers[pinType]) {
                    const query = this.featureLayers[pinType].createQuery();
                    query.outFields = ['*'];
                    query.returnGeometry = true;

                    this.featureLayers[pinType].queryFeatures(query).then(res => {
                        const { features = [] } = res;

                        features.forEach(item => {
                            const { attributes = {}, geometry } = item || {};

                            if (attributes.sbbh === id) {
                                this.arcgisPopup(attributes, geometry, this.view);
                            }
                        })
                    });
                }
            }
            if (!_.isEqual(nextState.mapReady, this.state.mapReady) ||
                !_.isEqual(nextProps.datas, this.props.datas) ||
                !_.isEqual(nextProps.layersData, this.props.layersData)
            ) {
                if (nextState.mapReady) {
                    const { datas: oldDt = {}, region } = this.props;
                    const { datas = {}, layersData = {} } = nextProps;
                    console.log('map shouldComponentUpdate data:', nextProps.datas, this.featureLayers);

                    this.view.popup.visible = false;
                    Object.keys(datas).forEach(pinType => {
                        const layerData = datas[pinType];
                        const { state = false } = layerData || {};
                        console.log('map shouldComponentUpdate layer', pinType, this.featureLayers[pinType]);

                        if (this.featureLayers[pinType]) {
                            if (state) {
                                if (FIXED_LAYER_PINTYPE.includes(pinType) || pinType.indexOf('gx2d') !== -1 || pinType.indexOf('gx3d') !== -1) {
                                    if (Array.isArray(this.featureLayers[pinType])) {
                                        this.featureLayers[pinType].forEach(layer => {
                                            layer.visible = true;
                                        });
                                    } else {
                                        this.featureLayers[pinType].visible = true;
                                    }
                                } else {
                                    if (!_.isEqual(datas[pinType], oldDt[pinType])) {
                                        console.log('map shouldComponentUpdate fresh layer', pinType);
                                        this.generateGraphLayer(datas[pinType], this.featureLayers[pinType]);
                                    }
                                }
                            } else {
                                if (Array.isArray(this.featureLayers[pinType])) {
                                    this.featureLayers[pinType].forEach(layer => {
                                        layer.visible = false;
                                    });
                                } else {
                                    this.featureLayers[pinType].visible = false;
                                }
                            }
                        } else {
                            if (state) {
                                if ((region === '新泾镇-河湖管理' || region === '新泾镇-河湖管理2d') && pinType === 'cnJuwei') {
                                    const graphicLayer = new this.ArcGisGraphicsLayer({ title: '长宁区村居委label', outFields: ['*'] });
                                    if (this.props.region && this.props.region.indexOf('2d') === -1) {
                                        this.map.add(graphicLayer);
                                    }

                                    const queryTask = new this.ArcGisQueryTask({ url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_juwei/FeatureServer/0' });
                                    const query = new this.ArcGisQuery();
                                    query.outFields = ['*'];
                                    query.returnGeometry = true;
                                    query.where = `所属街道='新泾镇'`;

                                    queryTask.execute(query)
                                        .then(results => {
                                            const { features = [] } = results || {};
                                            features.forEach(feature => {
                                                if (feature) {
                                                    const { attributes } = feature;
                                                    const x = attributes['x中心点坐'], y = attributes['y中心点坐'];

                                                    const graphic = new this.ArcGisGraphic({
                                                        attributes,
                                                        geometry: {
                                                            type: 'point',
                                                            x,
                                                            y: parseFloat(y) + 200,
                                                            z: 200,
                                                            spatialReference: this.spatialReferencevalue,
                                                        },
                                                        symbol: {
                                                            type: 'text',
                                                            text: `${attributes.居委会名称 ? attributes.居委会名称.replace('居委', '') : ''}`,
                                                            color: '#fff',
                                                            font: {
                                                                size: 24,
                                                            },
                                                            verticalAlignment: 'top'
                                                        }
                                                    });

                                                    graphicLayer.add(graphic);
                                                }
                                            });
                                        }).catch(e => {
                                            console.error('Hosted_juwei queryTask error:', e);
                                        });

                                    const layer = new this.ArcGisFeatureLayer({
                                        url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_juwei/FeatureServer',
                                        renderer:
                                            this.props.region && this.props.region.indexOf('2d') === -1 ?
                                                {
                                                    type: 'simple',
                                                    symbol: {
                                                        type: 'picture-marker',
                                                        url: juWeiIcon,
                                                        width: '64px',
                                                        height: '86px',
                                                    },
                                                } : {
                                                    type: 'simple',
                                                    symbol: {
                                                        type: 'simple-fill',
                                                        color: [242, 205, 189, 0],
                                                        style: 'solid',
                                                        outline: {
                                                            color: '#ffab00',
                                                            width: 1
                                                        }
                                                    },
                                                },
                                        // minScale: 0,
                                        // maxScale: 0,
                                        spatialReference: this.spatialReferencevalue,
                                        title: '长宁区村居委',
                                        definitionExpression: `所属街道='新泾镇'`
                                    });

                                    this.map.add(layer);
                                    this.featureLayers[pinType] = [layer, graphicLayer];
                                } else if (pinType === 'tsdd') {
                                    const polygon = new this.ArcGisPolygon({
                                        rings: [
                                            // [-6253.526888488419, -3141.416340079264],
                                            // [-6232.510614294906, -3148.161684868769],
                                            // [-6197.388021410423, -3156.3267062046643],
                                            // [-6165.853646419391, -3163.685516923814],
                                            // [-6136.163030971781, -3171.8408847180945],
                                            [-6106.558681159023, -3183.965672952649],
                                            [-6083.567148931611, -3195.4633662574106],
                                            [-6050.3021006673325, -3217.0985809862736],
                                            [-6030.5090048279735, -3231.4842558175164],
                                            [-6003.4245933948305, -3251.375561693255],
                                            [-5988.420027845166, -3259.5245450430652],
                                            [-5977.405747806521, -3251.0676858934016],
                                            [-5999.232901301504, -3239.4425739089043],
                                            [-6025.450692319195, -3221.927594871572],
                                            [-6058.230373787934, -3199.2441686877078],
                                            [-6095.255725547048, -3179.2109459075396],
                                            [-6102.779310287539, -3176.446882324984],
                                            // [-6135.67062237811, -3162.468990089371],
                                            // [-6251.527306631114, -3132.332517057364]
                                        ],
                                        spatialReference: this.spatialReferencevalue,
                                    });
                                    const graphic = new this.ArcGisGraphic({
                                        geometry: polygon,
                                        symbol: {
                                            type: 'simple-fill',
                                            color: [0, 0, 0, 0],
                                            style: 'solid',
                                            outline: {
                                                color: [200, 255, 200, 1],
                                                width: 2
                                            }
                                        }
                                    });
                                    const layer = new this.ArcGisGraphicsLayer({});
                                    layer.add(graphic);

                                    this.map.add(layer);
                                    this.featureLayers[pinType] = layer;
                                } else if (FIXED_LAYER_PINTYPE.includes(pinType) || pinType.indexOf('gx2d') !== -1 || pinType.indexOf('gx3d') !== -1) {
                                    this.generateFixedLayer(pinType);
                                } else {
                                    this.generateGraphLayer(datas[pinType]);
                                }
                            }
                        }
                    });
                    this.generateRoedLayer(layersData);
                }
            }

            return !_.isEqual(nextState, this.state) || !_.isEqual(nextProps, this.props);
        } catch (e) {
            console.error('map shouldComponentUpdate error:', e);
        }
    }

    // 创建固定图层
    generateFixedLayer(pinType) {
        // if (!this.state.mapReady) { return; }
        let { region, zrwg } = this.props;
        let index = undefined, layer = null, center = undefined, camera = undefined, zoom = undefined;
        const array = region.split('-');
        region = array[0];

        // 长宁区界
        if (pinType === 'cnBorder') {
            layer = LayerFactory.generateShadowBoundaryLayer(this.ArcGisFeatureLayer, VERSION, this.spatialReferencevalue);
        }
        // 街道
        else if (pinType === 'cnCountry') {
            if (region.indexOf('长宁') !== -1 || region.indexOf('联通商圈') !== -1 || region === '民政局') {
                if (this.props.region === '长宁-疫苗接种') {
                    layer = LayerFactory.generateStreetLayer(this.ArcGisFeatureLayer, VERSION, this.spatialReferencevalue, null, null, [64, 189, 255, 1], {
                        title: '',
                        outFields: ['*'],
                        content: function (feature) {
                            if (zrwg && feature && feature.graphic && feature.graphic.attributes) {
                                feature.graphic.layer.renderer = {
                                    type: 'unique-value',
                                    field: 'name',
                                    defaultSymbol: {
                                        type: 'simple-fill',
                                        color: [0, 0, 0, 0],
                                        style: 'solid',
                                        outline: {
                                            color: [64, 189, 255, 1],
                                            width: 1
                                        }
                                    },
                                    uniqueValueInfos: [
                                        {
                                            value: feature.graphic.attributes.name,
                                            symbol: {
                                                type: 'simple-fill',
                                                color: [64, 189, 255, 0.4],
                                                style: 'solid',
                                                outline: {
                                                    color: [64, 189, 255, 1],
                                                    width: 0
                                                }
                                            }
                                        }
                                    ]
                                }

                                const code = feature.graphic.attributes.name;
                                const data = zrwg.filter(item => item.A === (code === '虹桥临空经济园区' ? '临空' : code))[0];

                                if (data) {
                                    return `
                                    <div class='popup_dom_wrapper' style='border-radius: 0'>
                                        <div class='popup_dom_title'>${data.A}</div>
                                        <div style='padding: 0 32px'>
                                            <table class='popup_dom_content'>
                                                <tbody>
                                                    <tr>
                                                        <td style='min-width: 260px; color: #00c2ff'>加强针完成率</td>
                                                        <td>${data.D + '%' || 0}</td>
                                                    </tr>
                                                    <tr>
                                                        <td style='min-width: 260px; color: #00c2ff; padding-right: 40px'>老年人全程接种率</td>
                                                        <td>${data.E + '%' || 0}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    `;
                                }
                            }
                        }
                    }, region);
                } else {
                    layer = LayerFactory.generateStreetLayer(this.ArcGisFeatureLayer, VERSION, this.spatialReferencevalue, null, null, null, null, region);
                }
            }
            // else if (region === '虹桥临空经济园区') {
            //     // const queryTask = new this.ArcGisQueryTask({ url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_street_11/FeatureServer/0' });
            //     // const query = new this.ArcGisQuery();
            //     // query.outFields = ['*'];
            //     // query.returnGeometry = true;

            //     // queryTask.execute(query)
            //     //     .then(results => {
            //     //         console.info('虹桥临空经济园区', results);
            //     //     });
            //     layer = new this.ArcGisFeatureLayer({
            //         url: 'http://10.89.5.191/OneMapServer/rest/services/street_11_linkong/FeatureServer/0',
            //         spatialReference: this.spatialReferencevalue,
            //         title: '长宁区街道'
            //     });
            // } 
            else {
                layer = LayerFactory.generateStreetLayer(this.ArcGisFeatureLayer, VERSION, this.spatialReferencevalue, {
                    type: 'unique-value',
                    field: 'NAME',
                    defaultSymbol: {
                        type: 'simple-fill',
                        color: this.props.region && this.props.region.indexOf('2d') !== -1 ? [0, 0, 0, 0] : [0, 0, 0, 0.6],
                        style: 'solid',
                        outline: {
                            width: 0
                        }
                    },
                    uniqueValueInfos: [
                        {
                            value: `${region}`,
                            symbol: {
                                type: 'simple-fill',
                                color: [0, 0, 0, 0],
                                style: 'solid',
                                outline: {
                                    color: [64, 189, 255, 1],
                                    width: 2
                                }
                            }
                        }
                    ]
                }, null, null, null, region);
            }
        }
        // 责任网格 
        else if (pinType === 'cnWangge') {
            if (region.indexOf('长宁') !== -1 || region === '联通商圈' || region === '民政局') {
                layer = LayerFactory.generateWanggeLayer(this.ArcGisFeatureLayer, this.ArcGisLabelClass, VERSION, this.spatialReferencevalue, null, null, zrwg);
            } else {
                layer = LayerFactory.generateWanggeLayer(this.ArcGisFeatureLayer, this.ArcGisLabelClass, VERSION, this.spatialReferencevalue, null, `所属街道='${region}'`, zrwg);
            }
        }
        // 社区居委
        else if (pinType === 'cnJuwei') {
            if (region.indexOf('长宁') !== -1 || region === '联通商圈' || region === '民政局') {
                layer = LayerFactory.generateJuweiLayer(this.ArcGisFeatureLayer, this.ArcGisLabelClass, VERSION, this.spatialReferencevalue);
            } else {
                layer = LayerFactory.generateJuweiLayer(this.ArcGisFeatureLayer, this.ArcGisLabelClass, VERSION, this.spatialReferencevalue, null, `所属街道='${region}'`);
            }
        }
        // 长宁区三维白模型
        else if (pinType === 'buildingFFF') {
            if (region.indexOf('长宁') !== -1 || region === '联通商圈' || region === '民政局') {
                layer = LayerFactory.generateBaimoLayer(this.ArcGisSceneLayer, VERSION, this.spatialReferencevalue);
            } else {
                layer = LayerFactory.generateBaimoLayer(this.ArcGisSceneLayer, VERSION, this.spatialReferencevalue, null, `ZJD_NAME='${region}'`);
            }
        }
        // 长宁精模
        else if (pinType === 'buildingReal') {
            // if (region.indexOf('长宁') !== -1 || region === '联通商圈' || region === '民政局' || region === '华政步道') {
            if (region.indexOf('街道') !== -1 || region.indexOf('新泾镇') !== -1 /*|| region.indexOf('虹桥临空经济园区') !== -1*/) {
                layer = LayerFactory.generateJingmoLayer(this.ArcGisSceneLayer, VERSION, this.spatialReferencevalue, null, `jiezhen='${region && region.indexOf('临空') !== -1 ? '新泾镇' : region}'`);
                if (region.indexOf('程家桥街道') !== -1) {
                    if (!layer) {
                        layer = [];
                    }
                    layer.push(
                        new this.ArcGisIntegratedMeshLayer({
                            url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_dwyQXMX/SceneServer',
                            id: '动物园倾斜摄影模型'
                        })
                    );
                }

            } else if (region.indexOf('虹桥临空经济园区') !== -1) {
                layer = new this.ArcGisIntegratedMeshLayer({
                    // url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_linkongQXMX/SceneServer/layers/0',
                    url: `http://10.89.5.191/OneMapServer/rest/services/Hosted_LK_nodemerge/SceneServer`,
                    id: '虹桥临空经济园区精模'
                });
            } else {
                layer = LayerFactory.generateJingmoLayer(this.ArcGisSceneLayer, VERSION, this.spatialReferencevalue);
            }
        }
        // 长宁区卫星影像
        else if (pinType === 'cameraMaptile') {
            layer = new this.ArcGisTileLayer({
                url:
                    VERSION === 'new' ?
                        'http://10.89.5.191/OneMapServer/rest/services/cn_image/MapServer' :
                        // 'http://10.89.5.191/OneMapServer/rest/services/cn_sta_image_2020/MapServer' :
                        'http://10.207.204.19/server/rest/services/AIRIMAGE2020/MapServer',
                id: '长宁区卫星影像2020年'
            });
            index = 1;
        }
        // 水体
        else if (pinType === 'ST') {
            const labelClass = new this.ArcGisLabelClass({
                labelExpressionInfo: { expression: '$feature.NAME' },
                symbol: {
                    type: 'text',
                    color: '#ffffff',
                    font: {
                        size: 24,
                    },
                    haloSize: 0,
                    haloColor: 'white'
                }
            });

            layer = LayerFactory.generateSpecialLayer(this.ArcGisFeatureLayer, this.props.region && this.props.region.indexOf('2d') === -1 ? labelClass : undefined, this.spatialReferencevalue,
                {
                    type: 'simple',
                    symbol: {
                        type: 'simple-fill',
                        color: '#00F2BD',
                        style: 'solid',
                        outline: {
                            color: '#ffffff',
                            width: 0
                        }
                    },
                },
                'ST', '水体');
        }
        // 华政步道 
        else if (pinType === 'hzbd') {
            layer = new this.ArcGisFeatureLayer({
                url: `http://10.89.5.191/OneMapServer/rest/services/Hosted_hzbd/FeatureServer`,
                renderer: {
                    type: 'simple',
                    symbol: {
                        type: 'simple-fill',
                        color: [247, 242, 200, 0],
                        style: 'solid',
                        outline: {
                            color: [64, 189, 255, 1],
                            width: 6
                        }
                    }
                },
                minScale: 0,
                maxScale: 0,
                spatialReference: this.spatialReferencevalue,
                title: '华政步道',
            });
        }
        // 华政步道3d
        else if (pinType === 'hzbd_3d') {
            layer = new this.ArcGisIntegratedMeshLayer({
                // url: `http://10.89.5.191/OneMapServer/rest/services/Hosted_hzbd3d/SceneServer`,
                url: `http://10.89.5.191/OneMapServer/rest/services/Hosted_ZFDX_NorthPart_nodemerge/SceneServer`,
                id: '华政步道3d',
            });
            index = 1;
        }
        // 管线2D
        else if (pinType.indexOf('gx2d') !== -1) {
            [
                { title: '二维管线_工业', id: 'gx2d_gy', url: 'http://10.89.5.191/OneMapServer/rest/services/PIPE_Special/MapServer/1', symbol: { color: [230, 152, 0, 255], width: 3 } },
                { title: '二维管线_燃气', id: 'gx2d_rq', url: 'http://10.89.5.191/OneMapServer/rest/services/PIPE_Gas/MapServer/1', symbol: { color: [168, 168, 0, 255], width: 3 } },
                { title: '二维管线_给水', id: 'gx2d_gs', url: 'http://10.89.5.191/OneMapServer/rest/services/PIPE_Water/MapServer/1', symbol: { color: [205, 205, 102, 255], width: 3 } },
                { title: '二维管线_通信', id: 'gx2d_tx', url: 'http://10.89.5.191/OneMapServer/rest/services/PIPE_Telecom/MapServer/1', symbol: { color: [130, 52, 0, 255], width: 3 } },
                { title: '二维管线_排水', id: 'gx2d_ps', url: 'http://10.89.5.191/OneMapServer/rest/services/PIPE_Sewer/MapServer/1', symbol: { color: [94, 176, 0, 255], width: 3 } },
                { title: '二维管线_电力', id: 'gx2d_dl', url: 'http://10.89.5.191/OneMapServer/rest/services/PIPE_Power/MapServer/1', symbol: { color: [137, 68, 68, 255], width: 3 } },
                // { title: '二维管线_其它', id: 'gx2d_qt', url: 'http://10.89.5.191/OneMapServer/rest/services/PIPE_Other/MapServer/1', symbol: { color: [205, 170, 102, 255], width: 3 } },
            ].forEach(item => {
                let tmp = undefined;

                if (pinType === 'gx2d' || pinType === item.id) {
                    tmp = new this.ArcGisFeatureLayer({
                        url: item.url,
                        renderer: {
                            type: 'simple',
                            symbol: {
                                type: 'simple-line',
                                style: 'solid',
                                ...item.symbol
                            },
                        },
                        minScale: 0,
                        maxScale: 0,
                        spatialReference: this.spatialReferencevalue,
                        title: item.title,
                        id: item.id
                    });
                }

                if (tmp) {
                    if (!layer) {
                        layer = [];
                    }
                    layer.push(tmp);
                }
            });
        }
        // 管线3D
        else if (pinType.indexOf('gx3d') !== -1) {
            (
                region && region.indexOf('临空') !== -1 ?
                    [
                        { title: '工业管线', id: 'gygx', key: 'gx3d_gy', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_TZ_PIPES/SceneServer', color: [230, 152, 0, 255] },
                        { title: '燃气管点', id: 'rqgd', key: 'gx3d_rq', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_RQ_POINTS/SceneServer', color: [168, 168, 0, 255], center: { x: -12005.17603494779, y: -2485.342667736906 }, camera: { heading: 2.4171656982209138, tilt: 70.8464848466116 }, zoom: 12.545009203224511 },
                        { title: '燃气管线', id: 'rqgx', key: 'gx3d_rq', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_RQ_PIPES/SceneServer', color: [168, 168, 0, 255], center: { x: -12005.17603494779, y: -2485.342667736906 }, camera: { heading: 2.4171656982209138, tilt: 70.8464848466116 }, zoom: 12.545009203224511 },
                        { title: '给水管点', id: 'gsgd', key: 'gx3d_gs', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_JS_POINTS/SceneServer', color: [205, 205, 102, 255], center: { x: -12005.17603494779, y: -2485.342667736906 }, camera: { heading: 2.4171656982209138, tilt: 70.8464848466116 }, zoom: 12.545009203224511 },
                        { title: '给水管线', id: 'gsgx', key: 'gx3d_gs', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_JS_PIPES/SceneServer', color: [205, 205, 102, 255], center: { x: -12005.17603494779, y: -2485.342667736906 }, camera: { heading: 2.4171656982209138, tilt: 70.8464848466116 }, zoom: 12.545009203224511 },
                        { title: '电信管点', id: 'dxgd', key: 'gx3d_dx', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_DX_POINTS/SceneServer', color: [130, 52, 0, 255], center: { x: -12005.17603494779, y: -2485.342667736906 }, camera: { heading: 2.4171656982209138, tilt: 70.8464848466116 }, zoom: 12.545009203224511 },
                        { title: '电信管线', id: 'dxgx', key: 'gx3d_dx', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_DX_PIPES/SceneServer', color: [130, 52, 0, 255], center: { x: -12005.17603494779, y: -2485.342667736906 }, camera: { heading: 2.4171656982209138, tilt: 70.8464848466116 }, zoom: 12.545009203224511 },
                        { title: '排水管点', id: 'psgd', key: 'gx3d_ps', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_PS_POINTS/SceneServer', color: [94, 176, 0, 255], center: { x: -12005.17603494779, y: -2485.342667736906 }, camera: { heading: 2.4171656982209138, tilt: 70.8464848466116 }, zoom: 12.545009203224511 },
                        { title: '排水管线', id: 'psgd', key: 'gx3d_ps', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_PS_PIPES/SceneServer', color: [94, 176, 0, 255], center: { x: -12005.17603494779, y: -2485.342667736906 }, camera: { heading: 2.4171656982209138, tilt: 70.8464848466116 }, zoom: 12.545009203224511 },
                        { title: '电力管点', id: 'dlgd', key: 'gx3d_dl', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_DL_POINTS/SceneServer', color: [137, 68, 68, 255], center: { x: -12005.17603494779, y: -2485.342667736906 }, camera: { heading: 2.4171656982209138, tilt: 70.8464848466116 }, zoom: 12.545009203224511 },
                        { title: '电力管线', id: 'dlgx', key: 'gx3d_dl', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_DL_PIPES/SceneServer', color: [137, 68, 68, 255], center: { x: -12005.17603494779, y: -2485.342667736906 }, camera: { heading: 2.4171656982209138, tilt: 70.8464848466116 }, zoom: 12.545009203224511 },
                    ] :
                    [
                        // { title: '工业管线', id: 'gygx', key: 'gx3d_gy', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_TZ_PIPES/SceneServer', color: [230, 152, 0, 255] },
                        // { title: '燃气管点', id: 'rqgd', key: 'gx3d_rq', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_RQ_POINTS/SceneServer', color: [168, 168, 0, 255], center: { x: -6802.554855592013, y: -3071.058023966195 }, camera: { heading: 1.7904931097467067, tilt: 66.70845632623002 }, zoom: 15.5 },
                        // { title: '燃气管线', id: 'rqgx', key: 'gx3d_rq', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_RQ_PIPES/SceneServer', color: [168, 168, 0, 255], center: { x: -6802.554855592013, y: -3071.058023966195 }, camera: { heading: 1.7904931097467067, tilt: 66.70845632623002 }, zoom: 15.5 },
                        // { title: '给水管点', id: 'gsgd', key: 'gx3d_gs', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_JS_POINTS/SceneServer', color: [205, 205, 102, 255], center: { x: -6806.1212176192, y: -3063.941530060756 }, camera: { heading: 1.7904931097467067, tilt: 66.70845632623002 }, zoom: 15.5 },
                        // { title: '给水管线', id: 'gsgx', key: 'gx3d_gs', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_JS_PIPES/SceneServer', color: [205, 205, 102, 255], center: { x: -6806.1212176192, y: -3063.941530060756 }, camera: { heading: 1.7904931097467067, tilt: 66.70845632623002 }, zoom: 15.5 },
                        // { title: '电信管点', id: 'dxgd', key: 'gx3d_dx', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_DX_POINTS/SceneServer', color: [130, 52, 0, 255], center: { x: -6779.695248607764, y: -3034.895374201297 }, camera: { heading: 1.7904931097467067, tilt: 66.70845632623002 }, zoom: 14 },
                        // { title: '电信管线', id: 'dxgx', key: 'gx3d_dx', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_DX_PIPES/SceneServer', color: [130, 52, 0, 255], center: { x: -6779.695248607764, y: -3034.895374201297 }, camera: { heading: 1.7904931097467067, tilt: 66.70845632623002 }, zoom: 14 },
                        // { title: '排水管点', id: 'psgd', key: 'gx3d_ps', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_PS_POINTS/SceneServer', color: [94, 176, 0, 255], center: { x: -6810.271488139631, y: -3056.5190128290374 }, camera: { heading: 1.7904931097467067, tilt: 66.70845632623002 }, zoom: 14.76 },
                        // { title: '排水管线', id: 'psgd', key: 'gx3d_ps', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_PS_PIPES/SceneServer', color: [94, 176, 0, 255], center: { x: -6810.271488139631, y: -3056.5190128290374 }, camera: { heading: 1.7904931097467067, tilt: 66.70845632623002 }, zoom: 14.76 },
                        // { title: '电力管点', id: 'dlgd', key: 'gx3d_dl', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_DL_POINTS/SceneServer', color: [137, 68, 68, 255], center: { x: -6810.271488139631, y: -3056.5190128290374 }, camera: { heading: 1.7904931097467067, tilt: 66.70845632623002 }, zoom: 14.76 },
                        // { title: '电力管线', id: 'dlgx', key: 'gx3d_dl', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_DL_PIPES/SceneServer', color: [137, 68, 68, 255], center: { x: -6810.271488139631, y: -3056.5190128290374 }, camera: { heading: 1.7904931097467067, tilt: 66.70845632623002 }, zoom: 14.76 },

                        { title: '工业管线', id: 'gygx', key: 'gx3d_gy', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_TZ_PIPES/SceneServer', color: [230, 152, 0, 255] },
                        { title: '燃气管点', id: 'rqgd', key: 'gx3d_rq', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_RQ_POINTS/SceneServer', color: [168, 168, 0, 255], center: { x: -5181.653734219648, y: -1648.8043573202447 }, camera: { heading: 359.820950689025, tilt: 22.781692032858544 }, zoom: 11.216653192998628 },
                        { title: '燃气管线', id: 'rqgx', key: 'gx3d_rq', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_RQ_PIPES/SceneServer', color: [168, 168, 0, 255], center: { x: -5181.653734219648, y: -1648.8043573202447 }, camera: { heading: 359.820950689025, tilt: 22.781692032858544 }, zoom: 11.216653192998628 },
                        { title: '给水管点', id: 'gsgd', key: 'gx3d_gs', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_JS_POINTS/SceneServer', color: [205, 205, 102, 255], center: { x: -5181.653734219648, y: -1648.8043573202447 }, camera: { heading: 359.820950689025, tilt: 22.781692032858544 }, zoom: 11.216653192998628 },
                        { title: '给水管线', id: 'gsgx', key: 'gx3d_gs', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_JS_PIPES/SceneServer', color: [205, 205, 102, 255], center: { x: -5181.653734219648, y: -1648.8043573202447 }, camera: { heading: 359.820950689025, tilt: 22.781692032858544 }, zoom: 11.216653192998628 },
                        { title: '电信管点', id: 'dxgd', key: 'gx3d_dx', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_DX_POINTS/SceneServer', color: [130, 52, 0, 255], center: { x: -5181.653734219648, y: -1648.8043573202447 }, camera: { heading: 359.820950689025, tilt: 22.781692032858544 }, zoom: 11.216653192998628 },
                        { title: '电信管线', id: 'dxgx', key: 'gx3d_dx', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_DX_PIPES/SceneServer', color: [130, 52, 0, 255], center: { x: -5181.653734219648, y: -1648.8043573202447 }, camera: { heading: 359.820950689025, tilt: 22.781692032858544 }, zoom: 11.216653192998628 },
                        { title: '排水管点', id: 'psgd', key: 'gx3d_ps', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_PS_POINTS/SceneServer', color: [94, 176, 0, 255], center: { x: -5181.653734219648, y: -1648.8043573202447 }, camera: { heading: 359.820950689025, tilt: 22.781692032858544 }, zoom: 11.216653192998628 },
                        { title: '排水管线', id: 'psgd', key: 'gx3d_ps', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_PS_PIPES/SceneServer', color: [94, 176, 0, 255], center: { x: -5181.653734219648, y: -1648.8043573202447 }, camera: { heading: 359.820950689025, tilt: 22.781692032858544 }, zoom: 11.216653192998628 },
                        { title: '电力管点', id: 'dlgd', key: 'gx3d_dl', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_DL_POINTS/SceneServer', color: [137, 68, 68, 255], center: { x: -5181.653734219648, y: -1648.8043573202447 }, camera: { heading: 359.820950689025, tilt: 22.781692032858544 }, zoom: 11.216653192998628 },
                        { title: '电力管线', id: 'dlgx', key: 'gx3d_dl', url: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_DL_PIPES/SceneServer', color: [137, 68, 68, 255], center: { x: -5181.653734219648, y: -1648.8043573202447 }, camera: { heading: 359.820950689025, tilt: 22.781692032858544 }, zoom: 11.216653192998628 },
                    ]
            ).forEach(item => {
                if (!layer) {
                    layer = [];
                }

                if (pinType === 'gx3d' || pinType === item.key) {
                    if (!center) {
                        center = item.center;
                        zoom = item.zoom;
                        camera = item.camera;
                    }
                    layer.push(new this.ArcGisSceneLayer({
                        url: item.url,
                        popupEnabled: false,
                        renderer: {
                            type: 'simple',
                            symbol: {
                                type: 'mesh-3d',
                                symbolLayers: [
                                    {
                                        type: 'fill',
                                        material: {
                                            color: item.color,
                                            transparency: 0,
                                            colorMixMode: 'multiply',
                                        },
                                        edges: {
                                            type: 'solid',
                                            color: [0, 0, 0, 0.1],
                                            size: 1,
                                        },
                                    },
                                ],
                            },
                        },
                        id: item.id
                    }));
                }
            });
        }

        if (layer) {
            if (Array.isArray(layer)) {
                this.map.addMany(layer, index);
            } else {
                this.map.add(layer, index);
            }
            this.featureLayers[pinType] = layer;
            if (center) {
                console.info('camera', this.view.camera);
                // if (this.view.type === '3d' && this.view.camera.heading === 0) {
                //     this.view.goTo(
                //         {
                //             position: new this.ArcGisPoint({
                //                 x: center.x,
                //                 y: center.y,
                //                 spatialReference: this.spatialReferencevalue,
                //             }),
                //         },
                //         { duration: 1000 }
                //     ).then(() => {
                //         this.view.goTo({ zoom, ...camera }, { duration: 1000 });
                //     });
                // }
            }
        }
    }

    // 创建点位图层
    generateGraphLayer(data, layer) {
        console.log(data, layer);
        const { pinType, params = {}, points = [] } = data;
        const { icon = '', renderType, heatmapField, flash } = params;
        let icons = [], colors = [];
        let renderer = undefined, popupTemplate = undefined, flashLayer = undefined, maxZ = 0;

        const source = points.filter(p => (p.x && p.y) || (p.X && p.Y)).map(p => {
            if (p.icon && !icons.includes(p.icon)) {
                icons.push(p.icon);
            }
            if (p.color && !colors.includes(p.color)) {
                colors.push(p.color);
            }
            let z = (p.z || p.Z);
            z = z ? parseInt(z) : 0;
            maxZ = Math.max(maxZ, isNaN(z) ? 0 : z);

            return new this.ArcGisGraphic({
                attributes: { ...p },
                geometry: {
                    type: 'point',
                    hasZ: true,
                    x: +(p.x || p.X),
                    y: +(p.y || p.Y),
                    z: (p.z || p.Z) || 0,
                    spatialReference: this.spatialReferencevalue,
                },
                // 2d
                symbol: flash ?
                    {
                        'type': 'simple-marker',
                        'size': 25,
                        'color': p.color ? p.color : 'rgb(48, 168, 91)',
                        'style': 'circle',
                        'outline': {
                            'width': 2,
                            'color': 'black'
                        }
                    } :
                    this.defaultMarks(p.icon ? p.icon : icon ? icon : undefined, maxZ)
                // 测试
                // symbol: {
                //     'type': 'simple-marker',
                //     'size': 20,
                //     'color': '#ff5757',
                //     'style': 'circle',
                //     'outline': {
                //         'width': 2,
                //         'color': '#ff5757'
                //     }
                // }
            });
        });

        let fields = [
            { name: 'OBJECTID', alias: 'OBJECTID', type: 'oid' },
            { name: 'sbbh', alias: 'sbbh', type: 'string' },
            { name: 'name', alias: 'name', type: 'string' },
            { name: 'type', alias: 'type', type: 'string' },
            { name: 'address', alias: 'address', type: 'string' },
            { name: 'pinType', alias: 'pinType', type: 'string' },
            { name: 'schooltype', alias: 'schooltype', type: 'string' },
            { name: 'state', alias: 'state', type: 'string' },
            { name: 'popup', alias: 'popup', type: 'string' },
            { name: 'sbzbs', alias: 'sbzbs', type: 'string' },
            { name: 'sbztms', alias: 'sbztms', type: 'string' },
            { name: 'statePos', alias: 'statePos', type: 'small-integer' },
            { name: 'infoJSON', alias: 'infoJSON', type: 'string' },
            { name: 'infotype', alias: 'infotype', type: 'string' },
            { name: 'icon', alias: 'icon', type: 'string' },
            { name: 'color', alias: 'color', type: 'string' },
            { name: 'iconType', alias: 'iconType', type: 'string' },
            { name: 'extra', alias: 'extra', type: 'string' },
            { name: 'list', alias: 'list', type: 'string' },
            { name: 'X', alias: 'X', type: 'string' },
            { name: 'Y', alias: 'Y', type: 'string' },
            { name: 'Z', alias: 'Z', type: 'string' },
        ];

        if (renderType === 'heatmap') {
            const fieldData = points.map(p => isNaN(parseFloat(p[heatmapField])) ? 0 : parseFloat(p[heatmapField]));
            const max = Math.max(...fieldData), min = Math.min(...fieldData);
            const sample = points && points[0] ? points[0] : {};
            let array = undefined;
            let otherFields = [];
            let otherTemplate = '';

            try {
                array = JSON.parse(sample.sbzbs)
            } catch (e) {
                array = [];
            }
            array.forEach((item, index) => {
                otherFields.push({ name: `szms${index + 1}`, alias: `szms${index + 1}`, type: 'string' });
                otherFields.push({ name: `sz${index + 1}`, alias: `sz${index + 1}`, type: 'string' });

                if (index !== (array.length - 1)) {
                    otherTemplate += `
                        <tr>
                            <td style='min-width: 240px; color: #00c2ff'>{${`szms${index + 1}`}}</td>
                            <td>{${`sz${index + 1}`}}</td>
                        </tr>
                    `;
                }
            });
            fields = [...fields, ...otherFields];

            renderer = {
                type: 'heatmap',
                field: heatmapField,
                colorStops: [
                    { color: 'rgba(0, 0, 0, 0)', ratio: 0 },
                    { color: 'rgba(99, 220, 111, 1)', ratio: !isNaN(max) && max > 1 ? 0.3 / max : 0.3 },
                    { color: 'rgba(251, 220, 96, 1)', ratio: !isNaN(max) && max > 1 ? 0.6 / max : 0.6 },
                    { color: 'rgba(236, 82, 82, 1)', ratio: 1 }
                ],
                blurRadius: 18,
                minPixelIntensity: min,
                maxPixelIntensity: max < 1 ? 1 : max
            }
            popupTemplate = {
                actions: [],
                overwriteActions: true,
                'title': '',
                'content': `
                    <div class='popup_dom_wrapper' style='border-radius: 0'>
                        <div class='popup_dom_title'>{name}</div>
                        <div style='padding: 0 32px'>
                            <table class='popup_dom_content'>
                                <tbody>
                                    <tr>
                                        <td style='min-width: 240px; color: #00c2ff'>地址</td>
                                        <td>{address}</td>
                                    </tr>
                                    <tr>
                                        <td style='min-width: 240px; color: #00c2ff'>类型</td>
                                        <td>{infotype}</td>
                                    </tr>
                                    ${otherTemplate}
                                </tbody>
                            </table>
                        </div>
                    </div>
                `
            };
        } else {
            if (icons && icons.length > 0) {
                renderer = {
                    type: 'unique-value',
                    field: /*navigator.platform.indexOf('Linux') !== -1 ? 'iconType' :*/ 'icon',
                    defaultSymbol: this.defaultMarks(icon, maxZ),
                    uniqueValueInfos:
                        // navigator.platform.indexOf('Linux') !== -1 ?
                        //     [
                        //         {
                        //             value: '1',
                        //             symbol: {
                        //                 type: 'simple-marker',
                        //                 size: this.props.region === '民政16:9' ? 20 : this.props.region === '华政步道' ? 120 : 80,
                        //                 style: 'circle',
                        //                 'color': '#ff5757',
                        //                 'outline': {
                        //                     'width': 2,
                        //                     'color': '#ff5757'
                        //                 }
                        //             }
                        //         },
                        //         {
                        //             value: '2',
                        //             symbol: {
                        //                 type: 'simple-marker',
                        //                 size: this.props.region === '民政16:9' ? 20 : this.props.region === '华政步道' ? 120 : 80,
                        //                 style: 'circle',
                        //                 'color': '#aa1313',
                        //                 'outline': {
                        //                     'width': 2,
                        //                     'color': '#aa1313'
                        //                 }
                        //             }
                        //         },
                        //         {
                        //             value: '3',
                        //             symbol: {
                        //                 type: 'simple-marker',
                        //                 size: this.props.region === '民政16:9' ? 20 : this.props.region === '华政步道' ? 120 : 80,
                        //                 style: 'circle',
                        //                 'color': '#b8deeb',
                        //                 'outline': {
                        //                     'width': 2,
                        //                     'color': '#02bfff'
                        //                 }
                        //             }
                        //         },
                        //         {
                        //             value: '4',
                        //             symbol: {
                        //                 type: 'simple-marker',
                        //                 size: this.props.region === '民政16:9' ? 20 : this.props.region === '华政步道' ? 120 : 80,
                        //                 style: 'circle',
                        //                 'color': '#b9eada',
                        //                 'outline': {
                        //                     'width': 2,
                        //                     'color': '#06faab'
                        //                 }
                        //             }
                        //         }
                        //     ] :
                        icons.map(i => ({
                            value: i,
                            symbol: this.defaultMarks(i, maxZ)
                        }))
                };
            } else if (colors && colors.length > 0) {
                renderer = {
                    type: 'unique-value',
                    field: 'color',
                    defaultSymbol: {
                        'type': 'simple-marker',
                        'size': 25,
                        'color': 'rgb(48, 168, 91)',
                        'style': 'circle',
                        'outline': {
                            'width': 2,
                            'color': 'black'
                        }
                    },
                    uniqueValueInfos:
                        colors.map(i => ({
                            value: i,
                            symbol: {
                                'type': 'simple-marker',
                                'size': 25,
                                'color': i,
                                'style': 'circle',
                                'outline': {
                                    'width': 2,
                                    'color': 'black'
                                }
                            }
                        }))
                };
            } else {
                renderer = {
                    type: 'simple',
                    symbol: flash ?
                        {
                            'type': 'simple-marker',
                            'size': 25,
                            'color': 'rgb(48, 168, 91)',
                            'style': 'circle',
                            'outline': {
                                'width': 2,
                                'color': 'black'
                            }
                        } :
                        this.defaultMarks(icon, maxZ)
                };
            }
        }
        // if (flash && this.CustomLayer) {
        //     const graphics = points.filter(p => (p.x && p.y) || (p.X && p.Y)).map(p => {
        //         return new this.ArcGisGraphic({
        //             attributes: { ...p },
        //             geometry: {
        //                 type: 'point',
        //                 x: +(p.x || p.X),
        //                 y: +(p.y || p.Y),
        //                 z: 200,
        //                 spatialReference: this.spatialReferencevalue,
        //             }
        //         });
        //     });
        //     flashLayer = new this.CustomLayer({
        //         objectIdField: 'OBJECTID',
        //         fields,
        //         outFields: ['*'],
        //         popupTemplate
        //     });
        //     graphics.forEach(item => {
        //         flashLayer.add(item);
        //     });
        // }

        if (layer) {
            if (Array.isArray(layer)) {
                layer.forEach(l => {
                    this.map.remove(l);
                })
            } else {
                this.map.remove(layer);
            }

            setTimeout(() => {
                const tmp = Array.isArray(layer) ? layer[layer.length - 1] : layer;

                tmp.source = source;
                tmp.renderer = renderer;
                tmp.popupTemplate = popupTemplate;
                tmp.visible = true;
                tmp.refresh();
                this.map.add(tmp);
                if (flashLayer) {
                    this.map.add(flashLayer);
                }
                this.featureLayers[pinType] = flashLayer ? [flashLayer, tmp] : tmp;
            }, 200);
        } else {
            layer = new this.ArcGisFeatureLayer({
                source,
                objectIdField: 'OBJECTID',
                fields,
                outFields: ['*'],
                geometryType: 'point',
                elevationInfo: { mode: 'relative-to-scene' },
                screenSizePerspectiveEnabled: false,
                renderer,
                popupTemplate,
            });

            // layer = new this.ArcGisGraphicsLayer({
            //     objectIdField: 'OBJECTID',
            //     fields,
            //     outFields: ['*'],
            //     // renderer,
            //     popupTemplate
            // });
            // if (source && source.length > 0) {
            //     source.forEach(item => {
            //         layer.add(item);
            //     });
            // }

            this.map.add(layer);
            if (flashLayer) {
                this.map.add(flashLayer);
            }
            this.featureLayers[pinType] = flashLayer ? [flashLayer, layer] : layer;
        }
    }

    // 创建路况图层
    generateRoedLayer(list) {
        const { region = '长宁' } = this.props;
        const keys = Object.keys(list);

        // if (!this.state.mapReady) {
        //     return;
        // }

        keys.forEach(key => {
            const { data, state } = list[key];

            if (state) {
                if (key === 'road') {
                    const features = VERSION === 'new' ?
                        [
                            { url: 'http://10.89.5.191/OneMapServer/rest/services/JTLL_DMDL/MapServer/4', title: '地面主干道路发布段_二级显示 (4)', id: 'ROAD_DM_4', visible: [0, 9] },
                            { url: 'http://10.89.5.191/OneMapServer/rest/services/JTLL_DMDL/MapServer/1', title: '地面主干道路发布段_二级显示 (1)', id: 'ROAD_DM_1', visible: [0, 9] },
                            // { url: 'http://10.89.5.191/OneMapServer/rest/services/JTLL_DMDL/MapServer/1', title: '地面主干道路发布段_一级显示 (0)', id: 'ROAD_DM_0', visible: [0, 9] },
                            { url: 'http://10.89.5.191/OneMapServer/rest/services/JTLL_DMDL/MapServer/2', title: '地面主干道路发布段 (2)', id: 'ROAD_DM_2', visible: [9, Infinity] },
                            { url: 'http://10.89.5.191/OneMapServer/rest/services/JTLL_DMDL/MapServer/3', title: '地面次干道路发布段 (3)', id: 'ROAD_DM_3', visible: [9, Infinity] },
                            { url: 'http://10.89.5.191/OneMapServer/rest/services/JTLL_DMDL/MapServer/5', title: '地面次干道路发布段 (5)', id: 'ROAD_DM_4', visible: [9, Infinity] },
                            // { url: 'http://10.89.5.191/OneMapServer/rest/services/JTLL_DMDL/MapServer/5', title: '地面主干道路发布段_全景显示 (6)', id: 'ROAD_DM_6', visible: [9, Infinity] }
                        ] :
                        [
                            { url: 'http://10.207.204.19/server/rest/services/ROAD_DM/MapServer/7', title: '地面次干道路发布段_二级显示 (7)', id: 'ROAD_DM_7', visible: [0, 9] },
                            { url: 'http://10.207.204.19/server/rest/services/ROAD_DM/FeatureServer/4', title: '地面次干道路发布段_二级显示 (4)', id: 'ROAD_DM_4', visible: [0, 9] },
                            { url: 'http://10.207.204.19/server/rest/services/ROAD_DM/FeatureServer/8', title: '地面一般道路发布段 (8)', id: 'ROAD_DM_8', visible: [9, Infinity] },
                            { url: 'http://10.207.204.19/server/rest/services/ROAD_DM/FeatureServer/6', title: '地面次干道路发布段 (6)', id: 'ROAD_DM_6', visible: [9, Infinity] },
                            { url: 'http://10.207.204.19/server/rest/services/ROAD_DM/FeatureServer/5', title: '地面次干道路发布段 (5)', id: 'ROAD_DM_5', visible: [9, Infinity] }
                        ];
                    const renderer = {
                        type: 'unique-value',
                        field: 'bm_code',
                        defaultSymbol: { type: 'simple-fill', color: '#38A800', outline: { width: 0 } },
                        uniqueValueInfos: Object.keys(data).map(bmCode => {
                            return ({
                                value: bmCode + '',
                                symbol: {
                                    type: 'simple-fill',
                                    color: data[bmCode] === '21' ? 'rgb(48, 168, 91)' :
                                        data[bmCode] === '22' ? '#FFCF00' :
                                            data[bmCode] === '23' ? '#E60000' :
                                                data[bmCode] === '25' ? '#9C9C9C' :
                                                    '#38A800',
                                    outline: { color: '#002F47', join: 'round', width: 0 }
                                }
                            });
                        })
                    };
                    // 开始不存在，初始化图层
                    if (!this.newFatureLayers[key]) {
                        // 长宁
                        const definitionExpression = REGION_CONFIG[region] ? REGION_CONFIG[region].definitionExpression : undefined;
                        // 江苏街道
                        // const definitionExpression = `bm_code in (${jiangsuStreet.join(',')})`;
                        const roads = features.map(item => {
                            const road = new this.ArcGisFeatureLayer({
                                url: item.url,
                                renderer,
                                minScale: 0,
                                maxScale: 0,
                                spatialReference: this.spatialReferencevalue,
                                title: item.title,
                                visible: item.visible[0] <= (this.view.zoom || (REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM)) && (this.view.zoom || (REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM)) < item.visible[1],
                                outFields: ['*'],
                                popupTemplate: {
                                    'title': '',
                                    'content': `
                                            <div class='popup_dom_wrapper' style='border-radius: 0'>
                                                <div class='popup_dom_title'>{路名}</div>
                                                <div style='padding: 0 32px'>
                                                    <table class='popup_dom_content'>
                                                        <tbody>
                                                            <tr>
                                                                <td style='min-width: 240px; color: #00c2ff'>起点交叉路</td>
                                                                <td>{起点交叉路}</td>
                                                            </tr>
                                                            <tr>
                                                                <td style='min-width: 240px; color: #00c2ff'>终点交叉路</td>
                                                                <td>{终点交叉路}</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        `
                                },
                                definitionExpression
                            });
                            this.map.add(road);
                            return { visible: item.visible, layer: road }
                        });
                        this.view.popup.autoOpenEnabled = true;
                        this.newFatureLayers[key] = roads;
                        this.newTmpData[key] = data;
                    } else {
                        if (!_.isEqual(this.newTmpData[key], data)) {
                            if (Array.isArray(this.newFatureLayers[key]) && this.newFatureLayers[key].length > 0) {
                                this.newFatureLayers[key].forEach(item => {
                                    const { layer } = item;
                                    if (layer) {
                                        layer.renderer = renderer;
                                        layer.refresh();
                                    }
                                });
                            } else if (this.newFatureLayers[key]) {
                                this.newFatureLayers[key].renderer = renderer;
                                this.newFatureLayers[key].refresh();
                            }
                        }
                    }
                }
            } else if (!state && this.newFatureLayers[key]) {
                if (Array.isArray(this.newFatureLayers[key]) && this.newFatureLayers[key].length > 0) {
                    this.newFatureLayers[key].forEach(item => {
                        this.map.remove(item.layer);
                        item.layer.destroy();
                    });
                } else {
                    this.map.remove(this.newFatureLayers[key]);
                    this.newFatureLayers[key].destroy();
                }
                this.view.popup.autoOpenEnabled = false;
                this.newFatureLayers[key] = undefined;
                this.newTmpData[key] = undefined;
            }
        });
    }

    // 改变中心点
    changeCenter(road, region) {
        console.log('changeCenter', road, region);
        // 长宁边界
        let cnBorder = this.featureLayers['cnBorder'];
        // 长宁区街道
        let cnCountry = this.featureLayers['cnCountry'];

        if (road) {
            const renderer = {
                type: 'unique-value',
                field: 'NAME',
                defaultSymbol: {
                    type: 'simple-fill',
                    color: this.props.region && this.props.region.indexOf('2d') !== -1 ? [0, 0, 0, 0] : [0, 0, 0, 0.6],
                    style: 'solid',
                    outline: {
                        width: 0
                    }
                },
                uniqueValueInfos: [
                    {
                        // value: road.indexOf('_shzz_pc') !== -1 ? road.replace('_shzz_pc', '') : road.indexOf('_shzz') !== -1 ? road.replace('_shzz', '') : road,
                        value: road.split('_').length > 1 ? road.split('_')[0] : road,
                        symbol: {
                            type: 'simple-fill',
                            color: [0, 0, 0, 0],
                            style: 'solid',
                            outline: {
                                color: [64, 189, 255, 1],
                                width: 2
                            }
                        }
                    }
                ]
            };

            if (road !== 'all') {
                const roadData = ROAD_CENTER[road];

                if (roadData) {
                    if (!roadData.changeOnly) {
                        if (cnBorder) {
                            cnBorder.visible = false;
                        }
                        if (cnCountry) {
                            cnCountry.visible = true;
                            cnCountry.renderer = renderer;
                            cnCountry.refresh();
                        } else {
                            cnCountry = LayerFactory.generateStreetLayer(this.ArcGisFeatureLayer, VERSION, this.spatialReferencevalue, renderer, null, null, null, region);
                            this.map.add(cnCountry);
                            this.featureLayers['cnCountry'] = cnCountry;
                        }
                    }

                    if (road.indexOf('交互枢纽') !== -1) {
                        this.view.goTo({
                            center: roadData.center,
                            zoom: roadData.zoom
                        });
                    } else {
                        this.view.zoom = roadData.zoom;
                        this.view.goTo(
                            new this.ArcGisPoint({
                                x: roadData.center[0],
                                y: roadData.center[1],
                                spatialReference: this.spatialReferencevalue,
                            })
                        );
                    }
                }
            } else {
                if (cnCountry) {
                    this.map.remove(cnCountry);
                    this.featureLayers['cnCountry'] = undefined;
                }
                if (cnBorder) {
                    cnBorder.visible = true;
                }
                this.view.zoom = REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM;
                this.view.goTo(
                    new this.ArcGisPoint({
                        x: (REGION_CONFIG[region] ? REGION_CONFIG[region].center : CENTER)[0],
                        y: (REGION_CONFIG[region] ? REGION_CONFIG[region].center : CENTER)[1],
                        spatialReference: this.spatialReferencevalue,
                    })
                );
            }

            this.road = road;
        }
    }

    defaultMarks(url, z) {
        // if (navigator.platform.indexOf('Linux') !== -1) {
        //     return {
        //         type: 'simple-marker',
        //         size: this.props.region === '民政16:9' ? 20 : this.props.region === '华政步道' ? 120 : 80,
        //         style: 'circle',
        //         'color': '#fff',
        //         'outline': {
        //             'width': 1,
        //             'color': '#fff'
        //         }
        //     };
        // } else {
        // return {
        //     type: 'picture-marker',
        //     url: this.props.region && this.props.region.indexOf('2d') === -1 ? url || defaultIcon : defaultIcon,
        //     width: this.props.region === '民政16:9' ? '20px' : this.props.region === '华政步道' ? '120px' : '80px',
        //     height: this.props.region === '民政16:9' ? '20px' : this.props.region === '华政步道' ? '120px' : '80px',
        // };
        // }
        if (z && z > 0) {
            return {
                type: 'point-3d',
                symbolLayers: [
                    {
                        type: 'icon',
                        resource: {
                            href: this.props.region && this.props.region.indexOf('2d') === -1 ? url || defaultIcon : defaultIcon
                            // 'https://developers.arcgis.com/javascript/latest/sample-code/visualization-point-styles/live/Museum.png'
                        },
                        size: this.props.region === '民政16:9' ? 20 : this.props.region === '华政步道' ? 120 : 80,
                        // outline: {
                        //     color: 'white',
                        //     size: 2
                        // }
                    }
                ],
                verticalOffset: {
                    screenLength: Math.max(z / 2, 150),
                    maxWorldLength: Math.max(z, 400),
                    minWorldLength: 0
                },
                callout: {
                    type: 'line',
                    color: 'white',
                    size: 8,
                    border: {
                        color: '#D13470'
                    }
                }
            }
        } else {
            return {
                type: 'picture-marker',
                url: this.props.region && this.props.region.indexOf('2d') === -1 ? url || defaultIcon : defaultIcon,
                width: this.props.region === '民政16:9' ? '20px' : this.props.region === '华政步道' ? '120px' : '80px',
                height: this.props.region === '民政16:9' ? '20px' : this.props.region === '华政步道' ? '120px' : '80px',
            };
        }
    }

    initCall(config) {
        try {
            const _ = this;

            if (config) {
                const { prefix, ...extra } = config;
                this.prefix = prefix;
                this.agentClient = new AgentClient(extra);
                this.agentClient.setOption({
                    agentId: extra.agentId,
                    agentDn: extra.agentDn,
                    agentName: extra.agentId,
                    socketUrl: 'http://' + extra.proxyUrl + '/mywebsocket/' + extra.agentId + '/' + extra.agentDn,
                    proxyUrl: 'http://' + extra.proxyUrl
                });
                this.agentTimer = setInterval(() => {
                    const status = this.statusRef.current.value;
                    console.log('当前状态：', status);

                    if (status === '空闲态') {
                        this.setState({ online: true });
                    }
                    if (status === '通话态') {
                        if (_.activeId) {
                            const call = document.getElementById(`${_.activeId}-phone-call`);
                            if (call) {
                                call.style = 'display: none';
                            }
                            const forwarded = document.getElementById(`${_.activeId}-phone-forwarded`);
                            if (forwarded) {
                                forwarded.style = 'display: inline-block';
                            }
                        }
                    }
                    if (status === '整理') {
                        if (_.activeId) {
                            const call = document.getElementById(`${_.activeId}-phone-call`);
                            if (call) {
                                call.style = 'display: inline-block';
                            }
                            const forwarded = document.getElementById(`${_.activeId}-phone-forwarded`);
                            if (forwarded) {
                                forwarded.style = 'display: none';
                            }
                            const offDisabled = document.getElementById(`${_.activeId}-phone-off-disabled`);
                            if (offDisabled) {
                                offDisabled.style = 'display: inline-block';
                            }
                            const off = document.getElementById(`${_.activeId}-phone-off`);
                            if (off) {
                                off.style = 'display: none';
                            }
                            _.activeId = undefined;
                        }
                    }
                }, 2000);

                // this.agentClient.onOnline = function (event) {
                //     printEvent('onOnline', event);
                // };

                // this.agentClient.onOffline = function (event) {
                //     printEvent('onOffline', event);
                // };

                // this.agentClient.onStatusChanged = (event) => {
                //     const { eventType, currStatus } = event || {};
                //     const { label, status = {} } = CONST_CODE[eventType] || {};
                //     console.info('事件类型：', label, eventType, '，当前状态：', status[currStatus], currStatus);

                //     if (event && event.eventType === 3 && event.currStatus === 50) {
                //         this.setState({ online: true });
                //     }
                // };

                // this.agentClient.onDialing = function (event) {
                //     printEvent('onDialing', event);
                //     if (_.activeId) {
                //         const call = document.getElementById(`${_.activeId}-phone-call`);
                //         if (call) {
                //             call.style = 'display: none';
                //         }
                //         const forwarded = document.getElementById(`${_.activeId}-phone-forwarded`);
                //         if (forwarded) {
                //             forwarded.style = 'display: inline-block';
                //         }
                //     }
                // };

                // this.agentClient.onOffering = function (event) {
                //     printEvent('onOffering', event);
                // };

                // this.agentClient.onConnected = function (event) {
                //     printEvent('onConnected', event);
                // };

                // this.agentClient.onReleased = function (event) {
                //     printEvent('onReleased', event);
                //     if (_.activeId) {
                //         const call = document.getElementById(`${_.activeId}-phone-call`);
                //         if (call) {
                //             call.style = 'display: inline-block';
                //         }
                //         const forwarded = document.getElementById(`${_.activeId}-phone-forwarded`);
                //         if (forwarded) {
                //             forwarded.style = 'display: none';
                //         }
                //         const offDisabled = document.getElementById(`${_.activeId}-phone-off-disabled`);
                //         if (offDisabled) {
                //             offDisabled.style = 'display: inline-block';
                //         }
                //         const off = document.getElementById(`${_.activeId}-phone-off`);
                //         if (off) {
                //             off.style = 'display: none';
                //         }
                //         _.activeId = undefined;
                //     }
                // };

                // this.agentClient.onRecordEnd = function (event) {
                //     printEvent('onRecordEnd', event);
                // };

                // this.agentClient.onError = function (event) {
                //     printEvent('onError', event);
                // };

                this.agentClient.start();
            }
        } catch (e) {
            console.error('initCall error：', e);
        }
    }

    makeCall(activeId, value) {
        if (this.agentClient) {
            console.log('makeCall', `${this.prefix}${value}`);
            this.agentClient.makeCall(3, `${this.prefix}${value}`);
            this.activeId = activeId;

            const offDisabled = document.getElementById(`${activeId}-phone-off-disabled`);
            if (offDisabled) {
                offDisabled.style = 'display: none';
            }
            const off = document.getElementById(`${activeId}-phone-off`);
            if (off) {
                off.style = 'display: inline-block';
            }
        }
    }

    hangupCall() {
        if (this.agentClient) {
            console.log('hangupCall');
            this.agentClient.hangupCall();
        }
    }

    // 视频融合
    videoFusion(attributes) {
        try {
            console.log('vailed video', attributes);
            const { sbzbs } = attributes;
            let info = undefined;
            try {
                const tmp = JSON.parse(sbzbs);
                info = tmp.filter(t => t && t.name === 'info')[0];
                if (info) {
                    info = JSON.parse(info.value);
                }
            } catch (e) {
                console.error(e);
            }
            console.info(info);
            if (info.id) {
                if (this.threeCameras) this.threeCameras.cleanAllProjector();
                this.threeCamerasInfo.featureIDArray = [];
                this.threeCameras = new this.ArcGisThreeCameras(this.threeCamerasInfo);

                this.videoPlatformParams.deviceId = info.deviceId;
                axios.post(
                    'http://10.207.204.33:5479/sign/vedioservice/open',
                    { 'deviceId': this.videoPlatformParams.deviceId, 'protocol': 'http-flv', 'resolution': 'UHD' }
                ).then(response => {
                    console.log('获取到视频平台开流信息', response);
                    const videoUrl = response.data.result.data.send_uri;

                    this.threeCameras.createFlvPlayer('video_a', document.getElementById('videoElement_n1'), videoUrl).then(res => {
                        this.threeCameras.createProjector(info.id, MarkedInfo[info.info_id], res, './picture/2-1.png', false, false, false);
                    });
                }).catch(error => {
                    console.error(error);
                });
                console.info(info.postion, info.heading, info.tilt);
                let camera = new this.ArcGisCamera({
                    position: new this.ArcGisPoint({
                        hasZ: true,
                        // x: -10808,
                        // y: -1705,
                        // z: 12,
                        ...info.postion,
                        spatialReference: this.spatialReferencevalue
                    }),
                    // heading: 4,
                    // tilt: 78,
                    heading: info.heading,
                    tilt: info.tilt,
                });
                this.view.goTo(camera);
                this.view.popup.visible = false;
                document.onkeydown = (event) => {
                    var e = event || window.event || arguments.callee.caller.arguments[0];
                    if (e && e.keyCode == 27) {
                        console.info('addd');
                        if (this.threeCameras) this.threeCameras.cleanAllProjector();
                        this.resetCamera();
                        document.onkeydown = null;
                    }
                };
            }
        } catch (error) {
            console.error(error);
        }
    }

    componentDidMount() {
        let { region, callCfg } = this.props;
        const config = REGION_CONFIG[region] || {};
        const array = region.split('-');
        region = array[0];

        this.initCall(callCfg);
        window.getToken(VERSION);
        esriLoader
            .loadModules(
                [
                    'esri/config',
                    'esri/Map',
                    'esri/views/MapView',
                    'esri/views/SceneView',
                    'esri/geometry/Extent',
                    'esri/geometry/Point',
                    'esri/core/watchUtils',
                    // 'esri/core/promiseUtils',
                    // 'esri/geometry/support/webMercatorUtils',
                    // 'esri/views/2d/layers/BaseLayerViewGL2D',

                    'esri/identity/IdentityManager',
                    'esri/layers/TileLayer',
                    'esri/layers/IntegratedMeshLayer',
                    'esri/layers/FeatureLayer',
                    'esri/Graphic',
                    'esri/layers/GraphicsLayer',
                    'esri/layers/SceneLayer',
                    'dojo/dom-class',
                    'esri/tasks/QueryTask',
                    'esri/tasks/support/Query',
                    'esri/layers/support/LabelClass',
                    'esri/symbols/SimpleMarkerSymbol',
                    'esri/geometry/Polygon',
                    'esri/views/3d/externalRenderers',
                    'esri/Camera',
                    'app/threeCameras'
                ],
                { url: this.url }
            )
            .then(([
                esriConfig,
                Map,
                MapView,
                SceneView,
                Extent,
                Point,
                watchUtils,
                // promiseUtils,
                // webMercatorUtils,
                // BaseLayerViewGL2D,

                IdentityManager,
                TileLayer,
                IntegratedMeshLayer,
                FeatureLayer,
                Graphic,
                GraphicsLayer,
                SceneLayer,
                domClass,
                QueryTask,
                Query,
                LabelClass,
                SimpleMarkerSymbol,
                Polygon,
                externalRenderers,
                Camera,
                ThreeCameras
            ]) => {
                this.ArcGisPoint = Point;
                this.ArcGisTileLayer = TileLayer;
                this.ArcGisIntegratedMeshLayer = IntegratedMeshLayer;
                this.ArcGisFeatureLayer = FeatureLayer;
                this.ArcGisGraphic = Graphic;
                this.ArcGisGraphicsLayer = GraphicsLayer;
                this.ArcGisSceneLayer = SceneLayer;
                this.ArcGisQueryTask = QueryTask;
                this.ArcGisQuery = Query;
                this.ArcGisLabelClass = LabelClass;
                this.ArcGisSimpleMarkerSymbol = SimpleMarkerSymbol;
                this.ArcGisPolygon = Polygon;
                this.ArcGisExternalRenderers = externalRenderers;
                this.ArcGisCamera = Camera;
                this.ArcGisThreeCameras = ThreeCameras;

                // 加载字体文件
                esriConfig.fontsUrl = 'http://bigdata.cn.gov:9070/arcgisapi-master/fonts/arial-unicode-ms';
                // 初始化视图
                this.map = new Map({});

                // 2D
                if (config && config.viewType === '2d') {
                    this.view = new MapView({
                        container: 'arcgisContainer',
                        map: this.map,
                        center: config ? config.center : CENTER,
                        extent: new Extent({
                            type: 'extent',
                            xmax: 2116.0772399670277,
                            xmin: -18203.963400114255,
                            ymax: -16.55708170044818,
                            ymin: -5731.568511723309,
                            spatialReference: this.spatialReferencevalue
                        }),
                        zoom: config ? config.max_zoom : MAX_ZOOM,
                    });
                }
                // 3D 
                else {
                    this.view = new SceneView({
                        container: 'arcgisContainer',
                        map: this.map,
                        showLabels: true,
                        viewingMode: 'local',
                        center: config ? config.center : CENTER,
                        camera: {
                            tilt: 0,
                            zoom: config ? config.max_zoom : MAX_ZOOM
                        },
                        spatialReference: this.spatialReferencevalue,
                        extent: new Extent({
                            type: 'extent',
                            xmax: 2116.0772399670277,
                            xmin: -18203.963400114255,
                            ymax: -16.55708170044818,
                            ymin: -5731.568511723309,
                            spatialReference: this.spatialReferencevalue,
                        }),
                        sliderPosition: 'bottom-right',
                        sliderOrientation: 'horizontal',
                        zoom: config ? config.max_zoom : MAX_ZOOM,
                        qualityProfile: 'high',
                        environment: {
                            background: {
                                type: 'color',
                                color: [0, 0, 0, 0],
                            },
                            starsEnabled: false,
                            atmosphereEnabled: false,
                        },
                        highlightOptions: {
                            color: [64, 189, 255, 1],
                            haloOpacity: 0.8
                        }
                    });
                }

                const token = document.getElementById('txtToken').value;
                IdentityManager.registerToken({
                    server: VERSION === 'new' ? 'http://10.89.5.191/OneMapServer/rest/services' : 'http://map.cn.gov/OneMapServer/rest/services',
                    token,
                });

                const baseLayer = new TileLayer({
                    url: VERSION === 'new' ? 'http://10.89.5.191/OneMapServer/rest/services/shmw2bigsize_blueblack/MapServer' : 'http://10.207.204.19/server/rest/services/BIGANSE2/MapServer',
                    id: 'baseLayer',
                });
                // 长宁边界遮罩
                const maskBoundary = LayerFactory.generateMaskBoundaryLayer(FeatureLayer, VERSION, this.spatialReferencevalue);
                // 各街道光圈
                if (this.props.region && this.props.region.indexOf('2d') === -1 && (region.indexOf('长宁') === -1 || region !== '联通商圈' || region !== '民政16:9')) {
                    LayerFactory.generateShadowBorder(
                        this.url,
                        region && region.indexOf('临空') !== -1 ?
                            'http://10.89.5.191/OneMapServer/rest/services/street_11_linkong/FeatureServer/0' :
                            'http://10.89.5.191/OneMapServer/rest/services/STREEt_testzyy/MapServer/0',
                        this.spatialReferencevalue,
                        `NAME='${region}'`,
                        { lineWidth: 75, outlineNum: 75 },
                        (layer) => {
                            this.map.add(layer);
                        }
                    );
                }

                this.map.add(baseLayer);
                if (this.props.region && this.props.region.indexOf('2d') === -1 && navigator.platform.indexOf('Linux') === -1) {
                    this.map.add(maskBoundary);
                }

                // const CustomLayerView2D = BaseLayerViewGL2D.createSubclass({
                //     // Locations of the two vertex attributes that we use. They
                //     // will be bound to the shader program before linking.
                //     aPosition: 0,
                //     aOffset: 1,

                //     constructor: function () {
                //         // Geometrical transformations that must be recomputed
                //         // from scratch at every frame.
                //         this.transform = mat3.create();
                //         this.translationToCenter = vec2.create();
                //         this.screenTranslation = vec2.create();

                //         // Geometrical transformations whose only a few elements
                //         // must be updated per frame. Those elements are marked
                //         // with NaN.
                //         this.display = mat3.fromValues(NaN, 0, 0, 0, NaN, 0, -1, 1, 1);
                //         this.screenScaling = vec3.fromValues(NaN, NaN, 1);

                //         // Whether the vertex and index buffers need to be updated
                //         // due to a change in the layer data.
                //         this.needsUpdate = false;

                //         // We listen for changes to the graphics collection of the layer
                //         // and trigger the generation of new frames. A frame rendered while
                //         // `needsUpdate` is true may cause an update of the vertex and
                //         // index buffers.
                //         const requestUpdate = () => {
                //             this.needsUpdate = true;
                //             this.requestRender();
                //         };

                //         this.watcher = watchUtils.on(
                //             this,
                //             "layer.graphics",
                //             "change",
                //             requestUpdate,
                //             requestUpdate,
                //             requestUpdate
                //         );
                //     },

                //     // Called once a custom layer is added to the map.layers collection and this layer view is instantiated.
                //     attach: function () {
                //         const gl = this.context;

                //         // Define and compile shaders.
                //         const vertexSource = `
                //         precision highp float;
                //         uniform mat3 u_transform;
                //         uniform mat3 u_display;
                //         attribute vec2 a_position;
                //         attribute vec2 a_offset;
                //         varying vec2 v_offset;
                //         const float SIZE = 80.0;
                //         void main(void) {
                //             gl_Position.xy = (u_display * (u_transform * vec3(a_position, 1.0) + vec3(a_offset * SIZE, 0.0))).xy;
                //             gl_Position.zw = vec2(0.0, 1.0);
                //             v_offset = a_offset;
                //         }`;

                //         // red
                //         // const vec3 COLOR = vec3(1.0, 0.0, 0.0);
                //         const fragmentSource = `
                //         precision highp float;
                //         uniform float u_current_time;
                //         varying vec2 v_offset;
                //         const float PI = 3.14159;
                //         const float N_RINGS = 0.5;
                //         const vec3 COLOR = vec3(0.18823529411764706, 0.6588235294117647, 0.3568627450980392);
                //         const float FREQ = 0.5;
                //         void main(void) {
                //             float l = length(v_offset);
                //             float intensity = clamp(cos(l * PI), 0.0, 1.0) * clamp(cos(2.0 * PI * (l * 2.0 * N_RINGS - FREQ * u_current_time)), 0.0, 1.0);
                //             gl_FragColor = vec4(COLOR * intensity, intensity);
                //         }`;

                //         const vertexShader = gl.createShader(gl.VERTEX_SHADER);
                //         gl.shaderSource(vertexShader, vertexSource);
                //         gl.compileShader(vertexShader);
                //         const fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
                //         gl.shaderSource(fragmentShader, fragmentSource);
                //         gl.compileShader(fragmentShader);

                //         // Create the shader program.
                //         this.program = gl.createProgram();
                //         gl.attachShader(this.program, vertexShader);
                //         gl.attachShader(this.program, fragmentShader);

                //         // Bind attributes.
                //         gl.bindAttribLocation(this.program, this.aPosition, "a_position");
                //         gl.bindAttribLocation(this.program, this.aOffset, "a_offset");

                //         // Link.
                //         gl.linkProgram(this.program);

                //         // Shader objects are not needed anymore.
                //         gl.deleteShader(vertexShader);
                //         gl.deleteShader(fragmentShader);

                //         // Retrieve uniform locations once and for all.
                //         this.uTransform = gl.getUniformLocation(
                //             this.program,
                //             "u_transform"
                //         );
                //         this.uDisplay = gl.getUniformLocation(this.program, "u_display");
                //         this.uCurrentTime = gl.getUniformLocation(
                //             this.program,
                //             "u_current_time"
                //         );

                //         // Create the vertex and index buffer. They are initially empty. We need to track the
                //         // size of the index buffer because we use indexed drawing.
                //         this.vertexBuffer = gl.createBuffer();
                //         this.indexBuffer = gl.createBuffer();

                //         // Number of indices in the index buffer.
                //         this.indexBufferSize = 0;

                //         // When certain conditions occur, we update the buffers and re-compute and re-encode
                //         // all the attributes. When buffer update occurs, we also take note of the current center
                //         // of the view state, and we reset a vector called `translationToCenter` to [0, 0], meaning that the
                //         // current center is the same as it was when the attributes were recomputed.
                //         this.centerAtLastUpdate = vec2.fromValues(
                //             this.view.state.center[0],
                //             this.view.state.center[1]
                //         );
                //     },

                //     // Called once a custom layer is removed from the map.layers collection and this layer view is destroyed.
                //     detach: function () {
                //         // Stop watching the `layer.graphics` collection.
                //         this.watcher.remove();

                //         const gl = this.context;

                //         // Delete buffers and programs.
                //         gl.deleteBuffer(this.vertexBuffer);
                //         gl.deleteBuffer(this.indexBuffer);
                //         gl.deleteProgram(this.program);
                //     },

                //     // Called every time a frame is rendered.
                //     render: function (renderParameters) {
                //         const gl = renderParameters.context;
                //         const state = renderParameters.state;

                //         // Update vertex positions. This may trigger an update of
                //         // the vertex coordinates contained in the vertex buffer.
                //         // There are three kinds of updates:
                //         //  - Modification of the layer.graphics collection ==> Buffer update
                //         //  - The view state becomes non-stationary ==> Only view update, no buffer update
                //         //  - The view state becomes stationary ==> Buffer update
                //         this.updatePositions(renderParameters);

                //         // If there is nothing to render we return.
                //         if (this.indexBufferSize === 0) {
                //             return;
                //         }

                //         // Update view `transform` matrix; it converts from map units to pixels.
                //         mat3.identity(this.transform);
                //         this.screenTranslation[0] = (state.pixelRatio * state.size[0]) / 2;
                //         this.screenTranslation[1] = (state.pixelRatio * state.size[1]) / 2;
                //         mat3.translate(
                //             this.transform,
                //             this.transform,
                //             this.screenTranslation
                //         );
                //         mat3.rotate(
                //             this.transform,
                //             this.transform,
                //             (Math.PI * state.rotation) / 180
                //         );
                //         this.screenScaling[0] = state.pixelRatio / state.resolution;
                //         this.screenScaling[1] = -state.pixelRatio / state.resolution;
                //         mat3.scale(this.transform, this.transform, this.screenScaling);
                //         mat3.translate(
                //             this.transform,
                //             this.transform,
                //             this.translationToCenter
                //         );

                //         // Update view `display` matrix; it converts from pixels to normalized device coordinates.
                //         this.display[0] = 2 / (state.pixelRatio * state.size[0]);
                //         this.display[4] = -2 / (state.pixelRatio * state.size[1]);

                //         // Draw.
                //         gl.useProgram(this.program);
                //         gl.uniformMatrix3fv(this.uTransform, false, this.transform);
                //         gl.uniformMatrix3fv(this.uDisplay, false, this.display);
                //         gl.uniform1f(this.uCurrentTime, performance.now() / 1000.0);
                //         gl.bindBuffer(gl.ARRAY_BUFFER, this.vertexBuffer);
                //         gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer);
                //         gl.enableVertexAttribArray(this.aPosition);
                //         gl.enableVertexAttribArray(this.aOffset);
                //         gl.vertexAttribPointer(this.aPosition, 2, gl.FLOAT, false, 16, 0);
                //         gl.vertexAttribPointer(this.aOffset, 2, gl.FLOAT, false, 16, 8);
                //         gl.enable(gl.BLEND);
                //         gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
                //         gl.drawElements(
                //             gl.TRIANGLES,
                //             this.indexBufferSize,
                //             gl.UNSIGNED_SHORT,
                //             0
                //         );

                //         // Request new render because markers are animated.
                //         this.requestRender();
                //     },

                //     // Called by the map view or the popup view when hit testing is required.
                //     hitTest: function (x, y) {
                //         // The map view.
                //         const view = this.view;

                //         if (this.layer.graphics.length === 0) {
                //             // Nothing to do.
                //             return promiseUtils.resolve(null);
                //         }

                //         // Compute screen distance between each graphic and the test point.
                //         const distances = this.layer.graphics.map((graphic) => {
                //             const graphicPoint = view.toScreen(graphic.geometry);
                //             return Math.sqrt(
                //                 (graphicPoint.x - x) * (graphicPoint.x - x) +
                //                 (graphicPoint.y - y) * (graphicPoint.y - y)
                //             );
                //         });

                //         // Find the minimum distance.
                //         let minIndex = 0;

                //         distances.forEach((distance, i) => {
                //             if (distance < distances.getItemAt(minIndex)) {
                //                 minIndex = i;
                //             }
                //         });

                //         const minDistance = distances.getItemAt(minIndex);

                //         // If the minimum distance is more than 35 pixel then nothing was hit.
                //         if (minDistance > 35) {
                //             return promiseUtils.resolve(null);
                //         }

                //         // Otherwise it is a hit; We set the layer as the source layer for the graphic
                //         // (required for the popup view to work) and we return a resolving promise to
                //         // the graphic.
                //         const graphic = this.layer.graphics.getItemAt(minIndex);
                //         graphic.sourceLayer = this.layer;
                //         return promiseUtils.resolve(graphic);
                //     },

                //     // Called internally from render().
                //     updatePositions: function (renderParameters) {
                //         const gl = renderParameters.context;
                //         const stationary = renderParameters.stationary;
                //         const state = renderParameters.state;

                //         // If we are not stationary we simply update the `translationToCenter` vector.
                //         if (!stationary) {
                //             vec2.sub(
                //                 this.translationToCenter,
                //                 this.centerAtLastUpdate,
                //                 state.center
                //             );
                //             this.requestRender();
                //             return;
                //         }

                //         // If we are stationary, the `layer.graphics` collection has not changed, and
                //         // we are centered on the `centerAtLastUpdate`, we do nothing.
                //         if (
                //             !this.needsUpdate &&
                //             this.translationToCenter[0] === 0 &&
                //             this.translationToCenter[1] === 0
                //         ) {
                //             return;
                //         }

                //         // Otherwise, we record the new encoded center, which imply a reset of the `translationToCenter` vector,
                //         // we record the update time, and we proceed to update the buffers.
                //         this.centerAtLastUpdate.set(state.center);
                //         this.translationToCenter[0] = 0;
                //         this.translationToCenter[1] = 0;
                //         this.needsUpdate = false;

                //         const graphics = this.layer.graphics;

                //         // Generate vertex data.
                //         gl.bindBuffer(gl.ARRAY_BUFFER, this.vertexBuffer);
                //         const vertexData = new Float32Array(16 * graphics.length);

                //         let i = 0;
                //         graphics.forEach((graphic) => {
                //             const point = graphic.geometry;

                //             // The (x, y) position is relative to the encoded center.
                //             const x = point.x - this.centerAtLastUpdate[0];
                //             const y = point.y - this.centerAtLastUpdate[1];

                //             vertexData[i * 16 + 0] = x;
                //             vertexData[i * 16 + 1] = y;
                //             vertexData[i * 16 + 2] = -0.5;
                //             vertexData[i * 16 + 3] = -0.5;
                //             vertexData[i * 16 + 4] = x;
                //             vertexData[i * 16 + 5] = y;
                //             vertexData[i * 16 + 6] = 0.5;
                //             vertexData[i * 16 + 7] = -0.5;
                //             vertexData[i * 16 + 8] = x;
                //             vertexData[i * 16 + 9] = y;
                //             vertexData[i * 16 + 10] = -0.5;
                //             vertexData[i * 16 + 11] = 0.5;
                //             vertexData[i * 16 + 12] = x;
                //             vertexData[i * 16 + 13] = y;
                //             vertexData[i * 16 + 14] = 0.5;
                //             vertexData[i * 16 + 15] = 0.5;

                //             ++i;
                //         });

                //         gl.bufferData(gl.ARRAY_BUFFER, vertexData, gl.STATIC_DRAW);

                //         // Generates index data.
                //         gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer);

                //         let indexData = new Uint16Array(6 * graphics.length);
                //         for (let i = 0; i < graphics.length; ++i) {
                //             indexData[i * 6 + 0] = i * 4 + 0;
                //             indexData[i * 6 + 1] = i * 4 + 1;
                //             indexData[i * 6 + 2] = i * 4 + 2;
                //             indexData[i * 6 + 3] = i * 4 + 1;
                //             indexData[i * 6 + 4] = i * 4 + 3;
                //             indexData[i * 6 + 5] = i * 4 + 2;
                //         }

                //         gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indexData, gl.STATIC_DRAW);

                //         // Record number of indices.
                //         this.indexBufferSize = indexData.length;
                //     }
                // });

                // this.CustomLayer = GraphicsLayer.createSubclass({
                //     createLayerView: function (view) {
                //         // We only support MapView, so we only need to return a
                //         // custom layer view for the `2d` case.
                //         if (view.type === '2d') {
                //             return new CustomLayerView2D({
                //                 view: view,
                //                 layer: this
                //             });
                //         }
                //     }
                // });

                this.threeCameras = undefined;
                this.threeCamerasInfo = {
                    view: this.view,
                    layerUrl: 'http://10.89.5.191/OneMapServer/rest/services/Hosted_linkongQXMX/SceneServer/layers/0',
                    featureIDArray: [],
                    externalRenderer: externalRenderers,
                    ifAddAllNode: false,
                    ifAddGround: true,
                    groundCircleRadius: 100,
                    addGroundHeight: 19.8,
                    token: document.getElementById('txtToken').value
                };
                this.videoPlatformHeaders = {
                    'Content-Type': 'application/json',
                    'Authorization': 'eyJhbGciOiJIUzI1NiJ9.eyJ1c2VySWQiOiJTWkxTIiwidXNlck5hbWUiOiLmlbDlrZflrarnlJ8iLCJvcmdJZCI6IumZhuadsCIsIm9yZ05hbWUiOiIxODIyMTE5MzUyOSIsImNyZWF0ZVRpbWUiOjE2Mzg1MTA4NjcwMDEsImV4cCI6NDEwMjQxNjAwMDAwMH0.dZiDmXrYMDcnMBTxHDx7Z0aJWNS-y3Xjxg1qixgnyuQ',
                    'person-id': '330482199309222714'
                };
                this.videoPlatformParams = {
                    // 'deviceId': '31010522051321001004',
                    'protocol': 'http-flv',
                    'resolution': 'UHD'
                };

                this.watchViewCreated(this.view, watchUtils, domClass);
            });
    }

    componentWillUnmount() {
        console.log('destory');

        try {
            this.featureLayers = {};
            this.newFatureLayers = {}
            this.newTmpData = {};

            if (this.agentClient) {
                try {
                    this.agentClient.stop();
                } catch (e) {
                    console.error(e);
                }
            }
            if (this.agentTimer) {
                clearInterval(this.agentTimer);
            }
            if (this.popTimer) {
                clearInterval(this.popTimer);
            }
            if (this.map && this.map.layers) {
                const { items = [] } = this.map.layers;

                if (items) {
                    items.forEach(item => {
                        if (typeof item.destroy === 'function') {
                            item.destroy();
                        }
                    })
                }
            }
            if (this.view) {
                if (typeof this.view.destroy === 'function') {
                    this.view.destroy()
                }
            }
        } catch (e) {
            console.error('destory error：', e)
        }
    }

    watchViewCreated(view, watchUtils, domClass) {
        if (view) {
            // this.map.allLayers.on('change', function (event) {
            //     console.log('Layer added: ', event.added);
            //     console.log('Layer removed: ', event.removed);
            //     console.log('Layer moved: ', event.moved);
            // });
            const { region } = this.props;
            const { type } = view;

            view.when(() => {
                console.log(`view${type} create success.`);
                if (type === '2d') {

                } else {
                    view.qualitySettings.memoryLimit = 4096;
                }

                this.onResize();
                if (type === '2d' && region !== '新泾镇-河湖管理2d') {
                    view.goTo({
                        center: REGION_CONFIG[region].center
                    });
                } else {
                    this.resetCamera(view, 3000);
                }

                domClass.add(view.popup.domNode, 'custom_popup_wrapper');
                // this.popTimer = setInterval(() => {
                //     const popUpShow = document.getElementsByClassName('popup_dom_wrapper');

                //     if (popUpShow && popUpShow.length === 0) {
                //         if (typeof this.props.postClick === 'function') {
                //             this.props.postClick({ sbbh: undefined });
                //         }
                //     }
                // }, 2000);
                // view.popup.autoOpenEnabled = false;
                view.ui.components = [];

                watchUtils.whenTrue(view, 'stationary', () => {
                    const { center = {}, camera = {}, zoom, scale } = view;
                    console.log(
                        `view${type} data：`,
                        { longitude: center.longitude, latitude: center.latitude },
                        { x: center.x, y: center.y }, scale, zoom, { heading: camera.heading, tilt: camera.tilt }
                    );
                    this.x = center.x;
                    this.y = center.y;

                    if (this.newFatureLayers['road']) {
                        const roads = this.newFatureLayers['road'];
                        try {
                            if (roads) {
                                roads.forEach(item => {
                                    if (item.layer) {
                                        item.layer.visible = item.visible[0] <= (view.zoom || (REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM)) && (view.zoom || (REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM)) < item.visible[1];
                                    }
                                })
                            }
                        } catch (e) {
                            console.error(e)
                        }
                    }
                    console.log('road', this.road);
                    if (view.zoom < (this.road && this.road !== 'all' ? ROAD_CENTER[this.road].zoom : (REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM)) - (REGION_CONFIG[region] ? REGION_CONFIG[region].zoom_space : ZOOM_SPACE)) {
                        view.zoom = this.road && this.road !== 'all' ? ROAD_CENTER[this.road].zoom : (REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM);
                        if (type === '2d' && region !== '新泾镇-河湖管理2d') {
                            view.goTo({
                                center: REGION_CONFIG[region].center,
                                zoom: REGION_CONFIG[region].max_zoom
                            });
                        } else {
                            view.goTo(
                                new this.ArcGisPoint({
                                    x: this.road && this.road !== 'all' ? ROAD_CENTER[this.road].center[0] : (REGION_CONFIG[region] ? REGION_CONFIG[region].center : CENTER)[0],
                                    y: this.road && this.road !== 'all' ? ROAD_CENTER[this.road].center[1] : (REGION_CONFIG[region] ? REGION_CONFIG[region].center : CENTER)[1],
                                    spatialReference: this.spatialReferencevalue,
                                })
                            );
                        }
                    }
                });

                // this.map.on('zoom-start', (e) => {
                //     console.info('zoom-start', e.delta.x, e.delta.y);
                // });

                view.on('resize', (e) => {
                    console.log(`view${type} resize`);
                    this.onResize();
                });

                view.on('click', (event) => {
                    if (DEVELOPING) {
                        console.log('click resize before:', this.viewsize, event.x, event.y);
                        event.x *= this.viewsize.width;
                        event.y *= this.viewsize.height;
                        console.log('click resize after:', this.viewsize, event.x, event.y);
                    }
                    view.hitTest(event).then((result) => {
                        console.log(`view${type} click data：`, result);
                        const { results = [], screenPoint = {} } = result;
                        const point = results[0] || {};
                        const { graphic = {}, mapPoint = {} } = point;
                        const { attributes } = graphic || {};

                        if (!attributes || !attributes.pinType) {
                            console.log('invailed point', attributes, `[${mapPoint.x}, ${mapPoint.y}]`);
                            view.popup.visible = false;
                        } else if (
                            attributes.popup === 'click2' ||
                            attributes.popup === 'click3' ||
                            attributes.popup === 'click4'
                        ) {
                            console.log('vailed point', attributes, mapPoint);
                            view.popup.fillSymbol = false;
                            view.popup.titleInBody = false;
                            view.popup.autoOpenEnabled = false;

                            // if (typeof this.props.postClick === 'function') {
                            //     this.props.postClick(attributes);
                            // }
                            const { X, Y, pinType } = attributes;
                            const list = [];

                            // if (this.props.region.indexOf('民政') !== -1) {
                            if (this.featureLayers[pinType] && this.featureLayers[pinType].createQuery) {
                                const query = this.featureLayers[pinType].createQuery();
                                query.outFields = ['*'];
                                query.returnGeometry = true;
                                query.where = `X='${X}' and Y='${Y}'`;

                                this.featureLayers[pinType].queryFeatures(query).then(res => {
                                    const { features = [] } = res;

                                    features.forEach(item => {
                                        const { attributes = {}, geometry } = item || {};
                                        list.push(attributes);
                                    });

                                    if (list && list.length > 0) {
                                        this.arcgisPopup(list, mapPoint, view);
                                    }
                                });
                            } else if (this.featureLayers[pinType] && this.featureLayers[pinType].graphics) {
                                const { items = [] } = this.featureLayers[pinType].graphics;

                                if (items) {
                                    items.forEach(item => {
                                        const { attributes: attr = {} } = item;

                                        if (attr && attr.X === X && attr.Y === Y) {
                                            list.push(attributes);
                                        }
                                    });

                                    if (list && list.length > 0) {
                                        this.arcgisPopup(list, mapPoint, view);
                                    }
                                }
                            } else {
                                this.arcgisPopup(attributes, mapPoint, view);
                            }
                            // } else {
                            //     this.arcgisPopup(attributes, mapPoint, view);
                            // }
                        } else if (attributes.popup === 'postVis') {
                            if (typeof this.props.postClick === 'function') {
                                this.props.postClick(attributes);
                            }
                        } else if (attributes.popup === 'video') {
                            this.videoFusion(attributes);
                        }
                    });
                });
                view.on('pointer-move', (event) => {
                    if (DEVELOPING) {
                        event.x *= this.viewsize.width;
                        event.y *= this.viewsize.height;
                    }
                    view.hitTest(event).then((result) => {
                        const { results = [], screenPoint = {} } = result;
                        const point = results[0] || {};
                        const { graphic = {}, mapPoint = {} } = point;
                        const { attributes } = graphic || {};

                        if (attributes && attributes.popup === 'hover') {
                            // console.log('vailed point', attributes, mapPoint);
                            // view.popup.fillSymbol = false;
                            // view.popup.titleInBody = false;
                            // view.popup.autoOpenEnabled = false;

                            // this.arcgisPopup(attributes, mapPoint, view);
                        } if (attributes && (
                            attributes.popup === 'click2' ||
                            attributes.popup === 'click3' ||
                            attributes.popup === 'click4'
                        )) {
                            view.popup.autoOpenEnabled = false;
                        } else {
                            view.popup.autoOpenEnabled = true;
                        }
                    });
                });

                this.setState({ mapReady: true }, () => {
                    if (this.props.region && this.props.region.indexOf('2d') !== -1) {
                        this.changeCenter('all', this.props.region);
                    }
                });
            });
        }
    }

    arcgisPopup(data, location, view) {
        let dom = document.createElement('div');
        dom.style = 'height: 100%';
        const popup = Array.isArray(data) ? data[0].popup : data.popup;
        console.info('arcgisPopup', data);
        try {
            switch (popup) {
                case 'click4':
                    dom = popImage(dom, Array.isArray(data) ? data[0] : data, this.agentClient, this.makeCall.bind(this), this.hangupCall.bind(this), this.props.postClick);
                    break;
                case 'click3':
                    dom = wjPopUp(dom, Array.isArray(data) ? data[0] : data, this.callback.bind(this));
                    break;
                // case 'click2':
                //     dom = popSchool(dom, data);
                //     break;
                default:
                    dom = popDefault(dom, data, this.agentClient, this.makeCall.bind(this), this.hangupCall.bind(this), this.props.postClick, this, this.videoFusion.bind(this));
                    break;
            }
            view.popup.open({
                location,
                content: dom,
            });
        } catch (e) {
            console.log('popup error:', e);
        }
    }

    callback(num) {
        this.view.goTo(
            new this.ArcGisPoint({
                x: this.x + num,
                y: this.y + num,
                spatialReference: this.spatialReferencevalue,
            })
        );
    }

    resetCamera(view, t = 1000) {
        const { region = '长宁' } = this.props;

        this.endRotate();
        (view ? view : this.view)
            .goTo(
                {
                    // tilt: 0,
                    position: new this.ArcGisPoint({
                        x: (REGION_CONFIG[region] ? REGION_CONFIG[region].center : CENTER)[0],
                        y: (REGION_CONFIG[region] ? REGION_CONFIG[region].center : CENTER)[1],
                        spatialReference: this.spatialReferencevalue,
                    }),
                    // zoom: REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM,
                },
                { duration: t }
            )
            .then(() => {
                if (REGION_CONFIG[region].camera) {
                    (view ? view : this.view).goTo({ ...REGION_CONFIG[region].camera, zoom: REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM }, { duration: t });
                } else {
                    (view ? view : this.view).goTo({ heading: 0, tilt: 0.4999999999962178, zoom: REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM }, { duration: t });
                }
            });
    }

    setCamera(config, t = 1000) {
        const { region = '长宁' } = this.props;

        this.view.goTo(
            {
                position: new this.ArcGisPoint({
                    x: config.center[0],
                    y: config.center[1],
                    spatialReference: this.spatialReferencevalue,
                }),
            },
            { duration: t }
        )
            .then(() => {
                if (config.camera) {
                    this.view.goTo({ ...config.camera, zoom: config.max_zoom }, { duration: t });
                } else if (config.max_zoom) {
                    this.view.goTo({ zoom: config.max_zoom }, { duration: t });
                } else {
                    if (REGION_CONFIG[region].camera) {
                        this.view.goTo({ ...REGION_CONFIG[region].camera, zoom: REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM }, { duration: t });
                    } else {
                        this.view.goTo({ heading: 0, tilt: 0.4999999999962178, zoom: REGION_CONFIG[region] ? REGION_CONFIG[region].max_zoom : MAX_ZOOM }, { duration: t });
                    }
                }
            });
    }

    endRotate() {
        console.log('endRotate');
        clearInterval(this.rotationInterval);
        clearTimeout(this.rotationTimeout);
        this.rotationTimeout = 0;
        this.rotationInterval = 0;
    }

    onResize() {
        const container = document.getElementById('arcgisContainer');
        const { height, width } = container.getBoundingClientRect();
        const viewWidth = this.props.data[0],
            viewHeight = this.props.data[1];
        this.viewsize = { height: viewHeight / height, width: viewWidth / width };
        console.log('onResize data：', this.viewsize, viewWidth, viewHeight);
    }

    render() {
        // const { active, popup, postClick, data, datas, layersData, mapCenter, zrwg, ...extra } = this.props;

        return (
            <Fragment>
                <video id='videoElement_n1' muted loop='loop' hidden></video>
                <div
                    id='arcgisContainer'
                    style={{ width: '100%', height: '100%', margin: 0, padding: 0 }}
                // {...extra}
                >
                    <div id='printContainer' className='panel panel-default' style={{ display: 'none' }}><pre></pre></div>
                    <input id='status' ref={this.statusRef} style={{ display: 'none' }} />
                </div>
            </Fragment>
        );
    }
}