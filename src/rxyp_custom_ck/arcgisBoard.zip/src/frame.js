import React, { Component } from "react";
import Arcgis from "./page";

export default class Frame extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      popupInfo: null,
    };
    this.frame = null;
  }

  componentDidMount() {
    
  }

  componentDidUpdate() { }

  render() {
    let { data } = this.props;
    let zrwg = [];
    let callCfg = undefined;
    if (Array.isArray(data) && data[3] && data[3].agentId) {
      callCfg = { ...data[3] };
    }
    if (Array.isArray(data) && data[4]) {
      zrwg = [...data].splice(4);
    }
    return <Arcgis data={data} region={data[2]} callCfg={callCfg} zrwg={zrwg} {...this.props}></Arcgis>;
  }
}
