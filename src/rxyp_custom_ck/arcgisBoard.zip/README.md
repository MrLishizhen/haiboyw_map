# arcgisMap 组件撒点与通信指南

## 使用预制自定义组件

现有单选辅助组件`cn_point_checker`与树形图辅助组件`cn_point_poster`

fx 格式为`#array(params,@数据集://1:1-n:n;)`

配置后须加载在页面上

### params

```javascript
{
  pinType: string,
  popup: string/undefined,
  graphicType: string,
  messageType: push/clear,
  icon?: url,
  iconGreen?: url,
  iconRed?: url;
  exclude?: array,
  default:true/false,
  pointName?:string,
  levels?: string,
}
```

pinType

- 数据类型标识(全局唯一，相同 pinType 的消息将默认覆盖旧数据)

popup 弹窗类型:

- 撒点后的事件处理 组件固定弹窗 `popup` 浮窗 `hover` 点击浮窗 `click` visApp 事件 `postVis`

graphicType 撒点类型:

- 大量固定点`featurelayer` 动态点`graphic` 底图`tile`

messageType 消息类型:

- 叠加型 `push` 覆盖型 `clear`

icon 图标地址:

- undefined 则显示文字

iconRed/iconGreen:

- 依赖条件的图标，根据传入数据集内单个点的心跳 `sbztms` 和告警 `gjjlbh`

exclued 互斥数据:

- 互斥数据的 `pinType` 数组

pointName 设备指标名称

- 在弹窗中 `sbzb` 字段显示的名称

levels 依赖数值条件状态显示:

- 以数据集内字段 `sbzb` 判断状态，现支持使用两个数三个值域区分状态，格式为 JSONString eg:`'[60,80]'`

default 默认值:

- true false

### 数据集内字段格式

每一条数据都会与 params 合并传入 arcgis 撒点备用
X: x 坐标
Y: y 坐标
sbztms/gjjlbh?: 心跳数据专用，用于区分状态
sbzb?: 指标数据专用，用于区分状态
sz`x`?: 数据点的其他指标值，`x`从 1 开始累计,当`szx` 或 `szmsx` 为空时将丢弃`x`以后的指标
szms`x`?: 数据点其他指标名称与`szx`一一对应

### 撒点信息 postMessage 格式

亦可以直接通过`window.postMessage()`方法向地图撒点

```javascript
  {
    type: "SHOWNSTATE",
    flag: "GRIDFLAG",
    params
    points: []/undefined
    state: true/false
  }
```

### 点击撒点后 postMessage 格式

当`param.popup`为`popup`时，点击撒点图形将 postMessage
可以在其他组件通过`window.addEventListener("message",function)`解析

消息格式:

```javascript
  {
    type: "PICKPOINT",
    flag: "GRIDFLAG",
    data: {...}
  }
```

data: 信息可能包含字段(不存在则 undefined): sbbh,name,type,address,pinType,state,sbzt,sbztms,bjlx,bjlxhz,bjsj,ID

### 镜头焦点消息 postMessage 格式

```javascript
  {
    type: "CAMERAFOCUSE",
    flag: "GRIDFLAG",
    data:{
      X:number/undefined, //焦点X坐标
      Y:number/undefined, //焦点Y坐标
      zoom:number/undefined, //镜头高度，默认为10
      tile:number/undefined, //镜头角度
    }
  }
```

### 镜头旋转启停 postMessage 格式

```javascript
  {
    type: "CAMERAROTATE",
    flag: "GRIDFLAG",
    data: boolean, //打开/关闭
  }
```

### 例子:

```json
(params = {
  "pinType": "jishuidianwei",
  "popup": "hover",
  "graphicType": "graphic",
  "messageType": "clear",
  "icon": "/fastdfs/group1/M00/00/16/wKgJx18iqfaAA0rBAAAFVudkWu8232.png",
  "iconGreen": "/fastdfs/group1/M00/00/16/wKgJx18iqzKATuO_AAAHUovrJ2A733.png",
  "iconRed": "/fastdfs/group1/M00/00/16/wKgJx18iqtWAf9NXAAAHRzn16Ug970.png",
  "default": false
})
```

#### fx 填入:

```javascript
#array({ "pinType": "qiyeweixingxiaofangzhan", "popup": "popup", "graphicType": "feature", "messageType": "clear", "icon": "/fastdfs/group1/M00/00/16/wKgJx18iq1qAIulAAAAE2-4rFGU256.png", default:false },@xf_xiaofangzhansadian_1://1:1-n:n;)
```

## 附录

### 现存图标

| 鏈接                                                         | 圖標            |
| ------------------------------------------------------------ | --------------- |
| /fastdfs/group1/M00/00/16/wKgJx18iqfaAA0rBAAAFVudkWu8232.png | white pin       |
| /fastdfs/group1/M00/00/16/wKgJx18iqtWAf9NXAAAHRzn16Ug970.png | red pin         |
| /fastdfs/group1/M00/00/16/wKgJx18iqvqADpDJAAAHTP_mbT8614.png | purple pin      |
| /fastdfs/group1/M00/00/16/wKgJx18iqxCAZEv-AAAE286E78c632.png | pink pin        |
| /fastdfs/group1/M00/00/16/wKgJx18iqyOAMpgWAAAE2_fXb3E337.png | orange pin      |
| /fastdfs/group1/M00/00/16/wKgJx18iqzKATuO_AAAHUovrJ2A733.png | green pin       |
| /fastdfs/group1/M00/00/16/wKgJx18iq0KAR0IbAAAE25SOeAI347.png | grass pin       |
| /fastdfs/group1/M00/00/16/wKgJx18iq1qAIulAAAAE2-4rFGU256.png | brown pin       |
| /fastdfs/group1/M00/00/16/wKgJx18iq5-ASjQ6AAAHRSwO5dc584.png | alice pin       |
| /fastdfs/group1/M00/00/16/wKgJx18iq7WAOLclAAAHSpStIHc914.png | blue pin        |
| /fastdfs/group1/M00/00/16/wKgJx18iq9-AUuqOAAAK1ggxDzQ669.png | red halo        |
| /fastdfs/group1/M00/00/16/wKgJx18iq_GATiX9AAAK5VUriJ8188.png | orange halo     |
| /fastdfs/group1/M00/00/16/wKgJx18iq4KAVR4vAAAK9M96SHE549.png | yellow halo     |
| /fastdfs/group1/M00/00/16/wKgJx18irBWAWbDVAAALgfingTw140.png | green halo      |
| /fastdfs/group1/M00/00/16/wKgJx18irGiACxzKAAAQ_My2Ves552.png | red alarm       |
| /fastdfs/group1/M00/00/16/wKgJx18irLuAGsNaAAAR_gYZcxo235.svg | camera icon     |
| /fastdfs/group1/M00/00/19/wKgJx18pENyAY3CTAAAFfa8ZRIc330.png | 出动车辆        |
| /fastdfs/group1/M00/00/19/wKgJx18pEP-AYN-LAAAFueDEsPA147.png | 地上消火栓      |
| /fastdfs/group1/M00/00/19/wKgJx18pERqAe_9fAAAFqHOiqYk479.png | 附近消防站      |
| /fastdfs/group1/M00/00/19/wKgJx18pES-AW48DAAAGxlzNPs8493.png | 积水            |
| /fastdfs/group1/M00/00/1A/wKgJx18pEj2ATsmPAAAF-KvBSME385.png | 积水 red        |
| /fastdfs/group1/M00/00/1A/wKgJx18pEiiAXVn6AAAH4mPMRjY269.png | 积水 gray       |
| /fastdfs/group1/M00/00/19/wKgJx18pEUmAAwFkAAAFoq4VxNc586.png | 企业微型        |
| /fastdfs/group1/M00/00/1A/wKgJx18pEVmAYjWCAAAFqbbremY643.png | 区消防救援      |
| /fastdfs/group1/M00/00/1A/wKgJx18pEW2AEKpSAAAFaAOEKFI116.png | 取水点          |
| /fastdfs/group1/M00/00/1A/wKgJx18pEYmAIGtbAAAFwIbkSgc521.png | 社区微型        |
| /fastdfs/group1/M00/00/1A/wKgJx18pEZSANfNaAAAFMwfjJz8805.png | 未联网          |
| /fastdfs/group1/M00/00/1A/wKgJx18pEaSAVvD7AAAHOWxClcM930.png | 物联网          |
| /fastdfs/group1/M00/00/1A/wKgJx18pHLeAVotoAAAGKAhYSuA706.png | 物联网 red      |
| /fastdfs/group1/M00/00/1A/wKgJx18pHMmAVl5QAAAIgU5lWWI735.png | 物联网 gray     |
| /fastdfs/group1/M00/00/1A/wKgJx18pEbGAT8_xAAAFm2lQe7Y891.png | 执勤车辆        |
| /fastdfs/group1/M00/00/1A/wKgJx18pEcSAPZ0MAAAFyoNo91U074.png | 智能车棚        |
| /fastdfs/group1/M00/00/1A/wKgJx18pEe-ARSNTAAAFXFspark763.png | 智能车棚 red    |
| /fastdfs/group1/M00/00/1A/wKgJx18pEgiAF0lHAAAHF-pndUc531.png | 智能车棚 gray   |
| /fastdfs/group1/M00/00/1A/wKgJx18pEduACacfAAAGE0OiqLA282.png | 智能消火栓      |
| /fastdfs/group1/M00/00/1A/wKgJx18pEoSALKmvAAAFW8qlOcI691.png | 智能消火栓 red  |
| /fastdfs/group1/M00/00/1A/wKgJx18pEp-AfBTDAAAHBsiNRRg740.png | 智能消火栓 gray |
| /fastdfs/group1/M00/00/1F/wKgJx182EKmAdiAkAAAFsmTsPqw351.png | 历史火警        |

### 地图图层

| 地址                                                                        | 图层           |
| --------------------------------------------------------------------------- | -------------- |
| http://10.207.204.19/server/rest/services/BIGANSE2/MapServer                | 暗色底图       |
| http://10.207.204.19/server/rest/services/AIRIMAGE2020/MapServer            | 卫星图         |
| http://10.207.204.19/server/rest/services/Hosted/County/FeatureServer       | 区界           |
| http://10.207.204.19/server/rest/services/Hosted/Street/FeatureServer       | 街道           |
| http://10.207.204.19/server/rest/services/Hosted/wangge/FeatureServer       | 网格           |
| http://10.207.204.19/server/rest/services/Hosted/juwei/FeatureServer        | 居委           |
| http://10.207.204.19/server/rest/services/Hosted/baimo/SceneServer          | 白模           |
| http://10.207.204.19/server/rest/services/Hosted/biaomo_jm_fcfh/SceneServer | 精模 1         |
| http://10.207.204.19/server/rest/services/Hosted/jingmo/SceneServer         | 精模 2         |
| http://10.207.204.19/server/rest/services/Hosted/fencengfenhu01/SceneServer | 精模 3         |
| http://10.207.204.19/server/rest/services/YLJG/MapServer                    | 医疗机构       |
| http://10.207.204.19/server/rest/services/SCHOOL/MapServer                  | 学校           |
| http://10.207.204.19/server/rest/services/LSWHBH/MapServer                  | 历史文化保护   |
| http://10.207.204.19/server/rest/services/BMSS/MapServer                    | 便民设施       |
| http://10.207.204.19/server/rest/services/LSWHFMQ/MapServer                 | 历史文化风貌区 |
| http://10.207.204.19/server/rest/services/FMBHJF/MapServer                  | 风貌保护街坊   |
| http://10.207.204.19/server/rest/services/FMBHDL/MapServer                  | 风貌保护道路   |
| http://10.207.204.19/server/rest/services/WWBHXX/MapServer                  | 文物保护信息   |
| http://10.207.204.19/server/rest/services/YXLSJZ/MapServer                  | 优秀历史建筑   |
| http://10.207.204.19/server/rest/services/WHCG/MapServer                    | 文化场馆       |
