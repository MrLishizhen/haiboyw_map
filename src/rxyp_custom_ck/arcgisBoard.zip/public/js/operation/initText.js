var AgentClient = function(option) {


   /* var url = '';
    var socketUrl = "";
    var global_workNo;
    var global_phonenum;*/
    var actionType = 0;
    var appointType = 0;
    var acwTimer = null;
    var isOnline = false;
    var agent = {
        agentId : '',
        agentDn : '',
        agentName : '',
        agentType : 1,
        skillDesc : '',
        tenantDesc : '',
        acdAgentId : '',
        acdAgentGroup : '',
        acdAgentPassword : '',
        camponFlag: 0,
        status: 0,
        agentIp: '',
        phoneIp: '',
        loginId: '',
        loginTime: '',
        logoutTime: '',
        sessionId: '',
        isLogin: false
    };

    var config = {
        proxyUrl : '',	// 代理服务地址
        socketUrl : '',
        answerUrl : '',	// 话机应答地址
        hangupUrl : '',	// 话机挂机地址
        autoLogin : true,	// 是否自动签入
        forceLogin : true,	// 是否强制签入
        autoAnswer : false,	// 是否自动应答
        autoReady : 1,	// 自动空闲, 1:事后整理(默认), 2:自动空闲, 3:自动忙碌
        acwTime : 0,	// 事后整理时长(毫秒)
        answerTime : 2000,	// 自动应答延时(毫秒)
        transferFlag : 1,	// 转接标志, 1:通话转(默认), 2:振铃转
        dialPrefix : '0',	// 外呼前缀
        dialCaller : '',	// 外呼主叫号码
        ivrDn : '6000',	// IVR号码
        debug : false	// 启用调试
    };
    setOption(option);

    function getOption(field) {
        if (field == undefined) {
            return {
                agentId : agent.agentId,
                agentDn : agent.agentDn,
                agentName : agent.agentName,
                agentType : agent.agentType,
                skillDesc : agent.skillDesc,
                tenantDesc : agent.tenantDesc,
                acdAgentId : agent.acdAgentId,
                acdAgentGroup : agent.acdAgentGroup,
                acdAgentPassword : agent.acdAgentPassword,
                camponFlag: agent.camponFlag,
                status: agent.status,
                agentIp: agent.agentIp,
                phoneIp: agent.phoneIp,
                sessionId : agent.sessionId,
                isLogin : agent.isLogin,
                proxyUrl : config.proxyUrl,
                answerUrl : config.answerUrl,
                hangupUrl : config.hangupUrl,
                autoLogin : config.autoLogin,
                forceLogin : config.forceLogin,
                autoAnswer : config.autoAnswer,
                autoReady : config.autoReady,
                acwTime : config.acwTime,
                answerTime : config.answerTime,
                transferFlag : config.transferFlag,
                dialPrefix : config.dialPrefix,
                dialCaller : config.dialCaller,
                ivrDn : config.ivrDn,
                debug : config.debug
            };
        } else {
            var value = agent[field];

            if (value == undefined) {
                value = config[field];
            }

            return value;
        }
    }

    function setOption(option) {

        option = option || {};

        if (!agent.isLogin) {
            if (option.hasOwnProperty('agentId')) {
                agent.agentId = (option.agentId || '') + '';
            }

            if (option.hasOwnProperty('agentDn')) {
                agent.agentDn = (option.agentDn || '') + '';
            }

            if (option.hasOwnProperty('agentName')) {
                agent.agentName = (option.agentName || '') + '';
            }

            if (option.hasOwnProperty('agentType')) {
                agent.agentType = option.agentType;
            }

            if (option.hasOwnProperty('skillDesc')) {
                agent.skillDesc = (option.skillDesc || '') + '';
            }

            if (option.hasOwnProperty('tenantDesc')) {
                agent.tenantDesc = (option.tenantDesc || '') + '';
            }

            if (option.hasOwnProperty('acdAgentId')) {
                agent.acdAgentId = (option.acdAgentId || '') + '';
            }

            if (option.hasOwnProperty('acdAgentGroup')) {
                agent.acdAgentGroup = (option.acdAgentGroup || '') + '';
            }

            if (option.hasOwnProperty('acdAgentPassword')) {
                agent.acdAgentPassword = (option.acdAgentPassword || '') + '';
            }

            if (option.hasOwnProperty('camponFlag')) {
                agent.camponFlag = option.camponFlag;
            }

            if (option.hasOwnProperty('sessionId')) {
                agent.sessionId = (option.sessionId || '') + '';
            }

            if (!agent.sessionId) {
                agent.sessionId = getCookie('sid-' + agent.agentId);
            }
        }

        if (option.hasOwnProperty('proxyUrl')) {
            config.proxyUrl = (option.proxyUrl || '') + '';
        }

        if (option.hasOwnProperty('socketUrl')) {
            config.socketUrl = (option.socketUrl || '') + '';
        }

        if (option.hasOwnProperty('answerUrl')) {
            config.answerUrl = (option.answerUrl || '') + '';
        }

        if (option.hasOwnProperty('hangupUrl')) {
            config.hangupUrl = (option.hangupUrl || '') + '';
        }

        if (option.hasOwnProperty('autoLogin')) {
            config.autoLogin = option.autoLogin;
        }

        if (option.hasOwnProperty('forceLogin')) {
            config.forceLogin = option.forceLogin;
        }

        if (option.hasOwnProperty('autoAnswer')) {
            config.autoAnswer = option.autoAnswer;
        }

        if (option.hasOwnProperty('autoReady')) {
            config.autoReady = option.autoReady;
        }

        if (option.hasOwnProperty('acwTime')) {
            config.acwTime = option.acwTime;
        }

        if (option.hasOwnProperty('answerTime')) {
            config.answerTime = option.answerTime;
        }

        if (option.hasOwnProperty('transferFlag')) {
            config.transferFlag = option.transferFlag;
        }

        if (option.hasOwnProperty('dialPrefix')) {
            config.dialPrefix = (option.dialPrefix || '') + '';
        }

        if (option.hasOwnProperty('dialCaller')) {
            config.dialCaller = (option.dialCaller || '') + '';
        }

        if (option.hasOwnProperty('ivrDn')) {
            config.ivrDn = (option.ivrDn || '') + '';
        }

        if (option.hasOwnProperty('debug')) {
            config.debug = option.debug;
        }

        return true;
    }







    function getCookie(key) {
        return decodeURIComponent(document.cookie.replace(new RegExp("(?:(?:^|.*;)\\s*"
            + encodeURIComponent(key).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\=\\s*([^;]*).*$)|^.*$"), "$1")) || null;
    }

    function setCookie(key, value, end, path, domain, secure) {

        if (!key || /^(?:expires|max\-age|path|domain|secure)$/i.test(key)) {
            return false;
        }

        var expires = "";

        if (end) {
            switch (end.constructor) {
                case Number:
                    expires = end === Infinity ? "; expires=Fri, 31 Dec 9999 23:59:59 GMT" : "; max-age=" + end;
                    break;
                case String:
                    expires = "; expires=" + end;
                    break;
                case Date:
                    expires = "; expires=" + end.toUTCString();
                    break;
            }
        }

        document.cookie = encodeURIComponent(key) + "=" + encodeURIComponent(value) + expires
            + (domain ? "; domain=" + domain : "") + (path ? "; path=" + path : "")	+ (secure ? "; secure" : "");

        return true;
    }

    function hasCookie(key) {
        return (new RegExp("(?:^|;\\s*)" + encodeURIComponent(key).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\=")).test(document.cookie);
    }

    function expireCookie(key, path, domain) {
        if (!key || !hasCookie(key)) {
            return false;
        }
        document.cookie = encodeURIComponent(key) + "=; expires=Thu, 01 Jan 1970 00:00:00 GMT"
            + (domain ? "; domain=" + domain : "") + (path ? "; path=" + path : "");
        return true;
    }









	/**
     * WebSocket连接
     */
    var websocket = null;
    function start() {
        if('WebSocket' in window){
            var timestamp=new Date().getTime();
            var param = 1;
            var wsUrl =  config.socketUrl;
            console.log("socket 链接地址：" + wsUrl);
            if (wsUrl.indexOf("https") >= 0 ) {//如果是https  webSocket 需要遵守wss协议所以这里判断如果是https socket
                wsUrl = wsUrl.replace("https","wss");
            }else{
                wsUrl = wsUrl.replace("http","ws");
            }
            console.log("socket 通讯地址：" + wsUrl);
            websocket = new WebSocket(wsUrl);
        }else{
            alert("您的浏览器不支持websocket");
        }
		 //连接发生错误的回调方法
        websocket.onerror = function(){
            setMessageInnerHTML("{'code':'404','success':false,'message':'WebSocket连接发生错误'}");
        }
		//连接成功建立的回调方法
        websocket.onopen = function(){
            
			$('#printContainer pre').empty();
			setMessageInnerHTML("{'code':'200','success':true,'message':'WebSocket连接成功'}");
			$('#loginContainer').slideToggle();
			$('#mainContainer').slideToggle();
			forceLogin();
        }
		//接收到消息的回调方法
        websocket.onmessage  = function(event){
            //setMessageInnerHTML(event.data);
        }
		//连接关闭的回调方法
        websocket.onclose = function(){
            setMessageInnerHTML("{'code':'200','success':true,'message':'WebSocket连接关闭'}")
        }
        window.onbeforeunload = function(){
            clos();
        }
    }

    function setMessageInHtml(message){
        document.getElementById('message').innerHTML += "收到的消息:" + message + "<br/>" ;
    }
    function clos(){
        websocket.close(3000,"强制关闭");
    }
    function send(){
        var msg = document.getElementById('text').value;
        websocket.send(msg);
    }

    //监听窗口关闭事件，当窗口关闭时，主动去关闭websocket连接，防止连接还没断开就关闭窗口，server端会抛异常。
    window.onbeforeunload = function () {
        closeWebSocket();
    }

    $(window).unload(function () {
        socket.close();
    });

    //将消息显示在网页上
    function setMessageInnerHTML(sendMessage) {
        $('#printContainer pre').append("收到的消息: " +JSON.stringify(sendMessage, null, 0) + '\n\n');
        $('#printContainer').scrollTop($('#printContainer')[0].scrollHeight);
        return sendMessage;
    }

    //关闭WebSocket连接
    function closeWebSocket() {
        websocket.close();
    }

    function stop() {

        if (agent.isLogin) {
            logout();
        }

        setTimeout(function() {
            if (websocket && isOnline) {
                websocket.close();
            }
        }, 100);
    }
    var timer;
    //签入
    function login(){
        $.post(config.proxyUrl + "/onlineAgent/online",
            {
                workNo: agent.agentId,
                password: agent.agentDn,
                phonenum: agent.agentDn,
                agentName: agent.agentName,
                type: "LOGIN"
            },
            function (data) {
                console.info(data + ":data");

                if (data == null || data == "") {
                    return false;
                }
                if (data == "+OK") {
                    setTimeout(onStatusChanged(), 500);
                    timer = setInterval(getAgentState, 1000);
                    return true;
                }
            });
    }



    //强制签入
    function forceLogin() {
        logout2();
        setTimeout(function() {
            login();
        }, 100);
    }

    /*
        * Idle(Ready)
        * 置闲
        */
    function ready() {
        console.info("ready");

        $.post(config.proxyUrl + "/onlineAgent/online",
            {
                workNo: agent.agentId,
                type: "READY"
            },
            function (data) {
                if (data === "+OK") {
                    return true;
                }
                return false;
            });
    }


    /*
    * Work State
    * 置忙
    */
    function busy() {
        $.post(config.proxyUrl + "/onlineAgent/online",
            {
                workNo: agent.agentId,
                type: "BUSY"
            },
            function (data) {
                if (data === "+OK") {
                    return true;
                }
                return false;
            });
    }



    //签出
    function logout() {
        $.post(config.proxyUrl + "/onlineAgent/online",
            {
                workNo: agent.agentId,
                type: "LOGOUT"
            },
            function (data) {
                //writeLog("[Logout]" + data);
                if (data === "+OK") {
                    $("#status").val("签出态");
                    chxTime("签出态");
                    clos();
                    logOutStatus();
                    return true;
                }
                return false;
            });
    }

    //签出
    function logout2() {
        $.post(config.proxyUrl + "/onlineAgent/online",
            {
                workNo: agent.agentId,
                type: "LOGOUT"
            },
            function (data) {
                //writeLog("[Logout]" + data);
                if (data === "+OK") {
                    $("#status").val("签出态");
                    chxTime("签出态");
                    //clos();
                    logOutStatus();
                    return true;
                }
                return false;
            });
    }


    /*
     * 接听
     */
    function answerCall(){
        $.post(config.proxyUrl+"/voiceCall/voice.do",
            {
                workNo : agent.agentId,
                type : "ANSWER",
                answerUrl: config.answerUrl
            },function(data){
                writeLog("[answerCall]"+data);
                if(data != null && data != ''){
                    httpGet(data);
                    $.getJSON(data);
                    return true;
                }
                return false;
            });
    }

    /*
     * 挂机
     */
    function hangupCall() {
        $.post(config.proxyUrl+"/voiceCall/voice.do",
            {
                workNo : agent.agentId,
                type : "RELEASE",
                hangupUrl: config.hangupUrl
            },function(data){
                if (data === "+OK") {
                    return true;
                }
                return false;
            });
    }

    /*
     * 外呼
     */
    function makeCall(devicetype,called) {
        var result="";
        $.post(config.proxyUrl+"/voiceCall/voice.do",{
            workNo : agent.agentId,
            called : called,
            type : "CALLOUT",
            deviceType:devicetype
        },function(data){
            if (data == null || data == "") {
                return false;
            }
            if (data.indexOf( "+OK") != -1 ) {
                return true;
            }


        });
    }


    /*
     * 保持
     */
    function holdCall(workNo)  {
        $.post(config.proxyUrl+"/voiceCall/voice.do",
            {
                workNo : agent.agentId,
                type : "HOLD"
            },function(data){
                if (data == null || data == "") {
                    return false;
                }
                writeLog("[Hold]"+data);
                if(data.indexOf( "+OK") != -1){
                    Hold_Talking();
                    return true;
                }

            });
    }

    /*
     * 取消保持
     */
    function retrieveCall(workNo)  {
        $.post(config.proxyUrl+"/voiceCall/voice.do",
            {
                workNo : agent.agentId,
                type : "GETHOLD"
            },function(data){
                if (data == null || data == "") {
                    return false;
                }
                writeLog("[Hold]"+data);
                if(data.indexOf( "+OK") != -1){
                    Process_Talking();
                    return true;
                }
            });
    }



    /*
     * 转接
     */
    function transferCall(called)  {
        $.post(config.proxyUrl+"/voiceCall/voice.do",
            {
                workNo : agent.agentId,
                address : called,
                type : "TRANSFER"
            },function(data){
                if (data == null || data == "") {
                    return false;
                }else{
                    return true;
                }
            });
    }


    /*	三方*/
    function conferenceCall(called) {
        $.post(config.proxyUrl+"/voiceCall/voice.do",
            {
                workNo : agent.agentId,
                called : called ,
                type : "THREWAY"

            },function(data){
                if (data == null || data == "") {
                    console.info("三方失败！")
                    return false;
                }
                console.info("三方==data=="+data);
                if (data === "+OK") {
                    return true;
                }
            });
    }

    /*	监听*/
    function listenCall(called) {
        $.post(config.proxyUrl+"/voiceCall/voice.do",
            {
                workNo : agent.agentId,
                called : called ,
                type : "LISTEN"

            },function(data){
                if (data == null || data == "") {
                    alert("强插失败！")
                    return false;
                }
                console.info("监听==data=="+data);
                if (data === "+OK") {
                    return true;
                }
            });
    }


    //*******************************************************************//
    var res_agentState ;
    //get agent event
    function getAgentState() {

        if (agent.agentId == "") {
            return;
        }
        $.ajax({
            data:{
                workNo : agent.agentId,
                type : "queryAgentStatus"
            },
            url:config.proxyUrl+'/onlineAgent/online',
            type:'post',

            cache:false,
            success:function(mes){
                //console.info("mes:"+mes);
                try {
                    if (mes == null || mes == ""){
                        //setTimeout(getAgentState(), 5000);
                        //timer=window.clearInterval(timer);
                        return;
                    }
                    if (mes == "坐席未登录" || mes == "2") {
                        //setTimeout(onStatusChanged(), 5000);
                        console.info("Logged out timer:"+timer);
                        //QueryagentStatus("Logged out");
                        timer=window.clearInterval(timer);
                        return;
                    }

                    QueryagentStatus(mes);
                    //setTimeout(getAgentState(), 5000);
                }  catch(err){
                    console.info("错误信息："+err);
                    //setTimeout(getAgentState(), 5000);

                }
            },
            error:function (e) {
                console.info("错误信息："+e);
            }

        })

       /* $.post(config.proxyUrl+'/onlineAgent/online',  ,
            function(data)  {

            });*/
    };

    var AUTO_TYPE_AGENTREADY = 2; // 自动空闲
    var AUTO_TYPE_AGENTNOTREADY = 3; // 自动忙碌

    function QueryagentStatus(result){
        //var result = JSON.parse(event);
        var agentState = result;
        //writeLog(result);
        console.info("agentState= " + agentState);
        //chxTime(agentState);
        switch(agentState) {

            case "Login":  //签入
                agentStatus("签入");
                break;
            case "Available":  //空闲
                agentStatus("空闲态");
                break;
            case "On Break":  //忙碌
                agentStatus("忙碌态");
                break;
            case "Working":  //工作
                agentStatus("通话态");
                break;
            case "neaten":  //整理
                agentStatus("整理");
                break;
            case "Logged out":  //座席状态切换
                //gentStatus("签出");
                break;
            default:
                break;
        }

    }

    function agentStatus(status) {
        //改变按钮状态
        // forceLogin(workNo, extennumber);
        $("#status").val(status);
        chxTime(status);
    }


    /**
     * 话后整理
     * @param event
     */
    function onAgentAfterCallWork(event) {

        /*if (appointType == APPOINT_TYPE_NOTREADY) {
            appointType = APPOINT_TYPE_NULL;
            notReady();
            return;
        }

        if (appointType == APPOINT_TYPE_AFTERCALLWORK) {
            appointType = APPOINT_TYPE_NULL;
            return;
        }

        if (appointType == APPOINT_TYPE_OTHERWORK) {
            appointType = APPOINT_TYPE_NULL;
            otherWork(0);
            return;
        }*/
        console.info("onAgentAfterCallWork:"+config.acwTime);
        if (acwTimer) {
            clearTimeout(acwTimer);
        }

        acwTimer = setTimeout(function() {
            switch (config.autoReady) {
                case AUTO_TYPE_AGENTREADY:
                    ready();
                    break;

                case AUTO_TYPE_AGENTNOTREADY:
                    busy();
                    break;
            }
        }, config.acwTime);
    }




    //  get agent event
    function onStatusChanged(){
        if (agent.agentId == ""){
            return;
        }

        $.post(config.proxyUrl+'/event/event',{
                workNo : agent.agentId
            },
            function(data){
                //console.info("data= " +JSON.stringify(data));
                try {
                    if (data == null || data == "") {
                        setTimeout(onStatusChanged(), 5000);
                        return;
                    }
                    if (data == "坐席未登录") {
                        //setTimeout(onStatusChanged(), 5000);
                        return;
                    }

                    var event = JSON.parse(data);
                    //console.info("event----parse:"+event);
                    //var stringify = JSON.stringify(data);
                    //console.info("event----stringify:"+stringify);
                    if (event == undefined || null == event || event.length == 0) {
                        setTimeout(onStatusChanged(), 5000);
                        return;
                    }
                    //var obj = eval(event);
                    //Object.keys(event).filter(x => {if (x === '') delete event[x]});

                    var eventType = event['CC-Action'];
                    if (eventType == undefined || null == eventType || eventType.length == 0) {
                        setTimeout(onStatusChanged(), 5000);
                        return;
                    }
                    eventHandle(event);
                    onStatusChanged();
                }catch(err){
                    console.info("错误信息："+err);
                    setTimeout(onStatusChanged(), 5000);
                }
            });
    };

    //eventHandle
    function eventHandle(event) {
        var eventType = event['CC-Action'];
        //writeLog(JSON.stringify(event));
        //console.info("event= " + event);
        $('#printContainer pre').append("'CC-Action':" +eventType+ ';event: ' +JSON.stringify(event, null, 4) + '\n\n');
        $('#printContainer').scrollTop($('#printContainer')[0].scrollHeight);
        switch(eventType) {
            case "agent-status-change":  //座席状态切换
                agentStatusChange(event);
                break;
            case "agent-state-change":  //分机状态变化
                //Process_IN_SERVER();
                break;
            case "CHANNEL_PROGRESS":  //分机呼叫振铃
                Process_Ringing(event);
                break;
            case "agent-offering":  //振铃
                //Process_Ringing(event);
                break;
            case "CHANNEL_ANSWER":  //外呼分机接听
                //outcall_Talking(event);
                Process_Talking(event);
                break;
            case "CHANNEL_BRIDGE":  //对方接听
                Process_Talking(event);
                break;
            case "bridge-agent-start":  //坐席接听
                Process_Talking(event);
                break;

            case "CHANNEL_DESTROY":  //通道销毁
                Customer_Release();
                break;
            case "CHANNEL_HANGUP":  //分机挂断
                Customer_Release();
                break;
            case "bridge-agent-end":  //坐席挂断
                Customer_Release();
                break;
            case "bridge-agent-fail":  //坐席振铃后 坐席未接
                realseBtnClick();
                break;
            case "RECORD_STOP":  //录音结束
                //realseBtnClick();
                console.info("RECORD_STOP:录音结束"+event);
                break;
            case "RECORD_START":  //录音开始
                console.info("RECORD_START:录音开始"+event);
                break;
            case "members-count":  //队列计数 有呼叫进出队列发生

                //Process_IN_SERVER();
                break;
            case "member-queue-start":  //进队列

                //Process_IN_SERVER();
                break;
            case "member-queue-end":  //出队列   这时候主叫挂断CC-Cause: Cancel 正常转接给坐席 CC-Cause: Cancel

                //Process_IN_SERVER();
                break;

            default:
                break;
        }

    }

//***********************************************************************************************************************/










    this.getOption = function(field) {
        return getOption(field);
    };

    this.setOption = function(option) {
        return setOption(option);
    };

    this.start = function() {
        return start();
    };

    this.getMessageInnerHTML = function() {
        return setMessageInnerHTML();
    };

    this.stop = function() {
        return stop();
    };

    // 签入
    this.login = function() {
        return login();
    };

    // 签出
    this.logout = function() {
        return logout();
    };

    // 忙碌
    this.notReady = function() {
        return busy();
    };

    // 空闲
    this.ready = function() {
        return ready();
    };

    // 强制签入
    this.forceLogin = function() {
        return forceLogin();
    };

    // 接听
    this.answerCall = function() {
        return answerCall();
    };

    // 挂机
    this.hangupCall = function() {
        return hangupCall();
    };

    // 外呼
    this.makeCall = function(devicetype,called) {
        return makeCall(devicetype,called);
    };

    // 保持
    this.holdCall = function() {
        return holdCall();
    };

    // 取消保持
    this.retrieveCall = function() {
        return retrieveCall();
    };

    // 转接
    this.transferCall = function(called) {
        return transferCall(called);
    };

    // 三方
    this.conferenceCall = function(called) {
        return conferenceCall(called);
    };

    // 监听
    this.listenCall = function(called) {
        return listenCall(called);
    };

    //获取座席事件
    this.onStatusChanged = function() {
        return onStatusChanged();
    };
    //话后整理自动置忙/置闲
    this.onAgentAfterCallWork = function() {
        return onAgentAfterCallWork();
    };

    //获取坐席状态
    this.getAgentState = function() {
        return getAgentState();
    };

   /* this.chxTime = function () {
        return chxTime();
    }*/

    var chxduration=0;
    var chxstatus="";
    var chxhour="";
    var chxminute="";
    var chxsecond="";
    var chx=true;

    function chxTime(status){
        if(status!=""&&status!=chxstatus){
            chxduration=0;
            chxstatus=status;
            if(status=="整理"){
                onAgentAfterCallWork();
            }
        }

        if(chx){

            setInterval(FreshTime, 1000);
            chx=false;
        }
    }

    function FreshTime() {

        chxhour = parseInt(parseInt(chxduration) / 1000 / 60 / 60 % 60);
        chxminute = parseInt(parseInt(chxduration) / 1000 / 60 % 60);
        chxsecond = parseInt(parseInt(chxduration) / 1000 % 60);
        if (chxhour.toString().length < 2) {
            chxhour = "0" + chxhour;
        }
        if (chxminute.toString().length < 2) {
            chxminute = "0" + chxminute;
        }
        if (chxsecond.toString().length < 2) {
            chxsecond = "0" + chxsecond;
        }
        $("#times").val(chxhour + ":" + chxminute + ":" + chxsecond);
        chxduration+=1000;
    }
};




String.prototype.trim=function(){
    return this.replace(/(^\s*)|(\s*$)/g, "");
};

function httpGet(url) {
    try {

        var xhr = new XMLHttpRequest();

        if ('withCredentials' in xhr) {

            xhr.open('GET', url);
            xhr.send();

        } else if (window.XDomainRequest) {

            var xdr = new XDomainRequest();

            xdr.open('GET', url);
            setTimeout(function() {
                xdr.send();
            }, 0);
        }

    } catch (e) {
        console.info('http error:', e ? e.message : e);
    }
}




















