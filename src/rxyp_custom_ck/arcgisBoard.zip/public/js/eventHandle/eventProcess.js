//来电样式
function Process_Ringing(content) {

    if(content['Call-Direction']=="outbound"){
        $("#phone").val(content['Caller-Callee-ID-Number']);
    }else{
        $("#phone").val(content['Caller-Caller-ID-Number']);
    }
    //隐藏小休
    $("button[data-action='ready']").attr("disabled", true);
    //隐藏置闲
    $("button[data-action='sayIdle']").attr("disabled", true);
    //显示接听
    $("button[data-action='answer']").attr("disabled", false);
    //隐藏拨号
    $("button[data-action='dial']").attr("disabled", true);
    //隐藏挂机
    $("button[data-action='release']").attr("disabled", true);
    //隐藏保持
    $("button[data-action='hold']").attr("disabled", true);
    //隐藏取持
    $("button[data-action='getHold']").attr("disabled", true);
    //隐藏转接
    $("button[data-action='transfer']").attr("disabled", true);
    //隐藏监听
    $("button[data-action='listen']").attr("disabled", true);
    //隐藏三方
    $("button[data-action='threWay']").attr("disabled", true);
    //隐藏签出
    $("button[data-action='logout']").attr("disabled", true);
}

//外呼振铃
function out_Ringing(content) {

    //隐藏小休
    $("button[data-action='ready']").attr("disabled", true);
    //隐藏置闲
    $("button[data-action='sayIdle']").attr("disabled", true);
    //显示接听
    $("button[data-action='answer']").attr("disabled", false);
    //隐藏拨号
    $("button[data-action='dial']").attr("disabled", true);
    //隐藏挂机
    $("button[data-action='release']").attr("disabled", true);
    //隐藏保持
    $("button[data-action='hold']").attr("disabled", true);
    //隐藏取持
    $("button[data-action='getHold']").attr("disabled", true);
    //隐藏转接
    $("button[data-action='transfer']").attr("disabled", true);
    //隐藏监听
    $("button[data-action='listen']").attr("disabled", true);
    //隐藏三方
    $("button[data-action='threWay']").attr("disabled", true);
    //隐藏签出
    $("button[data-action='logout']").attr("disabled", true);

}

//接听样式
function Process_Talking(content) {
    //$("#checkin").removeClass('layui-btn-primary');
   // $("#checkin").addClass('layui-btn-disabled');
    if(content['Call-Direction']=="outbound"){
        $("#phone").val(content['Caller-Callee-ID-Number']);
    }else{
        $("#phone").val(content['Caller-Caller-ID-Number']);
    }

    //隐藏小休
    $("button[data-action='ready']").attr("disabled", true);
    //隐藏置闲
    $("button[data-action='sayIdle']").attr("disabled", true);
    //隐藏接听
    $("button[data-action='answer']").attr("disabled", true);
    //隐藏拨号
    $("button[data-action='dial']").attr("disabled", true);
    //显示挂机
    $("button[data-action='release']").attr("disabled", false);
    //显示保持
    $("button[data-action='hold']").attr("disabled", false);
    //隐藏取持
    $("button[data-action='getHold']").attr("disabled", true);
    //显示转接
    $("button[data-action='transfer']").attr("disabled", false);
    //隐藏监听
    $("button[data-action='listen']").attr("disabled", true);
    //隐藏三方
    $("button[data-action='threWay']").attr("disabled", true);
    //隐藏签出
    $("button[data-action='logout']").attr("disabled", true);
}


//保持样式
function Hold_Talking() {
    //$("#checkin").removeClass('layui-btn-primary');
    // $("#checkin").addClass('layui-btn-disabled');
    //隐藏小休
    $("button[data-action='ready']").attr("disabled", true);
    //隐藏置闲
    $("button[data-action='sayIdle']").attr("disabled", true);
    //隐藏接听
    $("button[data-action='answer']").attr("disabled", true);
    //隐藏拨号
    $("button[data-action='dial']").attr("disabled", true);
    //隐藏拨号
    $("button[data-action='release']").attr("disabled", true);
    //隐藏保持
    $("button[data-action='hold']").attr("disabled", true);
    //显示取消保持
    $("button[data-action='getHold']").attr("disabled", false);
    //隐藏转接
    $("button[data-action='transfer']").attr("disabled", true);
    //隐藏监听
    $("button[data-action='listen']").attr("disabled", true);
    //隐藏三方
    $("button[data-action='threWay']").attr("disabled", true);
    //隐藏签出
    $("button[data-action='logout']").attr("disabled", true);
}


//外呼分机接听
function outcall_Talking(content) {
    //隐藏小休
    $("button[data-action='ready']").attr("disabled", true);
    //隐藏置闲
    $("button[data-action='sayIdle']").attr("disabled", true);
    //隐藏接听
    $("button[data-action='answer']").attr("disabled", true);
    //隐藏拨号
    $("button[data-action='dial']").attr("disabled", true);
    //显示挂机
    $("button[data-action='release']").attr("disabled", false);
    //隐藏保持
    $("button[data-action='hold']").attr("disabled", true);
    //隐藏取持
    $("button[data-action='getHold']").attr("disabled", true);
    //隐藏转接
    $("button[data-action='transfer']").attr("disabled", true);
    //隐藏监听
    $("button[data-action='listen']").attr("disabled", true);
    //隐藏三方
    $("button[data-action='threWay']").attr("disabled", true);
    //隐藏签出
    $("button[data-action='logout']").attr("disabled", true);
}

//挂机
function Customer_Release() {
    //隐藏小休
    $("button[data-action='ready']").attr("disabled", true);
    //隐藏置闲
    $("button[data-action='sayIdle']").attr("disabled", true);
    //隐藏接听
    $("button[data-action='answer']").attr("disabled", true);
    //显示拨号
    $("button[data-action='dial']").attr("disabled", false);
    //隐藏挂机
    $("button[data-action='release']").attr("disabled", true);
    //隐藏保持
    $("button[data-action='hold']").attr("disabled", true);
    //隐藏取持
    $("button[data-action='getHold']").attr("disabled", true);
    //隐藏转接
    $("button[data-action='transfer']").attr("disabled", true);
    //显示监听
    $("button[data-action='listen']").attr("disabled", false);
    //显示三方
    $("button[data-action='threWay']").attr("disabled", false);
    //显示签出
    $("button[data-action='logout']").attr("disabled", false);
}




//按钮
function agentStatusChange(event) {
    var eventStatus = event['CC-Agent-Status'];
    console.info("eventStatus:"+eventStatus);
    switch(eventStatus) {
        case "Available":  //空闲
            workToReady();
            break;
        case "On Break":  //忙碌
            realseBtnClick(event);
            break;
        case "Working":  //工作
            monitorfu(event);
            break;
        case "agent-status-change":  //座席状态切换
            //agentStatusChange(event);
            break;
        case "agent-status-change":  //座席状态切换
            //agentStatusChange(event);
            break;
        default:
            break;

    }
}


//按钮
function signInBtnClick() {
    //改变按钮状态
    // forceLogin(workNo, extennumber);
    $("#status").val("整理态");
    //隐藏确认签入框

    //隐藏签入
    //$("#checkin").attr("disabled", true);
    //显示小休
    $("button[data-action='ready']").attr("disabled", true);
    //显示置闲
    $("button[data-action='sayIdle']").attr("disabled", false);
    //隐藏接听
    $("button[data-action='answer']").attr("disabled", true);
    //显示拨号
    $("button[data-action='dial']").attr("disabled", true);
    //隐藏挂机
    $("button[data-action='release']").attr("disabled", true);
    //隐藏保持
    $("button[data-action='hold']").attr("disabled", true);
    //隐藏咨询
    $("button[data-action='consult']").attr("disabled", true);
    //隐藏转接
    $("button[data-action='transfer']").attr("disabled", true);
    //显示取出
    $("button[data-action='monitor']").attr("disabled", true);
    $("button[data-action='threWay']").attr("disabled", true);
    // //显示拦截
    // $("button[data-action='holdup']").attr("disabled", true);
    // //显示强插
    // $("button[data-action='observe']").attr("disabled", true);1
    //显示签出
    $("button[data-action='logout']").attr("disabled", false);
    //initAgentLog();
}

function workToReady() {
    //改变按钮状态
    // forceLogin(workNo, extennumber);
/*    $("#status").val("空闲态");
    chxTime("空闲态");*/
    /*$('#loginContainer').slideToggle();
    $('#mainContainer').slideToggle();*/
    //隐藏签入
    //$("#checkin").attr("disabled", true);
    //显示小休
    $("button[data-action='ready']").attr("disabled", false);
    //隐藏置闲
    $("button[data-action='sayIdle']").attr("disabled", true);
    //隐藏接听
    $("button[data-action='answer']").attr("disabled", true);
    //显示拨号
    $("button[data-action='dial']").attr("disabled", false);
    //隐藏挂机
    $("button[data-action='release']").attr("disabled", true);
    //隐藏保持
    $("button[data-action='hold']").attr("disabled", true);
    //隐藏取持
    $("button[data-action='getHold']").attr("disabled", true);
    //隐藏转接
    $("button[data-action='transfer']").attr("disabled", true);
    //显示监听
    $("button[data-action='listen']").attr("disabled", false);
    //显示三方
    $("button[data-action='threWay']").attr("disabled", false);
    //显示签出
    $("button[data-action='logout']").attr("disabled", false);

}



//小休
function realseBtnClick() {
    //改变按钮状态
    // forceLogin(workNo, extennumber);
   /* $("#status").val("忙碌态");
    chxTime("忙碌态");*/
    //隐藏签入
   // $("#checkin").attr("disabled", true);
    //隐藏小休
    $("button[data-action='ready']").attr("disabled", true);
    //显示置闲
    $("button[data-action='sayIdle']").attr("disabled", false);
    //隐藏接听
    $("button[data-action='answer']").attr("disabled", true);
    //显示拨号
    $("button[data-action='dial']").attr("disabled", false);
    //隐藏挂机
    $("button[data-action='release']").attr("disabled", true);
    //隐藏保持
    $("button[data-action='hold']").attr("disabled", true);
    //隐藏取持
    $("button[data-action='getHold']").attr("disabled", true);
    //隐藏转接
    $("button[data-action='transfer']").attr("disabled", true);
    //隐藏监听
    $("button[data-action='listen']").attr("disabled", true);
    //隐藏三方
    $("button[data-action='threWay']").attr("disabled", true);
    //显示签出
    $("button[data-action='logout']").attr("disabled", false);
}









function monitorfu() {
    //改变按钮状态
    // forceLogin(workNo, extennumber);
    //$("#status").val("通话态");
   /* //隐藏签入
    $("#checkin").attr("disabled", true);
    //隐藏小休
    $("button[data-action='ready']").attr("disabled", true);
    //显示置闲
    $("button[data-action='sayIdle']").attr("disabled", false);
    //隐藏接听
    $("button[data-action='answer']").attr("disabled", true);
    //显示拨号
    $("button[data-action='dial']").attr("disabled", false);
    //隐藏挂机
    $("button[data-action='release']").attr("disabled", true);
    //隐藏保持
    $("button[data-action='hold']").attr("disabled", true);
    //隐藏取持
    $("button[data-action='getHold']").attr("disabled", true);
    //隐藏转接
    $("button[data-action='transfer']").attr("disabled", true);
    //隐藏监听
    $("button[data-action='listen']").attr("disabled", true);
    //隐藏三方
    $("button[data-action='threWay']").attr("disabled", true);
    //显示签出
    $("button[data-action='logout']").attr("disabled", false);*/
}

function logOutStatus() {
    //显示小休
    $("button[data-action='login']").attr("disabled", false);
    //隐藏小休
    $("button[data-action='ready']").attr("disabled", true);
    //隐藏置闲
    $("button[data-action='sayIdle']").attr("disabled", true);
    //隐藏接听
    $("button[data-action='answer']").attr("disabled", true);
    //隐藏拨号
    $("button[data-action='dial']").attr("disabled", true);
    //隐藏挂机
    $("button[data-action='release']").attr("disabled", true);
    //隐藏保持
    $("button[data-action='hold']").attr("disabled", true);
    //隐藏取持
    $("button[data-action='getHold']").attr("disabled", true);
    //隐藏转接
    $("button[data-action='transfer']").attr("disabled", true);
    //隐藏监听
    $("button[data-action='listen']").attr("disabled", true);
    //隐藏三方
    $("button[data-action='threWay']").attr("disabled", true);
    //隐藏签出
    $("button[data-action='logout']").attr("disabled", true);
}
