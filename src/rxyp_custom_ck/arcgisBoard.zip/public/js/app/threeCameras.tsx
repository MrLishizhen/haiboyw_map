// @ts-ignore
import * as THREE from 'three-projector';
// @ts-ignore
import axios from 'axios';
// @ts-ignore
import flvjs from 'flv';
// @ts-ignore
import VideoStream from 'VideoStream';

// @ts-ignore
import {subclass, property} from "esri/core/accessorSupport/decorators";
// @ts-ignore
import Widget = require("esri/widgets/Widget");
// @ts-ignore
import {renderable, tsx} from "esri/widgets/support/widget";
// @ts-ignore
import SceneView from "esri/views/SceneView";
// @ts-ignore
import SpatialReference from "esri/geometry/SpatialReference";

// @ts-ignore
@subclass("esri/views/3d/externalRenderers")
class ThreeCameras extends Widget {
    private scene: {};
    private projectors: {};
    private videoStreams: {};

    constructor(params?: any) {
        super(params);
    }

    @property()
    @renderable()
    view: SceneView;

    @property()
    @renderable()
    layerUrl: string = "https://tiles.arcgis.com/tiles/z2tnIkrLQ2BRzr6P/arcgis/rest/services/SanFrancisco_Bldgs/SceneServer/layers/0";

    @property()
    @renderable()
    featureIDArray: number[];

    @property()
    // @renderable()
    externalRenderer: any;

    @property()
    @renderable()
    ifAddAllNode: boolean = false;

    @property()
    @renderable()
    ifAddGround: boolean = true;

    @property()
    @renderable()
    groundCircleRadius: number = null;

    @property()
    @renderable()
    addGroundHeight: number = 0;

    @property()
    @renderable()
    f: string = 'json';

    @property()
    @renderable()
    token: string = '';


    postInitialize() {
        console.log("Entering postInitialize", this);
        this.projectors = {};
        this.videoStreams = {};
        const view = this.view;
        const layerUrl = this.layerUrl;
        const featureIDArray = this.featureIDArray;
        const externalRenderer = this.externalRenderer;
        const ifAddAllNode = this.ifAddAllNode;
        const ifAddGround = this.ifAddGround;
        const groundCircleRadius = this.groundCircleRadius;
        const addGroundHeight = this.addGroundHeight;
        const axiosParam = {
            params:{
                f: this.f,
                token:this.token
            }
        };

        let tthis = this;

        console.log("Defining  myExternalRenderer");
        const myExternalRenderer = {

            setup: function (context) {
                console.log("Entering setup");
                this.renderer = new THREE.WebGLRenderer({
                    context: context.gl,
                    premultipliedAlpha: false,
                    antialias: true,
                    alpha: true
                });
                this.renderer.shadowMap.enabled = true;
                this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
                //设置设备像素比，可以避免HiDPI设备上绘图模糊
                this.renderer.setPixelRatio(window.devicePixelRatio);
                //设置视口大小和三维场景的大小一样
                this.renderer.setViewport(0, 0, view.width, view.height);

                // 防止Three.js清除ArcGIS JS API提供的缓冲区
                this.renderer.autoClearDepth = false; // 定义renderer是否清除深度缓存
                this.renderer.autoClearStencil = false; // 定义renderer是否清除模板缓存
                this.renderer.autoClearColor = false; // 定义renderer是否清除颜色缓存

                //ArcGIS JS API渲染自定义离屏缓冲区，而不是默认的帧缓冲区。
                //我们必须将这段代码注入到Three.js运行时中，以便绑定这些缓冲区而不是默认的缓冲区。
                const originalSetRenderTarget = this.renderer.setRenderTarget.bind(
                    this.renderer
                );
                this.renderer.setRenderTarget = function (target) {
                    originalSetRenderTarget(target);
                    this.state.viewport(new THREE.Vector4(0, 0, view.width, view.height));
                    if (target == null) {
                        context.bindRenderTarget();
                    }
                }.bind(
                    this.renderer
                );

                const that = this;

                that.scene = new THREE.Scene();
                that.camera = new THREE.PerspectiveCamera();
                that.camera.far = 10000000;

                tthis.scene = that.scene;

                that.ambient = new THREE.AmbientLight(0xffffff, 0.5);
                that.scene.add(that.ambient);
                that.sun = new THREE.DirectionalLight(0xffffff, 0.5);
                that.scene.add(that.sun);


                that.tstack = [];
                that.featureInfo = {};      //包含这个ID的feature数据
                that.nodeInfo = {};         //所有检索过的节点信息，目的是查找mbs等
                that.layer0Info = {};       //保存layer0的信息，用于查找地理参考等
                that.nowSpatialReference = SpatialReference.WGS84;  //初始化空间参考，默认为WGS84坐标系

                that.tstacks = 0;

                loadArcgisLayer(layerUrl, featureIDArray);

                function loadArcgisLayer(layerUrl, featureIDArray) {

                    getNeededNodeFeatureInfoByID(featureIDArray, layerUrl);

                    function getNeededNodeFeatureInfoByID(featureIDArray, originUrl) {
                        getRootNodeUrl(originUrl).then(rootNodeUrl => {
                            // that.tstack.push("root");
                            that.tstacks ++;

                            for (const index in featureIDArray) {
                                getNeededFeatureAndChildrenByID(originUrl, featureIDArray[index], rootNodeUrl);
                            }
                        });
                    }

                    function getRootNodeUrl(originUrl) {
                        return new Promise(function (resolve, reject) {
                            try {
                                axios.get(originUrl, axiosParam).then(
                                    res => {
                                        console.log('origin info', res);

                                        that.layer0Info = res.data;         //将layer0信息存入
                                        that.nowSpatialReference = new SpatialReference({wkid: that.layer0Info.spatialReference.wkid});
                                        let rootNodeUrl = originUrl + res.data.store.rootNode.substr(1);
                                        resolve(rootNodeUrl);
                                    }
                                )
                            } catch (e) {
                                reject(e);
                            }
                        })
                    }

                    function getNeededFeatureAndChildrenByID(layerUrl, featureID, originUrl) {
                        axios.get(originUrl,axiosParam).then(res => {
                            const nodeInfo = res.data;
                            nodeInfo.isLeafNode = true;
                            if (nodeInfo.children && nodeInfo.children.length > 0) {
                                nodeInfo.isLeafNode = false;
                                for (let i = 0; i < nodeInfo.children.length; i++) {
                                    const childNode = nodeInfo.children[i];
                                    that.tstack.push(childNode.id);
                                    // console.log("nodeInfo.children");
                                    // console.log(that.tstack);
                                }
                            }
                            if (!nodeInfo.featureData) {
                                that.tstack.splice(that.tstack.indexOf(nodeInfo.id), 1);
                                if (nodeInfo.children && nodeInfo.children.length > 0) {
                                    for (let i = 0; i < nodeInfo.children.length; i++) {
                                        const childNode = nodeInfo.children[i];
                                        // @ts-ignore
                                        let nextNodeUrl = pathJoin([originUrl, childNode.href]);
                                        getNeededFeatureAndChildrenByID(layerUrl, featureID, nextNodeUrl);
                                    }
                                }
                            } else {
                                nodeInfo.url = originUrl;
                                that.nodeInfo[nodeInfo.id] = nodeInfo;
                                for (let i = 0; i < nodeInfo.featureData.length; i++) {
                                    const featureData = nodeInfo.featureData[i];
                                    // @ts-ignore
                                    let featureUrl = pathJoin([originUrl, featureData.href]);
                                    axios.get(featureUrl,axiosParam).then(res => {
                                        let featureInfo = res.data;
                                        let hasFeature = false;
                                        if (featureInfo.featureData && featureInfo.featureData.length > 0) {
                                            for (let j = 0; j < res.data.featureData.length; j++) {
                                                const feature = res.data.featureData[j];

                                                if (feature.id === featureID) {
                                                    featureInfo.url = originUrl;
                                                    that.featureInfo[nodeInfo.id] = featureInfo;
                                                    hasFeature = true;
                                                    break;
                                                }
                                            }
                                        }
                                        that.tstack.splice(that.tstack.indexOf(nodeInfo.id), 1);

                                        if (nodeInfo.children && nodeInfo.children.length > 0) {
                                            nodeInfo.isLeafNode = false;
                                            for (let i = 0; i < nodeInfo.children.length; i++) {
                                                const childNode = nodeInfo.children[i];
                                                if (hasFeature) {
                                                    // @ts-ignore
                                                    let nextNodeUrl = pathJoin([originUrl, childNode.href]);

                                                    getNeededFeatureAndChildrenByID(layerUrl, featureID, nextNodeUrl);
                                                } else {
                                                    that.tstack.splice(that.tstack.indexOf(childNode.id), 1);
                                                    // console.log(that.tstack);

                                                }
                                            }
                                        }
                                        if (that.tstack.length === 0) {
                                            // console.log(1111111111111);
                                            afterStoreInfo(featureID).then(r => {});
                                            return;
                                        }
                                    })
                                }
                            }
                        });
                    }
                    // function getNeededFeatureAndChildrenByID(layerUrl, featureID, originUrl) {
                    //     axios.get(originUrl).then(res => {
                    //         const nodeInfo = res.data;
                    //         nodeInfo.isLeafNode = true;
                    //         if (nodeInfo.children && nodeInfo.children.length > 0) {
                    //             nodeInfo.isLeafNode = false;
                    //             for (let i = 0; i < nodeInfo.children.length; i++) {
                    //                 // const childNode = nodeInfo.children[i];
                    //                 // that.tstack.push(childNode.id);
                    //                 that.tstacks ++;
                    //             }
                    //         }
                    //         if (!nodeInfo.featureData) {
                    //             // that.tstack.splice(that.tstack.indexOf(nodeInfo.id), 1);
                    //             that.tstacks --;
                    //
                    //             if (nodeInfo.children && nodeInfo.children.length > 0) {
                    //                 for (let i = 0; i < nodeInfo.children.length; i++) {
                    //                     const childNode = nodeInfo.children[i];
                    //                     // @ts-ignore
                    //                     let nextNodeUrl = pathJoin([originUrl, childNode.href]);
                    //                     getNeededFeatureAndChildrenByID(layerUrl, featureID, nextNodeUrl);
                    //                 }
                    //             }
                    //         } else {
                    //             nodeInfo.url = originUrl;
                    //             that.nodeInfo[nodeInfo.id] = nodeInfo;
                    //             for (let i = 0; i < nodeInfo.featureData.length; i++) {
                    //                 const featureData = nodeInfo.featureData[i];
                    //                 // @ts-ignore
                    //                 let featureUrl = pathJoin([originUrl, featureData.href]);
                    //                 axios.get(featureUrl).then(res => {
                    //                     let featureInfo = res.data;
                    //                     let hasFeature = false;
                    //                     if (featureInfo.featureData && featureInfo.featureData.length > 0) {
                    //                         for (let j = 0; j < res.data.featureData.length; j++) {
                    //                             const feature = res.data.featureData[j];
                    //
                    //                             if (feature.id === featureID) {
                    //                                 featureInfo.url = originUrl;
                    //                                 that.featureInfo[nodeInfo.id] = featureInfo;
                    //                                 hasFeature = true;
                    //                                 break;
                    //                             }
                    //                         }
                    //                     }
                    //                     if (nodeInfo.children && nodeInfo.children.length > 0) {
                    //                         nodeInfo.isLeafNode = false;
                    //                         for (let i = 0; i < nodeInfo.children.length; i++) {
                    //                             const childNode = nodeInfo.children[i];
                    //                             if (hasFeature) {
                    //                                 // @ts-ignore
                    //                                 let nextNodeUrl = pathJoin([originUrl, childNode.href]);
                    //
                    //                                 getNeededFeatureAndChildrenByID(layerUrl, featureID, nextNodeUrl);
                    //                             } else {
                    //
                    //                                 that.tstacks --;
                    //                                 // that.tstack.splice(that.tstack.indexOf(childNode.id), 1);
                    //                             }
                    //                         }
                    //                     }
                    //
                    //                     that.tstacks --;
                    //                         // that.tstack.splice(that.tstack.indexOf(nodeInfo.id), 1);
                    //
                    //
                    //                     // if (nodeInfo.isLeafNode && that.tstack.length === 0) {
                    //                     //     afterStoreInfo(featureID);
                    //                     // }
                    //                     if (that.tstacks === 1) {
                    //                         afterStoreInfo(featureID);
                    //                     }
                    //                 })
                    //             }
                    //         }
                    //     });
                    // }
                    async function afterStoreInfo(featureID) {
                        // console.log(that.featureInfo);
                        // console.log(that.nodeInfo);

                        let geometryUrls;
                        if (ifAddAllNode) {
                            geometryUrls = await getAllGeometryUrls();
                        } else {
                            geometryUrls = await getLeafGeometryUrls();
                        }
                        // @ts-ignore
                        if (geometryUrls.length === 0) {
                            console.warn("查询失败-ID：" + featureID);
                        }
                        console.log("检索到包含ID: "+ featureID +"的geometry URL：");
                        console.log(geometryUrls);
                        parseGeometriesInfo(geometryUrls);
                    }

                    function getAllGeometryUrls() {
                        const geometryUrls = [];
                        return new Promise(function (resolve) {
                            for (const featureID in that.featureInfo) {
                                for (const geometryNum in that.nodeInfo[featureID].geometryData) {
                                    geometryUrls.push(that.nodeInfo[featureID].url + that.nodeInfo[featureID].geometryData[geometryNum].href.substr(1));
                                }
                            }
                            // const selectedGeometryUrls = [geometryUrls[geometryUrls.length-1],geometryUrls[geometryUrls.length-3]];
                            // resolve(selectedGeometryUrls);
                            resolve(geometryUrls);
                        })
                    }

                    function getLeafGeometryUrls() {
                        const geometryUrls = [];
                        return new Promise(function (resolve) {
                            for (const featureID in that.featureInfo) {
                                for (const geometryNum in that.nodeInfo[featureID].geometryData)
                                    if (that.nodeInfo[featureID].isLeafNode) {
                                        geometryUrls.push(that.nodeInfo[featureID].url + that.nodeInfo[featureID].geometryData[geometryNum].href.substr(1));
                                    }
                            }
                            resolve(geometryUrls);
                        })
                    }

                    function parseGeometriesInfo(originGeometryUrlArray) {
                        if (originGeometryUrlArray !== undefined && originGeometryUrlArray !== []) {
                            for (const num in originGeometryUrlArray) {
                                axios({
                                    method: 'get',
                                    url: originGeometryUrlArray[num],
                                    responseType: 'blob',
                                    params:axiosParam.params
                                }).then(res => {
                                        let render = new FileReader();
                                        render.readAsArrayBuffer(res.data);
                                        render.onload = function () {
                                            const loadingNodeID = originGeometryUrlArray[num].split('/').slice(-3)[0];  //正在解析的数据的节点ID，用来查找它的mbs
                                            parseBinInfo(render.result, loadingNodeID);
                                            // parseBinInfoWithoutID(render.result);
                                        }
                                    }
                                ).catch((error) => {
                                    console.log(error)
                                })
                            }
                        }
                    }

                    //

                    function parseBinInfo(readerResult, loadingNodeID) {

                        const uInt32View = new Uint32Array(readerResult);
                        //解析顶点 要素数目
                        const verticesNum = uInt32View[0];

                        const mbs = that.nodeInfo[loadingNodeID].mbs;
                        //console.log(mbs);
                        const float32View = new Float32Array(readerResult);
                        const float32View_sub_position = float32View.subarray(2, verticesNum * 3 + 2);
                        const normalArray = float32View.subarray(verticesNum * 3 + 2, verticesNum * 6 + 2);
                        const uv0Array = float32View.subarray(verticesNum * 6 + 2, verticesNum * 8 + 2);

                        const uInt8View = new Uint8Array(readerResult);
                        const colorArray = uInt8View.subarray(verticesNum * 8 + 2, verticesNum * 12 + 2);

                        // mbs中心坐标与bin解析的GPS相对数值求和，经过坐标转换，得到每个点的笛卡尔坐标
                        const lengthTemp = float32View_sub_position.length - 2;
                        for (let i = 0; i < lengthTemp; i = i + 3) {

                            const position_GPS = [float32View_sub_position[i] + mbs[0], float32View_sub_position[i + 1] + mbs[1], float32View_sub_position[i + 2] + mbs[2]];

                            let position_XYZ = [0, 0, 0];
                            externalRenderer.toRenderCoordinates(
                                view,
                                position_GPS,
                                0,
                                that.nowSpatialReference,
                                position_XYZ,
                                0,
                                1
                            );
                            float32View_sub_position[i] = position_XYZ[0];
                            float32View_sub_position[i + 1] = position_XYZ[1];
                            float32View_sub_position[i + 2] = position_XYZ[2];
                        }

                        let positionArray = float32View_sub_position;

                        // console.log("正在绘制positionArray:");
                        // console.log(positionArray);
                        addGeometry(positionArray, normalArray, uv0Array, colorArray, mbs);
                    }

                    function pathJoin(parts, sep) {
                        const separator = sep || '/';
                        parts = parts.map((part, index) => {
                            if (index) {
                                part = part.replace(new RegExp('^' + separator), '');
                            }
                            if (index !== parts.length - 1) {
                                part = part.replace(new RegExp(separator + '$'), '');
                            }
                            return part;
                        });
                        return parts.join(separator);
                    }

                    function addGeometry(positionArray, normalArray, uv0Array, colorArray, mbs) {

                        let group = new THREE.Group();
                        let geometry = new THREE.BufferGeometry();

                        geometry.setAttribute('position', new THREE.BufferAttribute(positionArray, 3));

                        //计算包围盒，得到geometry中心
                        geometry.computeBoundingBox();

                        const boundingMin = geometry.boundingBox.min;
                        const boundingMax = geometry.boundingBox.max;

                        const boundingCenter = [(boundingMax.x + boundingMin.x) / 2, (boundingMax.y + boundingMin.y) / 2, (boundingMin.z + boundingMax.z) / 2];

                        // positionArray减掉geometry中心坐标
                        const relativePositionArray = new Float32Array(positionArray.length);
                        for (const pIndex in positionArray) {
                            // @ts-ignore
                            relativePositionArray[pIndex] = positionArray[pIndex] - boundingCenter[(pIndex % 3)];
                        }

                        geometry.setAttribute('position', new THREE.BufferAttribute(relativePositionArray, 3));
                        geometry.setAttribute('normal', new THREE.BufferAttribute(normalArray, 3));
                        geometry.setAttribute('uv0', new THREE.BufferAttribute(uv0Array, 2));
                        geometry.setAttribute('color', new THREE.BufferAttribute(colorArray, 4));

                        let material = new THREE.MeshFusionMaterial({
                            side: THREE.DoubleSide,
                            opacity: 0.0,
                            transparent: true,
                            polygonOffset: true,
                            polygonOffsetFactor: -6.5,
                            polygonOffsetUnits: -8.0

                        });

                        let mesh = new THREE.Mesh(geometry, material);
                        mesh.receiveShadow = true;
                        mesh.castShadow = true;
                        // mesh.position.set(boundingCenter[0] + 0.01, boundingCenter[1] + 0.01, (boundingCenter[2] + 0.01));
                        mesh.position.set(boundingCenter[0], boundingCenter[1], (boundingCenter[2]));

                        // mesh.add( new THREE.AxesHelper(10) );
                        group.add(mesh);
                        //group.add( new THREE.Box3Helper(tempGeometry.boundingBox, 0xff0000));

                        //添加地面
                        if (ifAddGround) {
                            let difference = Math.sqrt(Math.pow((boundingMax.x - boundingMin.x), 2) + Math.pow((boundingMax.y - boundingMin.y), 2) + Math.pow((boundingMax.z - boundingMin.z), 2));
                            addGround(difference, mbs);
                        }

                        that.scene.add(group);
                    }

                    function addGround(difference, mbs) {
                        //默认添加地面圆的半径为，模型包围盒的对角线长度的一半
                        let planeGeometry = new THREE.CircleBufferGeometry(difference / 2, 32);

                        if (groundCircleRadius !== null) {
                            planeGeometry = new THREE.CircleBufferGeometry(groundCircleRadius, 32);
                        }


                        const planeMaterial = new THREE.MeshFusionMaterial({
                            side: THREE.DoubleSide,
                            opacity: 0.0,
                            color: 0x00000000,
                            transparent: true,
                            polygonOffset: true,
                            polygonOffsetFactor: -0.5,
                            polygonOffsetUnits: -0.5

                        });
                        const plane = new THREE.Mesh(planeGeometry, planeMaterial);

                        plane.receiveShadow = true;
                        plane.castShadow = true;

                        let transform = new THREE.Matrix4();

                        transform.fromArray(
                            externalRenderer.renderCoordinateTransformAt(
                                view,
                                [mbs[0], mbs[1], addGroundHeight],
                                that.nowSpatialReference,
                                new Array(16)
                            )
                        );
                        transform.decompose(
                            plane.position,
                            plane.quaternion,
                            plane.scale
                        );
                        that.scene.add(plane);
                        // console.log( that.scene);
                    }

                    context.resetWebGLState();
                }
            },
            render: function (context) {

                const cam = context.camera;

                this.camera.position.set(cam.eye[0], cam.eye[1], cam.eye[2]);
                this.camera.up.set(cam.up[0], cam.up[1], cam.up[2]);
                this.camera.lookAt(
                    new THREE.Vector3(cam.center[0], cam.center[1], cam.center[2])
                );

                // 投影矩阵可以直接复制
                this.camera.projectionMatrix.fromArray(cam.projectionMatrix);

                // console.log(this.scene);
                // 绘制场景
                this.renderer.state.reset();

                this.renderer.state.setBlending(THREE.NoBlending);
                this.renderer.render(this.scene, this.camera);

                // 请求重绘视图。
                externalRenderer.requestRender(view);

                context.resetWebGLState();
            },

        };
        // console.log("myExternalRenderer defined!");

        // console.log("adding external Renderer", externalRenderer);
        externalRenderer.add(view, myExternalRenderer);
        // console.log("externalRenderer", externalRenderer);
    }

    render() {
        return;
    }

    createVideoStream(videoName) {
        return new Promise((resolve, reject) => {
            VideoStream.root = 'http://31.0.9.223:20002';

            this.videoStreams[videoName] = new VideoStream(videoName);
            console.log(this.videoStreams[videoName]);
            this.videoStreams[videoName].init().then(video => {
                    video.muted = true;
                    video.play();
                    resolve(video);

                    // setTimeout(()=> {
                    //     this.videoStreams[videoName].close();
                    //     console.log('close video')
                    // }, 6000)
                }
            );

        }).catch((e) => {
            console.log('error! ', e);
        })
    }

    getCameraMapList(cameraMapUrl) {
        return new Promise((resolve, reject) => {

            axios.get(cameraMapUrl).then(res => {
                    if (res.status === 200) {
                        resolve(res.data.data.camera_list);
                    } else {
                        console.warn("Get camera list ERROR! ");
                        console.warn(res);
                        reject(null);
                    }
                }
            )
        }).catch((e) => {
            console.log('error! ', e);
        })
    }

    getUuidFromCameraName(CameraName, cameraMapUrl) {
        return new Promise((resolve, reject) => {
            this.getCameraMapList(cameraMapUrl).then(cameraList => {
                let count = 0;
                // @ts-ignore
                for (let i = 0; i < cameraList.length; i++) {
                    if (cameraList[i].video_name === CameraName) {
                        resolve(cameraList[i]);
                    }
                    count++;
                }
                // @ts-ignore
                if (count === cameraList.length) reject(null)
            })
        }).catch((e) => {
            console.log('error! ', e);
        })
    }

    createProjectorFromDataCenterProps(dataCenterProps, videoElement, mapFlipY, maskFlipY, addHelper, maskUrl) {
        return new Promise((resolve, reject) => {
            const projectName = dataCenterProps.video_name;

            console.log('creating projector:' + projectName);
            this.projectors[projectName] = new THREE.Projector(0xff0000);

            const intrinsics = dataCenterProps.intrinsic.replace(/[\[\]]/g, '').split(',');
            // console.log(intrinsics);

            this.projectors[projectName].setAngleFromMatrix(new THREE.Matrix3().set(
                intrinsics[0], intrinsics[1], intrinsics[2],
                intrinsics[3], intrinsics[4], intrinsics[5],
                intrinsics[6], intrinsics[7], intrinsics[8],
            ));
            this.projectors[projectName].setDistortion(dataCenterProps.distcoeff.replace(/[\[\]]/g, '').split(','));
            const pose = dataCenterProps.extrinsic.replace(/[\[\]]/g, '').split(',');
            // console.log(pose);
            this.projectors[projectName].setPoseFromMatrix(new THREE.Matrix4().set(
                pose[1] * 1.732, pose[3] * 1.732, pose[0] * 1.732, pose[2] * 1.732,
                pose[5] * 1.732, pose[7] * 1.732, pose[4] * 1.732, pose[6] * 1.732,
                pose[9] * 1.732, pose[11] * 1.732, pose[8] * 1.732, pose[10] * 1.732,
                0, 0, 0, 0
            ));

            this.projectors[projectName].shadow.mapSize.width = 1024;
            this.projectors[projectName].shadow.mapSize.height = 1024;
            this.projectors[projectName].shadow.camera.near = 1;
            this.projectors[projectName].shadow.camera.far = 10000;

            // this[projectName].bias = -0.0001;

            this.projectors[projectName].map = new THREE.VideoTexture(videoElement);

            if (dataCenterProps.use_mask) {
                // console.log('-----------------------USING MASK---------------------');
                // console.log(this);
                this.projectors[projectName].useMask = true;
                let tempMaskUrl = './pic/' + dataCenterProps.video_name + '.jpg';
                if (maskUrl){
                    tempMaskUrl = maskUrl;
                }
                this.projectors[projectName].mask = new THREE.TextureLoader().load(tempMaskUrl);
                this.projectors[projectName].mask.flipY = maskFlipY;

            }
            this.projectors[projectName].bias = -0.0001;

            this.projectors[projectName].map.flipY = mapFlipY;
            this.projectors[projectName].castShadow = true;

            // @ts-ignore
            this.scene.add(this.projectors[projectName]);

            if (addHelper) {
                this[projectName].helper = new THREE.ProjectorHelper(this.projectors[projectName]);

                // @ts-ignore
                this.scene.add(this.projectors[projectName].helper);
            }
            resolve(this.projectors[projectName]);
        }).catch((e) => {
            console.log('error! ', e)
        });
    };

    //outdated
    createProjector(projectName, projectProps, videoElement, maskUrl, mapFlipY, maskFlipY, addHelper) {
        return new Promise((resolve, reject) => {
            this.projectors[projectName] = new THREE.Projector(0xff0000);
            const intrinsics = projectProps.Intrinsics;
            this.projectors[projectName].setAngleFromMatrix(new THREE.Matrix3().set(
                intrinsics[0][0], intrinsics[0][1], intrinsics[0][2],
                intrinsics[1][0], intrinsics[1][1], intrinsics[1][2],
                intrinsics[2][0], intrinsics[2][1], intrinsics[2][2],
            ));
            this.projectors[projectName].setDistortion(projectProps.distCoeffs);
            const pose = projectProps.images[0]['Pose, camera to model'];
            this.projectors[projectName].setPoseFromMatrix(new THREE.Matrix4().set(
                pose[0][1] * 1.732, pose[0][3] * 1.732, pose[0][0] * 1.732, pose[0][2] * 1.732,
                pose[1][1] * 1.732, pose[1][3] * 1.732, pose[1][0] * 1.732, pose[1][2] * 1.732,
                pose[2][1] * 1.732, pose[2][3] * 1.732, pose[2][0] * 1.732, pose[2][2] * 1.732,
                0, 0, 0, 0
            ));

            this.projectors[projectName].shadow.mapSize.width = 1024;
            this.projectors[projectName].shadow.mapSize.height = 1024;
            this.projectors[projectName].shadow.camera.near = 1;
            this.projectors[projectName].shadow.camera.far = 10000;

            this.projectors[projectName].bias = -0.0001;

            this.projectors[projectName].map = new THREE.VideoTexture(videoElement);
            this.projectors[projectName].useMask = true;
            this.projectors[projectName].mask = new THREE.TextureLoader().load(maskUrl);
            this.projectors[projectName].map.flipY = mapFlipY;
            this.projectors[projectName].mask.flipY = maskFlipY;
            this.projectors[projectName].castShadow = true;

            // @ts-ignore
            this.scene.add(this.projectors[projectName]);

            if (addHelper) {
                this.projectors[projectName].helper = new THREE.ProjectorHelper(this.projectors[projectName]);

                // @ts-ignore
                this.scene.add(this.projectors[projectName].helper);
            }
            resolve(this.projectors[projectName]);
        }).catch((e) => {
            console.log('error! ', e)
        });
    };

    //outdated
    createFlvPlayer(playerName, videoElement, flvUrl) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if (this.scene) {
                    // @ts-ignore
                    // this.scene.visible = true;

                    if (flvjs.isSupported()) {
                        this[playerName] = flvjs.createPlayer({
                            type: 'flv',
                            url: flvUrl,
                            isLive: true,
                        });
                        this[playerName].attachMediaElement(videoElement);

                        this[playerName].load();
                        this[playerName].play().then(r => {
                            resolve(videoElement);
                        });
                    }
                } else {
                    this.createFlvPlayer(playerName, videoElement, flvUrl);
                }
            }, 3000)

        }).catch((e) => {
            console.log('error! ', e)
        })
    }

    //outdated
    destroyFlvPlayer(flvPlayer) {
        try {
            flvPlayer.pause();
            flvPlayer.unload();
            flvPlayer.detachMediaElement();
            flvPlayer.destroy();
            flvPlayer = null;
        } catch (e) {
            console.warn(e);
        }
    }

    //outdated
    destroyProjector(playerName, projectName) {
        if (this[playerName] && this[playerName] !== null && this[playerName] !== undefined) {
            this.destroyFlvPlayer(this[playerName]);
        } else {
            console.log('There is no ' + playerName + ' player');
        }

        if (this.projectors[projectName] && this.projectors[projectName] !== undefined) {
            this.dispose(this.scene, this.projectors[projectName]);
            // @ts-ignore
            console.log('Destroy ' + projectName + ' success');
        } else console.log('Clean warning! There is no ' + projectName + ' projector');
    }

    destroyVideoStream( videoName ){
        try {
            this.videoStreams[videoName].close();
            console.log('Destroy video success')
        } catch (e) {
            console.warn(e);
        }
    }

    cleanProjector( projectorName ) {

        if (this.projectors[projectorName] && this.projectors[projectorName] !== undefined) {
            this.dispose(this.scene, this.projectors[projectorName]);
            // @ts-ignore
            console.log('Destroy ' + projectorName + ' success');
        } else console.log('Clean warning! There is no projector named' + projectorName);
    }


    destroyAllVideoStream (){
        for (let videoName in this.videoStreams){
            this.destroyVideoStream( videoName );
        }
    }

    cleanAllProjector (){
        try {
            for (let projectorName in this.projectors) {
                this.cleanProjector(projectorName);
            }
            this.destroyAllVideoStream();
        }catch (e) {
            console.log(e)
        }
    }


    dispose(parent, child) {
        if (child.children.length) {
            let arr = child.children.filter(x => x);
            arr.forEach(a => {
                this.dispose(child, a)
            })
        }
        if (child instanceof THREE.Mesh || child instanceof THREE.Line) {
            if (child.material.map) child.material.map.dispose();
            child.material.dispose();
            child.geometry.dispose();
        } else if (child.material) {
            child.material.dispose();
        }
        child.remove();
        parent.remove(child);
    }


}

export = ThreeCameras;

/*
* 打开遮挡注意事项： shadowMap.enabled = true;  x.castShadow = true; x.receiveShadow = true; side: THREE.DoubleSide; projector的distance不要设置; mapSize设成512x512或者1024x1024，需要是2的幂

*
*
*
*
* */
