define(["require", "exports", "tslib", "three-projector", "axios", "flv", "VideoStream", "esri/core/accessorSupport/decorators", "esri/widgets/Widget", "esri/widgets/support/widget", "esri/geometry/SpatialReference"], function (require, exports, tslib_1, THREE, axios_1, flv_1, VideoStream_1, decorators_1, Widget, widget_1, SpatialReference_1) {
    "use strict";
    THREE = tslib_1.__importStar(THREE);
    axios_1 = tslib_1.__importDefault(axios_1);
    flv_1 = tslib_1.__importDefault(flv_1);
    VideoStream_1 = tslib_1.__importDefault(VideoStream_1);
    SpatialReference_1 = tslib_1.__importDefault(SpatialReference_1);
    // @ts-ignore
    var ThreeCameras = /** @class */ (function (_super) {
        tslib_1.__extends(ThreeCameras, _super);
        function ThreeCameras(params) {
            var _this = _super.call(this, params) || this;
            _this.layerUrl = "https://tiles.arcgis.com/tiles/z2tnIkrLQ2BRzr6P/arcgis/rest/services/SanFrancisco_Bldgs/SceneServer/layers/0";
            _this.ifAddAllNode = false;
            _this.ifAddGround = true;
            _this.groundCircleRadius = null;
            _this.addGroundHeight = 0;
            _this.f = 'json';
            _this.token = '';
            return _this;
        }
        ThreeCameras.prototype.postInitialize = function () {
            console.log("Entering postInitialize", this);
            this.projectors = {};
            this.videoStreams = {};
            var view = this.view;
            var layerUrl = this.layerUrl;
            var featureIDArray = this.featureIDArray;
            var externalRenderer = this.externalRenderer;
            var ifAddAllNode = this.ifAddAllNode;
            var ifAddGround = this.ifAddGround;
            var groundCircleRadius = this.groundCircleRadius;
            var addGroundHeight = this.addGroundHeight;
            var axiosParam = {
                params: {
                    f: this.f,
                    token: this.token
                }
            };
            var tthis = this;
            console.log("Defining  myExternalRenderer");
            var myExternalRenderer = {
                setup: function (context) {
                    console.log("Entering setup");
                    this.renderer = new THREE.WebGLRenderer({
                        context: context.gl,
                        premultipliedAlpha: false,
                        antialias: true,
                        alpha: true
                    });
                    this.renderer.shadowMap.enabled = true;
                    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
                    //设置设备像素比，可以避免HiDPI设备上绘图模糊
                    this.renderer.setPixelRatio(window.devicePixelRatio);
                    //设置视口大小和三维场景的大小一样
                    this.renderer.setViewport(0, 0, view.width, view.height);
                    // 防止Three.js清除ArcGIS JS API提供的缓冲区
                    this.renderer.autoClearDepth = false; // 定义renderer是否清除深度缓存
                    this.renderer.autoClearStencil = false; // 定义renderer是否清除模板缓存
                    this.renderer.autoClearColor = false; // 定义renderer是否清除颜色缓存
                    //ArcGIS JS API渲染自定义离屏缓冲区，而不是默认的帧缓冲区。
                    //我们必须将这段代码注入到Three.js运行时中，以便绑定这些缓冲区而不是默认的缓冲区。
                    var originalSetRenderTarget = this.renderer.setRenderTarget.bind(this.renderer);
                    this.renderer.setRenderTarget = function (target) {
                        originalSetRenderTarget(target);
                        this.state.viewport(new THREE.Vector4(0, 0, view.width, view.height));
                        if (target == null) {
                            context.bindRenderTarget();
                        }
                    }.bind(this.renderer);
                    var that = this;
                    that.scene = new THREE.Scene();
                    that.camera = new THREE.PerspectiveCamera();
                    that.camera.far = 0; //10000000
                    tthis.scene = that.scene;
                    that.ambient = new THREE.AmbientLight(0xffffff, 0.5);
                    that.scene.add(that.ambient);
                    that.sun = new THREE.DirectionalLight(0xffffff, 0.5);
                    that.scene.add(that.sun);
                    that.tstack = [];
                    that.featureInfo = {}; //包含这个ID的feature数据
                    that.nodeInfo = {}; //所有检索过的节点信息，目的是查找mbs等
                    that.layer0Info = {}; //保存layer0的信息，用于查找地理参考等
                    that.nowSpatialReference = SpatialReference_1.default.WGS84; //初始化空间参考，默认为WGS84坐标系
                    that.tstacks = 0;
                  
                    loadArcgisLayer(layerUrl, featureIDArray);
                    function loadArcgisLayer(layerUrl, featureIDArray) {
                        addExGround();
                        getNeededNodeFeatureInfoByID(featureIDArray, layerUrl);
                        function getNeededNodeFeatureInfoByID(featureIDArray, originUrl) {
                            getRootNodeUrl(originUrl).then(function (rootNodeUrl) {
                                // that.tstack.push("root");
                                that.tstacks++;
                                for (var index in featureIDArray) {
                                    getNeededFeatureAndChildrenByID(originUrl, featureIDArray[index], rootNodeUrl);
                                }
                            });
                        }
                        function getRootNodeUrl(originUrl) {
                            return new Promise(function (resolve, reject) {
                                try {
                                    axios_1.default.get(originUrl, axiosParam).then(function (res) {
                                        console.log('origin info', res);
                                        that.layer0Info = res.data; //将layer0信息存入
                                        that.nowSpatialReference = new SpatialReference_1.default({ wkid: that.layer0Info.spatialReference.wkid });
                                        var rootNodeUrl = originUrl + res.data.store.rootNode.substr(1);
                                        resolve(rootNodeUrl);
                                    });
                                }
                                catch (e) {
                                    reject(e);
                                }
                            });
                        }
                        function getNeededFeatureAndChildrenByID(layerUrl, featureID, originUrl) {
                            axios_1.default.get(originUrl, axiosParam).then(function (res) {
                                var nodeInfo = res.data;
                                nodeInfo.isLeafNode = true;
                                if (nodeInfo.children && nodeInfo.children.length > 0) {
                                    nodeInfo.isLeafNode = false;
                                    for (var i = 0; i < nodeInfo.children.length; i++) {
                                        var childNode = nodeInfo.children[i];
                                        that.tstack.push(childNode.id);
                                        // console.log("nodeInfo.children");
                                        // console.log(that.tstack);
                                    }
                                }
                                if (!nodeInfo.featureData) {
                                    that.tstack.splice(that.tstack.indexOf(nodeInfo.id), 1);
                                    if (nodeInfo.children && nodeInfo.children.length > 0) {
                                        for (var i = 0; i < nodeInfo.children.length; i++) {
                                            var childNode = nodeInfo.children[i];
                                            // @ts-ignore
                                            var nextNodeUrl = pathJoin([originUrl, childNode.href]);
                                            getNeededFeatureAndChildrenByID(layerUrl, featureID, nextNodeUrl);
                                        }
                                    }
                                }
                                else {
                                    nodeInfo.url = originUrl;
                                    that.nodeInfo[nodeInfo.id] = nodeInfo;
                                    for (var i = 0; i < nodeInfo.featureData.length; i++) {
                                        var featureData = nodeInfo.featureData[i];
                                        // @ts-ignore
                                        var featureUrl = pathJoin([originUrl, featureData.href]);
                                        axios_1.default.get(featureUrl, axiosParam).then(function (res) {
                                            var featureInfo = res.data;
                                            var hasFeature = false;
                                            if (featureInfo.featureData && featureInfo.featureData.length > 0) {
                                                for (var j = 0; j < res.data.featureData.length; j++) {
                                                    var feature = res.data.featureData[j];
                                                    if (feature.id === featureID) {
                                                        featureInfo.url = originUrl;
                                                        that.featureInfo[nodeInfo.id] = featureInfo;
                                                        hasFeature = true;
                                                        break;
                                                    }
                                                }
                                            }
                                            that.tstack.splice(that.tstack.indexOf(nodeInfo.id), 1);
                                            if (nodeInfo.children && nodeInfo.children.length > 0) {
                                                nodeInfo.isLeafNode = false;
                                                for (var i_1 = 0; i_1 < nodeInfo.children.length; i_1++) {
                                                    var childNode = nodeInfo.children[i_1];
                                                    if (hasFeature) {
                                                        // @ts-ignore
                                                        var nextNodeUrl = pathJoin([originUrl, childNode.href]);
                                                        getNeededFeatureAndChildrenByID(layerUrl, featureID, nextNodeUrl);
                                                    }
                                                    else {
                                                        that.tstack.splice(that.tstack.indexOf(childNode.id), 1);
                                                        // console.log(that.tstack);
                                                    }
                                                }
                                            }
                                            if (that.tstack.length === 0) {
                                                // console.log(1111111111111);
                                                afterStoreInfo(featureID).then(function (r) { });
                                                return;
                                            }
                                        });
                                    }
                                }
                            });
                        }
                        // function getNeededFeatureAndChildrenByID(layerUrl, featureID, originUrl) {
                        //     axios.get(originUrl).then(res => {
                        //         const nodeInfo = res.data;
                        //         nodeInfo.isLeafNode = true;
                        //         if (nodeInfo.children && nodeInfo.children.length > 0) {
                        //             nodeInfo.isLeafNode = false;
                        //             for (let i = 0; i < nodeInfo.children.length; i++) {
                        //                 // const childNode = nodeInfo.children[i];
                        //                 // that.tstack.push(childNode.id);
                        //                 that.tstacks ++;
                        //             }
                        //         }
                        //         if (!nodeInfo.featureData) {
                        //             // that.tstack.splice(that.tstack.indexOf(nodeInfo.id), 1);
                        //             that.tstacks --;
                        //
                        //             if (nodeInfo.children && nodeInfo.children.length > 0) {
                        //                 for (let i = 0; i < nodeInfo.children.length; i++) {
                        //                     const childNode = nodeInfo.children[i];
                        //                     // @ts-ignore
                        //                     let nextNodeUrl = pathJoin([originUrl, childNode.href]);
                        //                     getNeededFeatureAndChildrenByID(layerUrl, featureID, nextNodeUrl);
                        //                 }
                        //             }
                        //         } else {
                        //             nodeInfo.url = originUrl;
                        //             that.nodeInfo[nodeInfo.id] = nodeInfo;
                        //             for (let i = 0; i < nodeInfo.featureData.length; i++) {
                        //                 const featureData = nodeInfo.featureData[i];
                        //                 // @ts-ignore
                        //                 let featureUrl = pathJoin([originUrl, featureData.href]);
                        //                 axios.get(featureUrl).then(res => {
                        //                     let featureInfo = res.data;
                        //                     let hasFeature = false;
                        //                     if (featureInfo.featureData && featureInfo.featureData.length > 0) {
                        //                         for (let j = 0; j < res.data.featureData.length; j++) {
                        //                             const feature = res.data.featureData[j];
                        //
                        //                             if (feature.id === featureID) {
                        //                                 featureInfo.url = originUrl;
                        //                                 that.featureInfo[nodeInfo.id] = featureInfo;
                        //                                 hasFeature = true;
                        //                                 break;
                        //                             }
                        //                         }
                        //                     }
                        //                     if (nodeInfo.children && nodeInfo.children.length > 0) {
                        //                         nodeInfo.isLeafNode = false;
                        //                         for (let i = 0; i < nodeInfo.children.length; i++) {
                        //                             const childNode = nodeInfo.children[i];
                        //                             if (hasFeature) {
                        //                                 // @ts-ignore
                        //                                 let nextNodeUrl = pathJoin([originUrl, childNode.href]);
                        //
                        //                                 getNeededFeatureAndChildrenByID(layerUrl, featureID, nextNodeUrl);
                        //                             } else {
                        //
                        //                                 that.tstacks --;
                        //                                 // that.tstack.splice(that.tstack.indexOf(childNode.id), 1);
                        //                             }
                        //                         }
                        //                     }
                        //
                        //                     that.tstacks --;
                        //                         // that.tstack.splice(that.tstack.indexOf(nodeInfo.id), 1);
                        //
                        //
                        //                     // if (nodeInfo.isLeafNode && that.tstack.length === 0) {
                        //                     //     afterStoreInfo(featureID);
                        //                     // }
                        //                     if (that.tstacks === 1) {
                        //                         afterStoreInfo(featureID);
                        //                     }
                        //                 })
                        //             }
                        //         }
                        //     });
                        // }
                        function afterStoreInfo(featureID) {
                            return tslib_1.__awaiter(this, void 0, void 0, function () {
                                var geometryUrls;
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0:
                                            if (!ifAddAllNode) return [3 /*break*/, 2];
                                            return [4 /*yield*/, getAllGeometryUrls()];
                                        case 1:
                                            geometryUrls = _a.sent();
                                            return [3 /*break*/, 4];
                                        case 2: return [4 /*yield*/, getLeafGeometryUrls()];
                                        case 3:
                                            geometryUrls = _a.sent();
                                            _a.label = 4;
                                        case 4:
                                            // @ts-ignore
                                            if (geometryUrls.length === 0) {
                                                console.warn("查询失败-ID：" + featureID);
                                            }
                                            console.log("检索到包含ID: " + featureID + "的geometry URL：");
                                            console.log(geometryUrls);
                                            parseGeometriesInfo(geometryUrls);
                                            return [2 /*return*/];
                                    }
                                });
                            });
                        }
                        function getAllGeometryUrls() {
                            var geometryUrls = [];
                            return new Promise(function (resolve) {
                                for (var featureID in that.featureInfo) {
                                    for (var geometryNum in that.nodeInfo[featureID].geometryData) {
                                        geometryUrls.push(that.nodeInfo[featureID].url + that.nodeInfo[featureID].geometryData[geometryNum].href.substr(1));
                                    }
                                }
                                // const selectedGeometryUrls = [geometryUrls[geometryUrls.length-1],geometryUrls[geometryUrls.length-3]];
                                // resolve(selectedGeometryUrls);
                                resolve(geometryUrls);
                            });
                        }
                        function getLeafGeometryUrls() {
                            var geometryUrls = [];
                            return new Promise(function (resolve) {
                                for (var featureID in that.featureInfo) {
                                    for (var geometryNum in that.nodeInfo[featureID].geometryData)
                                        if (that.nodeInfo[featureID].isLeafNode) {
                                            geometryUrls.push(that.nodeInfo[featureID].url + that.nodeInfo[featureID].geometryData[geometryNum].href.substr(1));
                                        }
                                }
                                resolve(geometryUrls);
                            });
                        }
                        function parseGeometriesInfo(originGeometryUrlArray) {
                            if (originGeometryUrlArray !== undefined && originGeometryUrlArray !== []) {
                                var _loop_1 = function (num) {
                                    axios_1.default({
                                        method: 'get',
                                        url: originGeometryUrlArray[num],
                                        responseType: 'blob',
                                        params: axiosParam.params
                                    }).then(function (res) {
                                        var render = new FileReader();
                                        render.readAsArrayBuffer(res.data);
                                        render.onload = function () {
                                            var loadingNodeID = originGeometryUrlArray[num].split('/').slice(-3)[0]; //正在解析的数据的节点ID，用来查找它的mbs
                                            parseBinInfo(render.result, loadingNodeID);
                                            // parseBinInfoWithoutID(render.result);
                                        };
                                    }).catch(function (error) {
                                        console.log(error);
                                    });
                                };
                                for (var num in originGeometryUrlArray) {
                                    _loop_1(num);
                                }
                            }
                        }
                        //
                        function parseBinInfo(readerResult, loadingNodeID) {
                            var uInt32View = new Uint32Array(readerResult);
                            //解析顶点 要素数目
                            var verticesNum = uInt32View[0];
                            var mbs = that.nodeInfo[loadingNodeID].mbs;
                            //console.log(mbs);
                            var float32View = new Float32Array(readerResult);
                            var float32View_sub_position = float32View.subarray(2, verticesNum * 3 + 2);
                            var normalArray = float32View.subarray(verticesNum * 3 + 2, verticesNum * 6 + 2);
                            var uv0Array = float32View.subarray(verticesNum * 6 + 2, verticesNum * 8 + 2);
                            var uInt8View = new Uint8Array(readerResult);
                            var colorArray = uInt8View.subarray(verticesNum * 8 + 2, verticesNum * 12 + 2);
                            // mbs中心坐标与bin解析的GPS相对数值求和，经过坐标转换，得到每个点的笛卡尔坐标
                            var lengthTemp = float32View_sub_position.length - 2;
                            for (var i = 0; i < lengthTemp; i = i + 3) {
                                var position_GPS = [float32View_sub_position[i] + mbs[0], float32View_sub_position[i + 1] + mbs[1], float32View_sub_position[i + 2] + mbs[2]];
                                var position_XYZ = [0, 0, 0];
                                externalRenderer.toRenderCoordinates(view, position_GPS, 0, that.nowSpatialReference, position_XYZ, 0, 1);
                                float32View_sub_position[i] = position_XYZ[0];
                                float32View_sub_position[i + 1] = position_XYZ[1];
                                float32View_sub_position[i + 2] = position_XYZ[2];
                            }
                            var positionArray = float32View_sub_position;
                            // console.log("正在绘制positionArray:");
                            // console.log(positionArray);
                            addGeometry(positionArray, normalArray, uv0Array, colorArray, mbs);
                        }
                        function pathJoin(parts, sep) {
                            var separator = sep || '/';
                            parts = parts.map(function (part, index) {
                                if (index) {
                                    part = part.replace(new RegExp('^' + separator), '');
                                }
                                if (index !== parts.length - 1) {
                                    part = part.replace(new RegExp(separator + '$'), '');
                                }
                                return part;
                            });
                            return parts.join(separator);
                        }
                        function addGeometry(positionArray, normalArray, uv0Array, colorArray, mbs) {
                            var group = new THREE.Group();
                            var geometry = new THREE.BufferGeometry();
                            geometry.setAttribute('position', new THREE.BufferAttribute(positionArray, 3));
                            //计算包围盒，得到geometry中心
                            geometry.computeBoundingBox();
                            var boundingMin = geometry.boundingBox.min;
                            var boundingMax = geometry.boundingBox.max;
                            var boundingCenter = [(boundingMax.x + boundingMin.x) / 2, (boundingMax.y + boundingMin.y) / 2, (boundingMin.z + boundingMax.z) / 2];
                            // positionArray减掉geometry中心坐标
                            var relativePositionArray = new Float32Array(positionArray.length);
                            for (var pIndex in positionArray) {
                                // @ts-ignore
                                relativePositionArray[pIndex] = positionArray[pIndex] - boundingCenter[(pIndex % 3)];
                            }
                            geometry.setAttribute('position', new THREE.BufferAttribute(relativePositionArray, 3));
                            geometry.setAttribute('normal', new THREE.BufferAttribute(normalArray, 3));
                            geometry.setAttribute('uv0', new THREE.BufferAttribute(uv0Array, 2));
                            geometry.setAttribute('color', new THREE.BufferAttribute(colorArray, 4));
                            var material = new THREE.MeshFusionMaterial({
                                side: THREE.DoubleSide,
                                opacity: 0.0,
                                transparent: true,
                                polygonOffset: true,
                                polygonOffsetFactor: -6.5,
                                polygonOffsetUnits: -8.0
                            });
                            var mesh = new THREE.Mesh(geometry, material);
                            mesh.receiveShadow = true;
                            mesh.castShadow = true;
                            // mesh.position.set(boundingCenter[0] + 0.01, boundingCenter[1] + 0.01, (boundingCenter[2] + 0.01));
                            mesh.position.set(boundingCenter[0], boundingCenter[1], (boundingCenter[2]));
                            // mesh.add( new THREE.AxesHelper(10) );
                            group.add(mesh);
                            //group.add( new THREE.Box3Helper(tempGeometry.boundingBox, 0xff0000));
                            //添加地面
                            if (ifAddGround) {
                                var difference = Math.sqrt(Math.pow((boundingMax.x - boundingMin.x), 2) + Math.pow((boundingMax.y - boundingMin.y), 2) + Math.pow((boundingMax.z - boundingMin.z), 2));
                                addGround(difference, mbs);
                            }
                            that.scene.add(group);
                        }
                        function addGround(difference, mbs) {
                            console.log('adding ground')
                            //默认添加地面圆的半径为，模型包围盒的对角线长度的一半
                            var planeGeometry = new THREE.CircleBufferGeometry(difference / 2, 32);
                            if (groundCircleRadius !== null) {
                                planeGeometry = new THREE.CircleBufferGeometry(groundCircleRadius, 32);
                            }
                            var planeMaterial = new THREE.MeshFusionMaterial({
                                side: THREE.DoubleSide,
                                // opacity: 0.0,
                                // color: 0x00000000,
                                opacity: 1.0,
                                color: 0xff0000,
                                transparent: true,
                                polygonOffset: true,
                                polygonOffsetFactor: -0.5,
                                polygonOffsetUnits: -0.5
                            });
                            var plane = new THREE.Mesh(planeGeometry, planeMaterial);
                            plane.receiveShadow = true;
                            plane.castShadow = true;
                            // var transform = new THREE.Matrix4();
                            // transform.fromArray(externalRenderer.renderCoordinateTransformAt(view, [mbs[0], mbs[1], addGroundHeight],  that.nowSpatialReference, new Array(16)));
                            // transform.decompose(plane.position, plane.quaternion, plane.scale);
                         
                            that.scene.add(plane);
                            console.log( that.scene);
                        }
                        function addExGround() {
                            console.log('adding ex ground')
                            //默认添加地面圆的半径为，模型包围盒的对角线长度的一半
                            var planeGeometry = new THREE.CircleBufferGeometry(901, 32);
                            // if (groundCircleRadius !== null) {
                            //     planeGeometry = new THREE.CircleBufferGeometry(groundCircleRadius, 32);
                            // }
                            var planeMaterial = new THREE.MeshFusionMaterial({
                                side: THREE.DoubleSide,
                                opacity: 0.0,
                                color: 0x00000000,
                                transparent: true,
                                polygonOffset: true,
                                polygonOffsetFactor: -0.5,
                                polygonOffsetUnits: -0.5
                            });
                            
                            console.log('planeMaterial',planeMaterial);
                            var plane = new THREE.Mesh(planeGeometry, planeMaterial);
                            plane.receiveShadow = true;
                            plane.castShadow = true;
                            var transform = new THREE.Matrix4();
                            transform.fromArray(externalRenderer.renderCoordinateTransformAt(view, [-11007,-1073,4.5],null, new Array(16)));
                            const pose = transform.decompose(plane.position, plane.quaternion, plane.scale);
                            // plane.position
                            console.log('plane pose',pose);
                            console.log('plane',plane);
                            that.scene.add(plane);
                            console.log( that.scene);
                        }
                        context.resetWebGLState();
                    }
                },
                render: function (context) {
                    var cam = context.camera;
                    this.camera.position.set(cam.eye[0], cam.eye[1], cam.eye[2]);
                    this.camera.up.set(cam.up[0], cam.up[1], cam.up[2]);
                    this.camera.lookAt(new THREE.Vector3(cam.center[0], cam.center[1], cam.center[2]));
                    // 投影矩阵可以直接复制
                    this.camera.projectionMatrix.fromArray(cam.projectionMatrix);
                    // console.log(this.scene);
                    // 绘制场景
                    this.renderer.state.reset();
                    this.renderer.state.setBlending(THREE.NoBlending);
                    this.renderer.render(this.scene, this.camera);
                    // 请求重绘视图。
                    externalRenderer.requestRender(view);
                    context.resetWebGLState();
                },
            };
            // console.log("myExternalRenderer defined!");
            // console.log("adding external Renderer", externalRenderer);
            externalRenderer.add(view, myExternalRenderer);
            // console.log("externalRenderer", externalRenderer);
        };
        ThreeCameras.prototype.render = function () {
            return;
        };
        ThreeCameras.prototype.createVideoStream = function (videoName) {
            var _this = this;
            return new Promise(function (resolve, reject) {
                VideoStream_1.default.root = 'http://31.0.9.223:20002';
                _this.videoStreams[videoName] = new VideoStream_1.default(videoName);
                console.log(_this.videoStreams[videoName]);
                _this.videoStreams[videoName].init().then(function (video) {
                    video.muted = true;
                    video.play();
                    resolve(video);
                    // setTimeout(()=> {
                    //     this.videoStreams[videoName].close();
                    //     console.log('close video')
                    // }, 6000)
                });
            }).catch(function (e) {
                console.log('error! ', e);
            });
        };
        ThreeCameras.prototype.getCameraMapList = function (cameraMapUrl) {
            return new Promise(function (resolve, reject) {
                axios_1.default.get(cameraMapUrl).then(function (res) {
                    if (res.status === 200) {
                        resolve(res.data.data.camera_list);
                    }
                    else {
                        console.warn("Get camera list ERROR! ");
                        console.warn(res);
                        reject(null);
                    }
                });
            }).catch(function (e) {
                console.log('error! ', e);
            });
        };
        ThreeCameras.prototype.getUuidFromCameraName = function (CameraName, cameraMapUrl) {
            var _this = this;
            return new Promise(function (resolve, reject) {
                _this.getCameraMapList(cameraMapUrl).then(function (cameraList) {
                    var count = 0;
                    // @ts-ignore
                    for (var i = 0; i < cameraList.length; i++) {
                        if (cameraList[i].video_name === CameraName) {
                            resolve(cameraList[i]);
                        }
                        count++;
                    }
                    // @ts-ignore
                    if (count === cameraList.length)
                        reject(null);
                });
            }).catch(function (e) {
                console.log('error! ', e);
            });
        };
        ThreeCameras.prototype.createProjectorFromDataCenterProps = function (dataCenterProps, videoElement, mapFlipY, maskFlipY, addHelper, maskUrl) {
            var _this = this;
            return new Promise(function (resolve, reject) {
                var projectName = dataCenterProps.video_name;
                console.log('creating projector:' + projectName);
                _this.projectors[projectName] = new THREE.Projector(0xff0000);
                var intrinsics = dataCenterProps.intrinsic.replace(/[\[\]]/g, '').split(',');
                // console.log(intrinsics);
                _this.projectors[projectName].setAngleFromMatrix(new THREE.Matrix3().set(intrinsics[0], intrinsics[1], intrinsics[2], intrinsics[3], intrinsics[4], intrinsics[5], intrinsics[6], intrinsics[7], intrinsics[8]));
                _this.projectors[projectName].setDistortion(dataCenterProps.distcoeff.replace(/[\[\]]/g, '').split(','));
                var pose = dataCenterProps.extrinsic.replace(/[\[\]]/g, '').split(',');
                // console.log(pose);
                _this.projectors[projectName].setPoseFromMatrix(new THREE.Matrix4().set(pose[1] * 1.732, pose[3] * 1.732, pose[0] * 1.732, pose[2] * 1.732, pose[5] * 1.732, pose[7] * 1.732, pose[4] * 1.732, pose[6] * 1.732, pose[9] * 1.732, pose[11] * 1.732, pose[8] * 1.732, pose[10] * 1.732, 0, 0, 0, 0));
                _this.projectors[projectName].shadow.mapSize.width = 1024;
                _this.projectors[projectName].shadow.mapSize.height = 1024;
                _this.projectors[projectName].shadow.camera.near = 0.1;
                _this.projectors[projectName].shadow.camera.far = 0;
                // this[projectName].bias = -0.0001;
                _this.projectors[projectName].map = new THREE.VideoTexture(videoElement);
                if (dataCenterProps.use_mask) {
                    // console.log('-----------------------USING MASK---------------------');
                    // console.log(this);
                    _this.projectors[projectName].useMask = true;
                    var tempMaskUrl = './pic/' + dataCenterProps.video_name + '.jpg';
                    if (maskUrl) {
                        tempMaskUrl = maskUrl;
                    }
                    _this.projectors[projectName].mask = new THREE.TextureLoader().load(tempMaskUrl);
                    _this.projectors[projectName].mask.flipY = maskFlipY;
                }
                _this.projectors[projectName].bias = -0.0001;
                _this.projectors[projectName].map.flipY = mapFlipY;
                _this.projectors[projectName].castShadow = true;
                // @ts-ignore
                _this.scene.add(_this.projectors[projectName]);
                if (addHelper) {
                    _this[projectName].helper = new THREE.ProjectorHelper(_this.projectors[projectName]);
                    // @ts-ignore
                    _this.scene.add(_this.projectors[projectName].helper);
                }
                resolve(_this.projectors[projectName]);
            }).catch(function (e) {
                console.log('error! ', e);
            });
        };
        ;
        //outdated
        ThreeCameras.prototype.createProjector = function (projectName, projectProps, videoElement, maskUrl, mapFlipY, maskFlipY, addHelper) {
            console.info(tslib_1, THREE, axios_1, flv_1, VideoStream_1)
            var _this = this;
            return new Promise(function (resolve, reject) {
                _this.projectors[projectName] = new THREE.Projector(0xff0000);
                var intrinsics = projectProps.Intrinsics;
                _this.projectors[projectName].setAngleFromMatrix(new THREE.Matrix3().set(intrinsics[0][0], intrinsics[0][1], intrinsics[0][2], intrinsics[1][0], intrinsics[1][1], intrinsics[1][2], intrinsics[2][0], intrinsics[2][1], intrinsics[2][2]));
                _this.projectors[projectName].setDistortion(projectProps.distCoeffs);
                var pose = projectProps.images[0]['Pose, camera to model'];
                _this.projectors[projectName].setPoseFromMatrix(new THREE.Matrix4().set(pose[0][1] * 1.732, pose[0][3] * 1.732, pose[0][0] * 1.732, pose[0][2] * 1.732, pose[1][1] * 1.732, pose[1][3] * 1.732, pose[1][0] * 1.732, pose[1][2] * 1.732, pose[2][1] * 1.732, pose[2][3] * 1.732, pose[2][0] * 1.732, pose[2][2] * 1.732, 0, 0, 0, 0));
                _this.projectors[projectName].shadow.mapSize.width = 1024;
                _this.projectors[projectName].shadow.mapSize.height = 1024;
                _this.projectors[projectName].shadow.camera.near = 0;
                _this.projectors[projectName].shadow.camera.far =0;
                // _this.projectors[projectName].bias = -0.01;
                _this.projectors[projectName].map = new THREE.VideoTexture(videoElement);
                _this.projectors[projectName].useMask = false;
                // _this.projectors[projectName].mask = new THREE.TextureLoader().load(maskUrl);
                _this.projectors[projectName].map.flipY = mapFlipY;
                // _this.projectors[projectName].mask.flipY = maskFlipY;
                _this.projectors[projectName].castShadow = true;
                // @ts-ignore
                _this.scene.add(_this.projectors[projectName]);
                if (addHelper) {
                    _this.projectors[projectName].helper = new THREE.ProjectorHelper(_this.projectors[projectName]);
                    // @ts-ignore
                    _this.scene.add(_this.projectors[projectName].helper);
                }
                resolve(_this.projectors[projectName]);
            }).catch(function (e) {
                console.log('error! ', e);
            });
        };
        ;
        //outdated
        ThreeCameras.prototype.createFlvPlayer = function (playerName, videoElement, flvUrl) {
            var _this = this;
            return new Promise(function (resolve, reject) {
                setTimeout(function () {
                    if (_this.scene) {
                        // @ts-ignore
                        // this.scene.visible = true;
                        if (flv_1.default.isSupported()) {
                            _this[playerName] = flv_1.default.createPlayer({
                                type: 'flv',
                                url: flvUrl,
                                isLive: true,
                            });
                            _this[playerName].attachMediaElement(videoElement);
                            _this[playerName].load();
                            _this[playerName].play().then(function (r) {
                                resolve(videoElement);
                            });
                        }
                    }
                    else {
                        _this.createFlvPlayer(playerName, videoElement, flvUrl);
                    }
                }, 3000);
            }).catch(function (e) {
                console.log('error! ', e);
            });
        };
        //outdated
        ThreeCameras.prototype.destroyFlvPlayer = function (flvPlayer) {
            try {
                flvPlayer.pause();
                flvPlayer.unload();
                flvPlayer.detachMediaElement();
                flvPlayer.destroy();
                flvPlayer = null;
            }
            catch (e) {
                console.warn(e);
            }
        };
        //outdated
        ThreeCameras.prototype.destroyProjector = function (playerName, projectName) {
            if (this[playerName] && this[playerName] !== null && this[playerName] !== undefined) {
                this.destroyFlvPlayer(this[playerName]);
            }
            else {
                console.log('There is no ' + playerName + ' player');
            }
            if (this.projectors[projectName] && this.projectors[projectName] !== undefined) {
                this.dispose(this.scene, this.projectors[projectName]);
                // @ts-ignore
                console.log('Destroy ' + projectName + ' success');
            }
            else
                console.log('Clean warning! There is no ' + projectName + ' projector');
        };
        ThreeCameras.prototype.destroyVideoStream = function (videoName) {
            try {
                this.videoStreams[videoName].close();
                console.log('Destroy video success');
            }
            catch (e) {
                console.warn(e);
            }
        };
        ThreeCameras.prototype.cleanProjector = function (projectorName) {
            if (this.projectors[projectorName] && this.projectors[projectorName] !== undefined) {
                this.dispose(this.scene, this.projectors[projectorName]);
                // @ts-ignore
                console.log('Destroy ' + projectorName + ' success');
            }
            else
                console.log('Clean warning! There is no projector named' + projectorName);
        };
        ThreeCameras.prototype.destroyAllVideoStream = function () {
            for (var videoName in this.videoStreams) {
                this.destroyVideoStream(videoName);
            }
        };
        ThreeCameras.prototype.cleanAllProjector = function () {
            try {
                for (var projectorName in this.projectors) {
                    this.cleanProjector(projectorName);
                }
                this.destroyAllVideoStream();
            }
            catch (e) {
                console.log(e);
            }
        };
        ThreeCameras.prototype.dispose = function (parent, child) {
            var _this = this;
            if (child.children.length) {
                var arr = child.children.filter(function (x) { return x; });
                arr.forEach(function (a) {
                    _this.dispose(child, a);
                });
            }
            if (child instanceof THREE.Mesh || child instanceof THREE.Line) {
                if (child.material.map)
                    child.material.map.dispose();
                child.material.dispose();
                child.geometry.dispose();
            }
            else if (child.material) {
                child.material.dispose();
            }
            child.remove();
            parent.remove(child);
        };
        tslib_1.__decorate([
            decorators_1.property(),
            widget_1.renderable()
        ], ThreeCameras.prototype, "view", void 0);
        tslib_1.__decorate([
            decorators_1.property(),
            widget_1.renderable()
        ], ThreeCameras.prototype, "layerUrl", void 0);
        tslib_1.__decorate([
            decorators_1.property(),
            widget_1.renderable()
        ], ThreeCameras.prototype, "featureIDArray", void 0);
        tslib_1.__decorate([
            decorators_1.property()
        ], ThreeCameras.prototype, "externalRenderer", void 0);
        tslib_1.__decorate([
            decorators_1.property(),
            widget_1.renderable()
        ], ThreeCameras.prototype, "ifAddAllNode", void 0);
        tslib_1.__decorate([
            decorators_1.property(),
            widget_1.renderable()
        ], ThreeCameras.prototype, "ifAddGround", void 0);
        tslib_1.__decorate([
            decorators_1.property(),
            widget_1.renderable()
        ], ThreeCameras.prototype, "groundCircleRadius", void 0);
        tslib_1.__decorate([
            decorators_1.property(),
            widget_1.renderable()
        ], ThreeCameras.prototype, "addGroundHeight", void 0);
        tslib_1.__decorate([
            decorators_1.property(),
            widget_1.renderable()
        ], ThreeCameras.prototype, "f", void 0);
        tslib_1.__decorate([
            decorators_1.property(),
            widget_1.renderable()
        ], ThreeCameras.prototype, "token", void 0);
        ThreeCameras = tslib_1.__decorate([
            decorators_1.subclass("esri/views/3d/externalRenderers")
        ], ThreeCameras);
        return ThreeCameras;
    }(Widget));
    return ThreeCameras;
});
/*
* 打开遮挡注意事项： shadowMap.enabled = true;  x.castShadow = true; x.receiveShadow = true; side: THREE.DoubleSide; projector的distance不要设置; mapSize设成512x512或者1024x1024，需要是2的幂

*
*
*
*
* */
//# sourceMappingURL=threeCameras.js.map