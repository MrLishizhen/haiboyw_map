//>>built
define({previousMessage:"\u018fvv\u0259lki variantlar",nextMessage:"Ba\u015fqa variantlar"});