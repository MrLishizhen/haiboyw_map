//>>built
define({previousMessage:"Choix pr\u00e9c\u00e9dents",nextMessage:"Plus de choix"});