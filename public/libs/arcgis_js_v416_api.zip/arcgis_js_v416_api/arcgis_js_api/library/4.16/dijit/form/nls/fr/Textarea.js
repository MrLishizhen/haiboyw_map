//>>built
define({iframeEditTitle:"zone d'\u00e9dition",iframeFocusTitle:"cadre de la zone d'\u00e9dition"});