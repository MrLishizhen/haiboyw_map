//>>built
define({iframeEditTitle:"redigeringsomr\u00e5de",iframeFocusTitle:"ramme for redigeringsomr\u00e5de"});