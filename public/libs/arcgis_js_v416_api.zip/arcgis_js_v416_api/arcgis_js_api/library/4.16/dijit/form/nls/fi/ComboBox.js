//>>built
define({previousMessage:"Edelliset valinnat",nextMessage:"Lis\u00e4\u00e4 valintoja"});