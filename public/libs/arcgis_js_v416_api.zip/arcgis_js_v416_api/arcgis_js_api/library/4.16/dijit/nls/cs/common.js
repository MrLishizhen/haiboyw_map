//>>built
define({buttonOk:"OK",buttonCancel:"Storno",buttonSave:"Ulo\u017eit",itemClose:"Zav\u0159\u00edt"});