//>>built
define({buttonOk:"OK",buttonCancel:"Annull\u00e9r",buttonSave:"Gem",itemClose:"Luk"});