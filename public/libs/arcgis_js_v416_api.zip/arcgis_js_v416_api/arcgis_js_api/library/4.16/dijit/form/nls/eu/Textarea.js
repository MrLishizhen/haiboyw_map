//>>built
define({iframeEditTitle:"editatu area",iframeFocusTitle:"editatu arearen markoa"});