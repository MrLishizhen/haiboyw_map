//>>built
define({iframeEditTitle:"Editierbereich",iframeFocusTitle:"Rahmen f\u00fcr Editierbereich"});