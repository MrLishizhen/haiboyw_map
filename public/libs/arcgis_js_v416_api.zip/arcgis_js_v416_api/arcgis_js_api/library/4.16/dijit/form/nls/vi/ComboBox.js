//>>built
define({previousMessage:"L\u1ef1a ch\u1ecdn tr\u01b0\u1edbc \u0111\u00f3",nextMessage:"L\u1ef1a ch\u1ecdn kh\u00e1c"});