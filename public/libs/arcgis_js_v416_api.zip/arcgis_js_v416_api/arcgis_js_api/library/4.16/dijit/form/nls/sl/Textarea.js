//>>built
define({iframeEditTitle:"urejevalno podro\u010dje",iframeFocusTitle:"okvir urejevalnega podro\u010dja"});