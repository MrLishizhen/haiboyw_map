//>>built
define({previousMessage:"Poprzednie wybory",nextMessage:"Wi\u0119cej wybor\u00f3w"});