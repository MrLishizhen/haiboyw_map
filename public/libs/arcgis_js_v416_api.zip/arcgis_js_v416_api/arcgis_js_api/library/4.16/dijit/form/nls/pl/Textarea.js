//>>built
define({iframeEditTitle:"edycja obszaru",iframeFocusTitle:"edycja ramki obszaru"});