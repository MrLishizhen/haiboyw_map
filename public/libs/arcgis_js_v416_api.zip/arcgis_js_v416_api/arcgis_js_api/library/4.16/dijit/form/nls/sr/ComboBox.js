//>>built
define({previousMessage:"Prethodne opcije",nextMessage:"Vi\u0161e opcija"});