//>>built
define({iframeEditTitle:"oblast \u00faprav",iframeFocusTitle:"r\u00e1mec oblasti \u00faprav"});