//>>built
define({iframeEditTitle:"muokkausalue",iframeFocusTitle:"muokkausalueen kehys"});