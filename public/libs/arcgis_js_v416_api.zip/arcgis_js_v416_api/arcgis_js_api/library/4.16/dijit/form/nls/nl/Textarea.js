//>>built
define({iframeEditTitle:"veld bewerken",iframeFocusTitle:"veldkader bewerken"});