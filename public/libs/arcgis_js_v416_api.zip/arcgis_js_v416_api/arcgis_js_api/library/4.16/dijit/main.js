//>>built
define(["dojo/_base/kernel"],function(a){return a.dijit});