//>>built
define({iframeEditTitle:"redigeringsomr\u00e5de",iframeFocusTitle:"ramme om redigeringsomr\u00e5de"});