//>>built
define({iframeEditTitle:"redigeringsomr\u00e5de",iframeFocusTitle:"redigeringsomr\u00e5desram"});