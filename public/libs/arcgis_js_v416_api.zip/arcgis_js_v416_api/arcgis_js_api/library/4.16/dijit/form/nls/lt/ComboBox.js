//>>built
define({previousMessage:"Ankstesni pasirinkimai",nextMessage:"Daugiau pasirinkim\u0173"});