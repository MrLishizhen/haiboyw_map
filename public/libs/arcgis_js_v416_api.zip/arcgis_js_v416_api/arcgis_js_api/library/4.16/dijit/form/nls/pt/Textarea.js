//>>built
define({iframeEditTitle:"editar \u00e1rea",iframeFocusTitle:"editar quadro da \u00e1rea"});