//>>built
define({iframeEditTitle:"edit area",iframeFocusTitle:"edit bingkai area"});