//>>built
define({buttonOk:"OK",buttonCancel:"Odustani",buttonSave:"Spremi",itemClose:"Zatvori"});