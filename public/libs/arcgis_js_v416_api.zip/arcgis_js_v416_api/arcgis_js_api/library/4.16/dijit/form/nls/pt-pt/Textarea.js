//>>built
define({iframeEditTitle:"\u00e1rea de edi\u00e7\u00e3o",iframeFocusTitle:"painel da \u00e1rea de edi\u00e7\u00e3o"});