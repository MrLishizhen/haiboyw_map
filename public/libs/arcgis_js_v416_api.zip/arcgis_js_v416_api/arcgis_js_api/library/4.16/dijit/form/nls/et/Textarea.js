//>>built
define({iframeEditTitle:"muudetav ala",iframeFocusTitle:"muudetava ala raam"});