//>>built
define(["dojo/_base/declare","./ValidationTextBox","./ComboBoxMixin"],function(a,b,c){return a("dijit.form.ComboBox",[b,c],{})});