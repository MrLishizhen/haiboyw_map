//>>built
define({previousMessage:"Op\u00e7\u00f5es anteriores",nextMessage:"Mais op\u00e7\u00f5es"});