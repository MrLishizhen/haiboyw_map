//>>built
define({loadingState:"Kargatzen...",errorState:"Barkatu, errorea gertatu da"});