//>>built
define({previousMessage:"Vorherige Auswahl",nextMessage:"Weitere Auswahlm\u00f6glichkeiten"});