//>>built
define({previousMessage:"Varasemad valikud",nextMessage:"Rohkem valikuid"});