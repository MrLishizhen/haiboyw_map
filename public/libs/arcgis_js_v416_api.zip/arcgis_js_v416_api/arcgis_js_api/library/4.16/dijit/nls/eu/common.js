//>>built
define({buttonOk:"Ados",buttonCancel:"Utzi",buttonSave:"Gorde",itemClose:"Itxi"});