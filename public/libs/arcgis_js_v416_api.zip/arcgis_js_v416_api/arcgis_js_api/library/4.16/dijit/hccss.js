//>>built
define(["dojo/dom-class","dojo/hccss","dojo/domReady","dojo/_base/window"],function(b,a,c,d){c(function(){a("highcontrast")&&b.add(d.body(),"dijit_a11y")});return a});