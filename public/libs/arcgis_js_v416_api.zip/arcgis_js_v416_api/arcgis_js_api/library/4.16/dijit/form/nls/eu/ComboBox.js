//>>built
define({previousMessage:"Aurreko aukerak",nextMessage:"Aukera gehiago"});