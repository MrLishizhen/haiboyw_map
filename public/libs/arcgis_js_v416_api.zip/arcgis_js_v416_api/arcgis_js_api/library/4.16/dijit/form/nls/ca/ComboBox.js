//>>built
define({previousMessage:"Opcions anteriors",nextMessage:"M\u00e9s opcions"});