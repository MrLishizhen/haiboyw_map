//>>built
define({loadingState:"Laadimine...",errorState:"Kahjuks ilmnes viga"});