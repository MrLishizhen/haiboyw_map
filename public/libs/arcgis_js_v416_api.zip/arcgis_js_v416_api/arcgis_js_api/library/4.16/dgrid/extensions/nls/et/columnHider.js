//>>built
define({popupLabel:"Kuva v\u00f5i peida veerud"});